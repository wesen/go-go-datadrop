package script

import (
	"context"
	"encoding/json"

	"github.com/go-go-golems/opendrop-pod/internal/realtime"
	"github.com/go-go-golems/opendrop-pod/internal/store"
)

// StoreBackend exposes only space-scoped data capabilities to scripts.
type StoreBackend struct {
	Store *store.Store
	Hub   *realtime.Hub
}

func (b StoreBackend) GetRecord(ctx context.Context, _ string, space, collection, rkey string) (store.Record, error) {
	return b.Store.GetRecord(ctx, space, collection, rkey)
}

func (b StoreBackend) PutRecord(ctx context.Context, actor, space, collection, rkey string, value json.RawMessage) (store.Record, error) {
	item, change, err := b.Store.PutRecord(ctx, actor, space, collection, rkey, value, nil)
	if err == nil && b.Hub != nil {
		b.Hub.Publish(change)
	}
	return item, err
}

func (b StoreBackend) AppendEvent(ctx context.Context, actor, space, stream string, data, meta json.RawMessage) (store.Event, error) {
	item, change, err := b.Store.AppendEvent(ctx, actor, space, stream, data, meta)
	if err == nil && b.Hub != nil {
		b.Hub.Publish(change)
	}
	return item, err
}

func (b StoreBackend) ListEvents(ctx context.Context, _ string, space, stream string, after int64, limit int) ([]store.Event, error) {
	return b.Store.ListEvents(ctx, space, stream, after, limit)
}
