package app

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"path/filepath"
	"sync"
	"time"

	"github.com/go-go-golems/opendrop-pod/internal/identity"
	"github.com/go-go-golems/opendrop-pod/internal/realtime"
	"github.com/go-go-golems/opendrop-pod/internal/script"
	"github.com/go-go-golems/opendrop-pod/internal/server"
	"github.com/go-go-golems/opendrop-pod/internal/store"
)

type Config struct {
	StateDir        string
	PublicURL       string
	SiteBaseURL     string
	RedirectURIs    []string
	AllowedOrigins  []string
	SeedLogin       string
	SeedPassword    string
	SeedEmail       string
	SessionTTL      time.Duration
	WSTicketTTL     time.Duration
	ScriptTimeout   time.Duration
	ScriptWorkers   int
	MaxRequestBytes int64
	Logger          *slog.Logger
}

type App struct {
	handler    http.Handler
	identity   *identity.Identity
	store      *store.Store
	dispatcher *script.Dispatcher
	cancel     context.CancelFunc
	closeOnce  sync.Once
	closeErr   error
}

func New(ctx context.Context, cfg Config) (_ *App, retErr error) {
	if ctx == nil {
		return nil, errors.New("application context is required")
	}
	if cfg.Logger == nil {
		cfg.Logger = slog.Default()
	}
	lifetime, cancel := context.WithCancel(ctx)
	app := &App{cancel: cancel}
	defer func() {
		if retErr != nil {
			_ = app.Close(context.Background())
		}
	}()
	id, err := identity.New(lifetime, identity.Config{
		StateRoot: cfg.StateDir, PublicURL: cfg.PublicURL, RedirectURIs: cfg.RedirectURIs,
		SeedLogin: cfg.SeedLogin, SeedPassword: cfg.SeedPassword, SeedEmail: cfg.SeedEmail,
	})
	if err != nil {
		return nil, fmt.Errorf("initialize identity: %w", err)
	}
	app.identity = id
	if _, err := id.Provider.RunMaintenance(lifetime); err != nil {
		return nil, fmt.Errorf("run initial identity maintenance: %w", err)
	}
	go func() {
		ticker := time.NewTicker(15 * time.Minute)
		defer ticker.Stop()
		for {
			select {
			case <-lifetime.Done():
				return
			case <-ticker.C:
				if _, err := id.Provider.RunMaintenance(lifetime); err != nil && lifetime.Err() == nil {
					cfg.Logger.Error("identity maintenance failed", "error", err)
				}
			}
		}
	}()
	dataStore, err := store.Open(lifetime, filepath.Join(cfg.StateDir, "data", "opendrop.sqlite"))
	if err != nil {
		return nil, fmt.Errorf("open data store: %w", err)
	}
	app.store = dataStore
	hub := realtime.NewHub(256)
	backend := script.StoreBackend{Store: dataStore, Hub: hub}
	runner, err := script.NewRunner(backend, cfg.ScriptTimeout)
	if err != nil {
		return nil, fmt.Errorf("initialize script runtime: %w", err)
	}
	dispatcher := script.NewDispatcher(dataStore, runner, cfg.ScriptWorkers, 256, cfg.Logger)
	dispatcher.Start(lifetime)
	app.dispatcher = dispatcher
	httpServer, err := server.New(server.Config{
		PublicURL: cfg.PublicURL, SiteBaseURL: cfg.SiteBaseURL, AllowedOrigins: cfg.AllowedOrigins,
		SessionTTL: cfg.SessionTTL, WSTicketTTL: cfg.WSTicketTTL,
		MaxRequestBytes: cfg.MaxRequestBytes, Logger: cfg.Logger,
	}, id, dataStore, hub, runner, dispatcher)
	if err != nil {
		return nil, fmt.Errorf("initialize HTTP server: %w", err)
	}
	app.handler = httpServer.Handler()
	return app, nil
}

func (a *App) Handler() http.Handler {
	if a == nil || a.handler == nil {
		return http.NotFoundHandler()
	}
	return a.handler
}

func (a *App) Close(ctx context.Context) error {
	if a == nil {
		return nil
	}
	if ctx == nil {
		ctx = context.Background()
	}
	a.closeOnce.Do(func() {
		if a.cancel != nil {
			a.cancel()
		}
		if a.dispatcher != nil {
			done := make(chan struct{})
			go func() {
				a.dispatcher.Wait()
				close(done)
			}()
			select {
			case <-done:
			case <-ctx.Done():
				a.closeErr = errors.Join(a.closeErr, ctx.Err())
			}
		}
		if a.identity != nil {
			a.closeErr = errors.Join(a.closeErr, a.identity.Close(ctx))
		}
		if a.store != nil {
			a.closeErr = errors.Join(a.closeErr, a.store.Close())
		}
	})
	return a.closeErr
}
