# OpenDrop Pod protocol profile

Status: implementation draft, 2026-07-23.

## 1. Terminology

- **Issuer:** the embedded tiny-idp origin, normally `<pod-origin>/idp`.
- **Pod:** the OpenDrop storage origin.
- **Space:** a private authorization and synchronization boundary.
- **Record:** a revisioned JSON value addressed by `(space, collection, rkey)`.
- **Stream event:** immutable JSON addressed by `(space, stream, sequence)`.
- **Change:** a committed mutation with a monotonically increasing global cursor.
- **Storage token:** an opaque OpenDrop token bound to a DPoP JWK thumbprint.
- **Site:** a versionless MVP manifest plus files, served from a per-site origin.

## 2. OAuth and DPoP

### 2.1 Browser

1. Generate a non-extractable P-256 key with WebCrypto.
2. Store the `CryptoKeyPair` in IndexedDB.
3. Start tiny-idp authorization code flow with PKCE and a configured redirect URI.
4. Request the resource indicator `<pod-origin>/api`.
5. Exchange the authorization code at the tiny-idp token endpoint.
6. Create an ES256 DPoP proof for `POST /xrpc/io.opendrop.session.createDPoP` with `ath = BASE64URL(SHA-256(bearer-token))`.
7. Send the bearer token and proof.
8. Receive an opaque storage token bound to the proof key thumbprint.

### 2.2 CLI

The CLI uses the tiny-idp device authorization grant, then performs the same storage-session exchange with a locally generated P-256 key.

### 2.3 Storage request

```http
POST /xrpc/io.opendrop.stream.append HTTP/1.1
Authorization: DPoP <opaque-token>
DPoP: <compact-JWS>
Content-Type: application/json
```

Required proof properties:

```json
{
  "header": {
    "typ": "dpop+jwt",
    "alg": "ES256",
    "jwk": { "kty": "EC", "crv": "P-256", "x": "...", "y": "..." }
  },
  "claims": {
    "jti": "fresh-random-value",
    "htm": "POST",
    "htu": "https://pod.example/xrpc/io.opendrop.stream.append",
    "iat": 1784832000,
    "ath": "base64url-sha256-of-storage-token",
    "nonce": "optional-server-challenge"
  }
}
```

`htu` uses an absolute HTTP(S) URI and excludes query and fragment. The server accepts a five-minute proof age, one minute future skew, and one use per `(JWK thumbprint, jti)`. A `nonce` is required when the server supplies a challenge, including the WebSocket channel proof.

## 3. Errors

```json
{
  "error": "InvalidRequest",
  "message": "space must match [a-z][a-z0-9-]{0,62}"
}
```

Common codes:

```text
InvalidRequest
InvalidToken
InvalidDPoPProof
InsufficientScope
Forbidden
NotFound
Conflict
OriginDenied
InvalidTicket
ScriptFailed
InternalError
```

## 4. Procedures

### 4.1 `io.opendrop.session.createDPoP`

```http
POST /xrpc/io.opendrop.session.createDPoP
Authorization: Bearer <tiny-idp-access-token>
DPoP: <proof whose ath covers the bearer token>
```

Response:

```json
{
  "tokenType": "DPoP",
  "accessToken": "opaque",
  "expiresAt": "2026-07-23T20:00:00Z",
  "subject": "local-alice",
  "scopes": ["opendrop.read", "opendrop.write"],
  "jkt": "RFC-7638-thumbprint"
}
```

### 4.2 `io.opendrop.repo.createSpace`

```json
{ "name": "greenhouse", "title": "Greenhouse" }
```

### 4.3 `io.opendrop.repo.putRecord`

```json
{
  "space": "greenhouse",
  "collection": "io.opendrop.sensor.profile",
  "rkey": "sensor-7",
  "record": { "label": "north bed", "unit": "Cel" },
  "swapRev": 4
}
```

`swapRev` is optional. `0` means the record must not exist. A mismatched revision returns `409 Conflict`.

Response:

```json
{
  "uri": "odrop://greenhouse/io.opendrop.sensor.profile/sensor-7",
  "space": "greenhouse",
  "collection": "io.opendrop.sensor.profile",
  "rkey": "sensor-7",
  "value": { "label": "north bed", "unit": "Cel" },
  "rev": 5,
  "digest": "hex-sha256-of-stored-normalized-json-bytes",
  "createdAt": "2026-07-23T18:00:00Z",
  "updatedAt": "2026-07-23T19:00:00Z"
}
```

### 4.4 `io.opendrop.repo.getRecord`

```http
GET /xrpc/io.opendrop.repo.getRecord?space=greenhouse&collection=io.opendrop.sensor.profile&rkey=sensor-7
```

### 4.5 `io.opendrop.repo.listRecords`

```http
GET /xrpc/io.opendrop.repo.listRecords?space=greenhouse&collection=io.opendrop.sensor.profile&cursor=sensor-6&limit=100
```

The cursor is the last returned lexical record key.

### 4.6 `io.opendrop.stream.append`

```json
{
  "space": "greenhouse",
  "stream": "readings",
  "data": { "sensor": "sensor-7", "temperature": 21.7 },
  "meta": { "source": "browser" }
}
```

Response includes a per-stream `sequence` and random event `id`.

### 4.7 `io.opendrop.stream.list`

```http
GET /xrpc/io.opendrop.stream.list?space=greenhouse&stream=readings&after=18400&limit=100
```

### 4.8 `io.opendrop.sync.subscribe`

```http
GET /xrpc/io.opendrop.sync.subscribe?space=greenhouse&cursor=9142
Accept: application/x-ndjson
```

Each line is one JSON object:

```json
{"type":"change","cursor":9143,"space":"greenhouse","kind":"stream.append","stream":"readings","sequence":18401,"actor":"local-alice","data":{},"createdAt":"..."}
```

Heartbeats:

```json
{"type":"heartbeat","cursor":9143,"time":"..."}
```

Slow-consumer reset:

```json
{"type":"reset","cursor":9143,"reason":"slow_consumer"}
```

Reconnect using the last processed durable cursor. Delivery is at least once.

### 4.9 WebSocket ticket

```json
{
  "space": "greenhouse",
  "cursor": 9142,
  "origin": "https://dashboard.greenhouse.sites.example"
}
```

The server binds the ticket to subject, DPoP thumbprint, space, cursor, browser origin, and a short expiry. The ticket is consumed atomically on upgrade. It is not sufficient by itself to receive data.

After upgrade, the server sends:

```json
{"type":"dpop_challenge","nonce":"random","htu":"https://pod.example/xrpc/io.opendrop.sync.websocket"}
```

The client responds with a proof signed by the same P-256 key whose thumbprint was attached to the ticket:

```json
{"type":"dpop_proof","proof":"compact-ES256-JWS"}
```

This channel proof uses `htm=GET`, the challenge `htu`, and the supplied `nonce`; it does not carry `ath` because the opaque ticket has already been consumed. On success, the server sends `{"type":"ready","cursor":9142}` and only then starts history replay and live delivery.

### 4.10 `io.opendrop.script.put`

```json
{
  "space": "greenhouse",
  "name": "frost-check",
  "source": "module.exports = function (ctx) { return {ok:true}; };",
  "enabled": true,
  "triggerStream": "readings"
}
```

### 4.11 `io.opendrop.script.run`

```json
{
  "space": "greenhouse",
  "name": "frost-check",
  "input": { "temperature": 2.4 }
}
```

### 4.12 Site procedures

Manifest:

```json
{
  "space": "greenhouse",
  "name": "dashboard",
  "public": true,
  "entrypoint": "index.html"
}
```

File:

```json
{
  "space": "greenhouse",
  "site": "dashboard",
  "path": "index.html",
  "contentType": "text/html",
  "contentBase64": "PCFkb2N0eXBlIGh0bWw+..."
}
```

## 5. Cursor transaction rule

Every mutable domain operation and its `changes` row occur in one SQLite transaction. A change is published to the in-process hub only after commit. A browser subscription registers with the hub before reading history, then discards live duplicates with `cursor <= lastCursor`.

## 6. Script capability rule

The runtime never receives an OAuth token, storage token, database handle, filesystem path, or unrestricted network object. It receives a Go-backed object whose methods have a fixed invocation space and actor. Script-generated events do not recursively enter the trigger dispatcher in this MVP.

## 7. Site-origin rule

A published site host is:

```text
<site>.<space>.<site-base-host>
```

The API automatically allows exact origins matching that two-label form, with the configured site-base scheme and port. The main administration origin never serves user site files.
