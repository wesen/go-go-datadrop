// Package weborigin parses and canonicalizes HTTP(S) origins shared by the
// identity, API, CLI, and static-site layers.
package weborigin

import (
	"errors"
	"net"
	"net/url"
	"strings"
)

// Parse accepts an HTTP(S) origin. Paths other than "/", userinfo, queries,
// and fragments are rejected. Default ports are removed.
func Parse(raw string) (*url.URL, error) {
	parsed, err := url.Parse(strings.TrimSpace(raw))
	if err != nil || parsed.Opaque != "" || parsed.Host == "" || parsed.User != nil {
		return nil, errors.New("origin must be an absolute HTTP(S) scheme and host")
	}
	parsed.Scheme = strings.ToLower(parsed.Scheme)
	if parsed.Scheme != "http" && parsed.Scheme != "https" {
		return nil, errors.New("origin scheme must be http or https")
	}
	if parsed.Path != "" && parsed.Path != "/" {
		return nil, errors.New("origin must not contain a path")
	}
	if parsed.RawQuery != "" || parsed.ForceQuery || parsed.Fragment != "" {
		return nil, errors.New("origin must not contain a query or fragment")
	}
	hostname := strings.ToLower(parsed.Hostname())
	if hostname == "" {
		return nil, errors.New("origin hostname is required")
	}
	port := parsed.Port()
	if (parsed.Scheme == "http" && port == "80") || (parsed.Scheme == "https" && port == "443") {
		port = ""
	}
	host := hostname
	if port != "" {
		host = net.JoinHostPort(hostname, port)
	} else if strings.Contains(hostname, ":") {
		host = "[" + hostname + "]"
	}
	return &url.URL{Scheme: parsed.Scheme, Host: host}, nil
}

// Canonical returns the normalized serialization of an HTTP(S) origin.
func Canonical(raw string) (string, error) {
	parsed, err := Parse(raw)
	if err != nil {
		return "", err
	}
	return parsed.String(), nil
}
