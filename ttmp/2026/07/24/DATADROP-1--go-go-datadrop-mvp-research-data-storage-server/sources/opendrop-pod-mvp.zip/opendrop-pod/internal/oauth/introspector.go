package oauth

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

type Principal struct {
	Subject   string
	ClientID  string
	Scopes    []string
	ExpiresAt time.Time
}

type Introspector struct {
	issuer     string
	endpoint   string
	clientID   string
	secret     string
	audience   string
	httpClient *http.Client
	now        func() time.Time
}

type Config struct {
	Issuer       string
	ClientID     string
	ClientSecret string
	Audience     string
	HTTPClient   *http.Client
	Now          func() time.Time
}

type discoveryDocument struct {
	Issuer                            string   `json:"issuer"`
	IntrospectionEndpoint             string   `json:"introspection_endpoint"`
	IntrospectionAuthMethodsSupported []string `json:"introspection_endpoint_auth_methods_supported"`
}

type introspectionResponse struct {
	Active    bool     `json:"active"`
	Issuer    string   `json:"iss"`
	Subject   string   `json:"sub"`
	ClientID  string   `json:"client_id"`
	Scope     string   `json:"scope"`
	Audience  []string `json:"aud"`
	Expires   int64    `json:"exp"`
	TokenType string   `json:"token_type"`
}

func New(ctx context.Context, cfg Config) (*Introspector, error) {
	if ctx == nil {
		return nil, errors.New("introspection context is required")
	}
	if cfg.Issuer == "" || cfg.ClientID == "" || cfg.ClientSecret == "" || cfg.Audience == "" {
		return nil, errors.New("issuer, client id, client secret, and audience are required")
	}
	client := cfg.HTTPClient
	if client == nil {
		client = &http.Client{Timeout: 10 * time.Second}
	}
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, strings.TrimRight(cfg.Issuer, "/")+"/.well-known/openid-configuration", nil)
	if err != nil {
		return nil, err
	}
	response, err := client.Do(request)
	if err != nil {
		return nil, fmt.Errorf("discover issuer: %w", err)
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("issuer discovery returned %d", response.StatusCode)
	}
	var discovery discoveryDocument
	if err := decodeJSON(response.Body, &discovery, 64<<10); err != nil {
		return nil, fmt.Errorf("decode discovery: %w", err)
	}
	if discovery.Issuer != strings.TrimRight(cfg.Issuer, "/") || discovery.IntrospectionEndpoint == "" {
		return nil, errors.New("issuer discovery mismatch or missing introspection endpoint")
	}
	if !contains(discovery.IntrospectionAuthMethodsSupported, "client_secret_basic") {
		return nil, errors.New("issuer does not advertise client_secret_basic introspection")
	}
	endpoint, err := url.Parse(discovery.IntrospectionEndpoint)
	if err != nil {
		return nil, fmt.Errorf("parse introspection endpoint: %w", err)
	}
	issuerURL, _ := url.Parse(cfg.Issuer)
	if endpoint.Scheme != issuerURL.Scheme || endpoint.Host != issuerURL.Host {
		return nil, errors.New("introspection endpoint is outside the issuer origin")
	}
	now := cfg.Now
	if now == nil {
		now = time.Now
	}
	return &Introspector{issuer: strings.TrimRight(cfg.Issuer, "/"), endpoint: endpoint.String(), clientID: cfg.ClientID, secret: cfg.ClientSecret, audience: cfg.Audience, httpClient: client, now: now}, nil
}

func (i *Introspector) Introspect(ctx context.Context, token string) (Principal, error) {
	if i == nil || strings.TrimSpace(token) == "" {
		return Principal{}, errors.New("access token is required")
	}
	form := url.Values{"token": {token}}
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, i.endpoint, strings.NewReader(form.Encode()))
	if err != nil {
		return Principal{}, err
	}
	request.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	request.SetBasicAuth(i.clientID, i.secret)
	response, err := i.httpClient.Do(request)
	if err != nil {
		return Principal{}, fmt.Errorf("introspect token: %w", err)
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return Principal{}, fmt.Errorf("introspection returned %d", response.StatusCode)
	}
	var result introspectionResponse
	if err := decodeJSON(response.Body, &result, 64<<10); err != nil {
		return Principal{}, fmt.Errorf("decode introspection: %w", err)
	}
	if !result.Active || result.Issuer != i.issuer || result.Subject == "" || !strings.EqualFold(result.TokenType, "Bearer") || !contains(result.Audience, i.audience) {
		return Principal{}, errors.New("access token is inactive or invalid for this resource")
	}
	expiresAt := time.Unix(result.Expires, 0).UTC()
	if result.Expires <= 0 || !i.now().UTC().Before(expiresAt) {
		return Principal{}, errors.New("access token is expired")
	}
	return Principal{Subject: result.Subject, ClientID: result.ClientID, Scopes: strings.Fields(result.Scope), ExpiresAt: expiresAt}, nil
}

func decodeJSON(reader io.Reader, target any, limit int64) error {
	decoder := json.NewDecoder(io.LimitReader(reader, limit))
	if err := decoder.Decode(target); err != nil {
		return err
	}
	var extra any
	if err := decoder.Decode(&extra); err != io.EOF {
		if err == nil {
			return errors.New("multiple JSON values")
		}
		return err
	}
	return nil
}

func contains(values []string, wanted string) bool {
	for _, value := range values {
		if value == wanted {
			return true
		}
	}
	return false
}
