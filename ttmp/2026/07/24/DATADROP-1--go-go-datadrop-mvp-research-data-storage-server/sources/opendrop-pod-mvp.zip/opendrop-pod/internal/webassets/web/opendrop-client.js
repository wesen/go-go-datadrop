const DB_NAME = "opendrop-browser-session";
const DB_VERSION = 1;
const STORE = "kv";

function b64url(bytes) {
  const input = bytes instanceof ArrayBuffer
    ? new Uint8Array(bytes)
    : ArrayBuffer.isView(bytes)
      ? new Uint8Array(bytes.buffer, bytes.byteOffset, bytes.byteLength)
      : new Uint8Array(bytes);
  let binary = "";
  for (const byte of input) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}

function randomValue(size = 32) {
  const bytes = new Uint8Array(size);
  crypto.getRandomValues(bytes);
  return b64url(bytes);
}

function utf8(value) {
  return new TextEncoder().encode(value);
}

async function sha256(value) {
  return crypto.subtle.digest("SHA-256", typeof value === "string" ? utf8(value) : value);
}

function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(STORE)) request.result.createObjectStore(STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function dbGet(key) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readonly");
    const request = tx.objectStore(STORE).get(key);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
    tx.oncomplete = () => db.close();
  });
}

async function dbPut(key, value) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(value, key);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error); };
  });
}

async function dbDelete(key) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).delete(key);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error); };
  });
}

function parseDERInteger(bytes, offset) {
  if (bytes[offset] !== 0x02) throw new Error("invalid DER ECDSA integer");
  const length = bytes[offset + 1];
  const start = offset + 2;
  let value = bytes.slice(start, start + length);
  while (value.length > 32 && value[0] === 0) value = value.slice(1);
  if (value.length > 32) throw new Error("DER ECDSA integer is too large");
  const padded = new Uint8Array(32);
  padded.set(value, 32 - value.length);
  return { value: padded, next: start + length };
}

function joseSignature(signature) {
  const bytes = new Uint8Array(signature);
  if (bytes.length === 64) return bytes;
  if (bytes[0] !== 0x30) throw new Error("unsupported ECDSA signature encoding");
  const first = parseDERInteger(bytes, 2);
  const second = parseDERInteger(bytes, first.next);
  const output = new Uint8Array(64);
  output.set(first.value, 0);
  output.set(second.value, 32);
  return output;
}

function canonicalHTU(raw) {
  const value = new URL(raw);
  if (value.protocol !== "http:" && value.protocol !== "https:") {
    throw new Error("DPoP htu must use http or https");
  }
  value.search = "";
  value.hash = "";
  return value.toString();
}

export class OpenDropClient {
  constructor(config = globalThis.OPENDROP_CONFIG ?? {}) {
    this.server = String(config.server ?? location.origin).replace(/\/$/, "");
    this.issuer = String(config.issuer ?? `${this.server}/idp`).replace(/\/$/, "");
    this.clientId = config.clientId ?? "opendrop-browser";
    this.resource = config.resource ?? `${this.server}/api`;
    this.scopes = config.scopes ?? ["openid", "profile", "email", "opendrop.read", "opendrop.write", "opendrop.script", "opendrop.site"];
    this.redirectUri = config.redirectUri ?? `${location.origin}/auth/callback`;
    this.keyPair = null;
    this.publicJWK = null;
    this.storageSession = null;
    this.oauthSession = null;
  }

  async initialize() {
    this.keyPair = await dbGet("dpop-keypair");
    if (!this.keyPair) {
      this.keyPair = await crypto.subtle.generateKey({ name: "ECDSA", namedCurve: "P-256" }, false, ["sign", "verify"]);
      await dbPut("dpop-keypair", this.keyPair);
    }
    this.publicJWK = await crypto.subtle.exportKey("jwk", this.keyPair.publicKey);
    delete this.publicJWK.key_ops;
    delete this.publicJWK.ext;
    this.storageSession = await dbGet("storage-session");
    this.oauthSession = await dbGet("oauth-session");
    if (this.storageSession && new Date(this.storageSession.expiresAt).getTime() <= Date.now()) {
      await dbDelete("storage-session");
      this.storageSession = null;
    }
    return this;
  }

  async beginLogin() {
    await this.initialize();
    const state = randomValue(24);
    const verifier = randomValue(48);
    const challenge = b64url(await sha256(verifier));
    sessionStorage.setItem("opendrop-oauth-state", JSON.stringify({ state, verifier, redirectUri: this.redirectUri }));
    const authorizationURL = new URL(`${this.issuer}/authorize`);
    authorizationURL.search = new URLSearchParams({
      response_type: "code",
      client_id: this.clientId,
      redirect_uri: this.redirectUri,
      scope: this.scopes.join(" "),
      state,
      code_challenge: challenge,
      code_challenge_method: "S256",
      resource: this.resource,
    });
    location.assign(authorizationURL);
  }

  async handleRedirect() {
    const parameters = new URLSearchParams(location.search);
    if (!parameters.has("code") && !parameters.has("error")) return false;
    const saved = JSON.parse(sessionStorage.getItem("opendrop-oauth-state") ?? "null");
    sessionStorage.removeItem("opendrop-oauth-state");
    if (parameters.has("error")) throw new Error(`${parameters.get("error")}: ${parameters.get("error_description") ?? "authorization failed"}`);
    if (!saved || parameters.get("state") !== saved.state) throw new Error("OAuth state mismatch");
    const body = new URLSearchParams({
      grant_type: "authorization_code",
      client_id: this.clientId,
      code: parameters.get("code"),
      redirect_uri: saved.redirectUri,
      code_verifier: saved.verifier,
      resource: this.resource,
    });
    const response = await fetch(`${this.issuer}/token`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    });
    const token = await response.json();
    if (!response.ok) throw new Error(token.error_description ?? token.error ?? `token endpoint returned ${response.status}`);
    this.oauthSession = token;
    await dbPut("oauth-session", token);
    await this.exchangeBearer(token.access_token);
    history.replaceState({}, document.title, location.pathname);
    return true;
  }

  async exchangeBearer(bearerToken) {
    await this.initialize();
    const endpoint = `${this.server}/xrpc/io.opendrop.session.createDPoP`;
    const proof = await this.createProof("POST", endpoint, bearerToken);
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { Authorization: `Bearer ${bearerToken}`, DPoP: proof },
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.message ?? payload.error ?? `session exchange returned ${response.status}`);
    this.storageSession = payload;
    await dbPut("storage-session", payload);
    return payload;
  }

  async refresh() {
    await this.initialize();
    if (!this.oauthSession?.refresh_token) throw new Error("no OAuth refresh token is available");
    const body = new URLSearchParams({
      grant_type: "refresh_token",
      client_id: this.clientId,
      refresh_token: this.oauthSession.refresh_token,
      resource: this.resource,
    });
    const response = await fetch(`${this.issuer}/token`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    });
    const token = await response.json();
    if (!response.ok) throw new Error(token.error_description ?? token.error ?? "refresh failed");
    this.oauthSession = { ...this.oauthSession, ...token };
    await dbPut("oauth-session", this.oauthSession);
    return this.exchangeBearer(token.access_token);
  }

  async logout() {
    await dbDelete("storage-session");
    await dbDelete("oauth-session");
    this.storageSession = null;
    this.oauthSession = null;
  }

  async createProof(method, rawURL, accessToken, nonce = "") {
    if (!this.keyPair) await this.initialize();
    const header = { typ: "dpop+jwt", alg: "ES256", jwk: this.publicJWK };
    const claims = {
      jti: randomValue(18),
      htm: method.toUpperCase(),
      htu: canonicalHTU(rawURL),
      iat: Math.floor(Date.now() / 1000),
    };
    if (accessToken) claims.ath = b64url(await sha256(accessToken));
    if (nonce) claims.nonce = nonce;
    const encodedHeader = b64url(utf8(JSON.stringify(header)));
    const encodedClaims = b64url(utf8(JSON.stringify(claims)));
    const signingInput = `${encodedHeader}.${encodedClaims}`;
    const signature = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, this.keyPair.privateKey, utf8(signingInput));
    return `${signingInput}.${b64url(joseSignature(signature))}`;
  }

  async request(method, rawURL, options = {}) {
    const { __retried = false, ...fetchOptions } = options;
    await this.initialize();
    if (!this.storageSession?.accessToken) throw new Error("not logged in");
    if (new Date(this.storageSession.expiresAt).getTime() <= Date.now()) await this.refresh();
    const token = this.storageSession.accessToken;
    const proof = await this.createProof(method, rawURL, token);
    const headers = new Headers(fetchOptions.headers ?? {});
    headers.set("Authorization", `DPoP ${token}`);
    headers.set("DPoP", proof);
    const response = await fetch(rawURL, { ...fetchOptions, method, headers });
    if (response.status === 401 && this.oauthSession?.refresh_token && !__retried) {
      await this.refresh();
      return this.request(method, rawURL, { ...fetchOptions, __retried: true });
    }
    return response;
  }

  async xrpc(name, { method = "POST", query = {}, body } = {}) {
    const endpoint = new URL(`${this.server}/xrpc/${name}`);
    for (const [key, value] of Object.entries(query)) {
      if (value !== undefined && value !== null && value !== "") endpoint.searchParams.set(key, String(value));
    }
    const options = {};
    if (body !== undefined) {
      options.headers = { "Content-Type": "application/json" };
      options.body = JSON.stringify(body);
    }
    const response = await this.request(method, endpoint.toString(), options);
    const contentType = response.headers.get("content-type") ?? "";
    const payload = contentType.includes("json") ? await response.json() : await response.text();
    if (!response.ok) throw new Error(payload?.message ?? payload?.error ?? `request returned ${response.status}`);
    return payload;
  }

  createSpace(name, title = name) {
    return this.xrpc("io.opendrop.repo.createSpace", { body: { name, title } });
  }
  listSpaces() {
    return this.xrpc("io.opendrop.repo.listSpaces", { method: "GET" });
  }
  getRecord(space, collection, rkey) {
    return this.xrpc("io.opendrop.repo.getRecord", { method: "GET", query: { space, collection, rkey } });
  }
  putRecord(space, collection, rkey, record, swapRev) {
    return this.xrpc("io.opendrop.repo.putRecord", { body: { space, collection, rkey, record, swapRev } });
  }
  append(space, stream, data, meta) {
    return this.xrpc("io.opendrop.stream.append", { body: { space, stream, data, meta } });
  }
  listEvents(space, stream, after = 0, limit = 100) {
    return this.xrpc("io.opendrop.stream.list", { method: "GET", query: { space, stream, after, limit } });
  }
  putScript(space, name, source, { enabled = true, triggerStream = "" } = {}) {
    return this.xrpc("io.opendrop.script.put", { body: { space, name, source, enabled, triggerStream } });
  }
  runScript(space, name, input = {}) {
    return this.xrpc("io.opendrop.script.run", { body: { space, name, input } });
  }

  async subscribe(space, cursor = 0, onMessage, { signal } = {}) {
    const endpoint = new URL(`${this.server}/xrpc/io.opendrop.sync.subscribe`);
    endpoint.searchParams.set("space", space);
    endpoint.searchParams.set("cursor", String(cursor));
    const response = await this.request("GET", endpoint.toString(), { signal });
    if (!response.ok) throw new Error(`subscription returned ${response.status}`);
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffered = "";
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffered += decoder.decode(value, { stream: true });
      let newline;
      while ((newline = buffered.indexOf("\n")) >= 0) {
        const line = buffered.slice(0, newline).trim();
        buffered = buffered.slice(newline + 1);
        if (line) await onMessage(JSON.parse(line));
      }
    }
  }

  async openWebSocket(space, cursor = 0) {
    const ticket = await this.xrpc("io.opendrop.sync.createWebSocketTicket", { body: { space, cursor, origin: location.origin } });
    const socket = new WebSocket(ticket.url);
    await new Promise((resolve, reject) => {
      const fail = () => reject(new Error("websocket closed before DPoP authentication completed"));
      const authenticate = async event => {
        let message;
        try {
          message = JSON.parse(event.data);
        } catch {
          return;
        }
        if (message.type === "dpop_challenge") {
          event.stopImmediatePropagation();
          try {
            const proof = await this.createProof("GET", message.htu, "", message.nonce);
            socket.send(JSON.stringify({ type: "dpop_proof", proof }));
          } catch (error) {
            socket.close();
            reject(error);
          }
          return;
        }
        if (message.type === "ready") {
          event.stopImmediatePropagation();
          socket.removeEventListener("message", authenticate);
          socket.removeEventListener("close", fail);
          resolve();
        }
      };
      socket.addEventListener("message", authenticate);
      socket.addEventListener("close", fail, { once: true });
      socket.addEventListener("error", () => reject(new Error("websocket authentication failed")), { once: true });
    });
    return socket;
  }
}
