package webassets

import "embed"

// FS contains the dependency-free browser console and SDK.
//
//go:embed web/*
var FS embed.FS
