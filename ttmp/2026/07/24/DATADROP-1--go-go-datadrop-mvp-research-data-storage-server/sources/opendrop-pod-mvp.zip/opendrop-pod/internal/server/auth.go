package server

import (
	"context"
	"errors"
	"net/http"
	"strings"
	"time"

	"github.com/go-go-golems/opendrop-pod/internal/dpop"
	"github.com/go-go-golems/opendrop-pod/internal/oauth"
	"github.com/go-go-golems/opendrop-pod/internal/store"
)

type principalKey struct{}

type Principal struct {
	Subject  string
	ClientID string
	Scopes   []string
	JKT      string
	Token    string
}

func principalFromContext(ctx context.Context) (Principal, bool) {
	value, ok := ctx.Value(principalKey{}).(Principal)
	return value, ok
}

func (s *Server) handleCreateDPoPSession(w http.ResponseWriter, r *http.Request) {
	bearer, ok := parseAuthorization(r.Header.Values("Authorization"), "Bearer")
	if !ok {
		w.Header().Set("WWW-Authenticate", `Bearer realm="opendrop"`)
		writeError(w, http.StatusUnauthorized, "InvalidToken", "one bearer access token is required")
		return
	}
	proofHeader := singleHeader(r.Header.Values("DPoP"))
	if proofHeader == "" {
		writeError(w, http.StatusUnauthorized, "InvalidDPoPProof", "DPoP proof is required")
		return
	}
	principal, err := s.introspector.Introspect(r.Context(), bearer)
	if err != nil {
		s.logger.Info("rejected bearer token exchange", "error", err)
		writeError(w, http.StatusUnauthorized, "InvalidToken", "bearer access token is inactive or invalid")
		return
	}
	proof, err := dpop.Verify(r.Context(), proofHeader, dpop.VerifyOptions{
		Method: r.Method, URL: s.requestURL(r), AccessToken: bearer, RequireATH: true,
		ReplayStore: s.store,
	})
	if err != nil {
		s.logger.Info("rejected DPoP exchange proof", "error", err, "subject", principal.Subject)
		writeError(w, http.StatusUnauthorized, "InvalidDPoPProof", "DPoP proof is invalid or replayed")
		return
	}
	expiresAt := time.Now().UTC().Add(s.cfg.SessionTTL)
	if principal.ExpiresAt.Before(expiresAt) {
		expiresAt = principal.ExpiresAt
	}
	token, err := s.store.CreateSession(r.Context(), principal.Subject, principal.ClientID, principal.Scopes, proof.Thumbprint, expiresAt)
	if err != nil {
		s.internalError(w, r, err)
		return
	}
	writeJSON(w, http.StatusCreated, map[string]any{
		"tokenType": "DPoP", "accessToken": token, "expiresAt": expiresAt,
		"subject": principal.Subject, "scopes": principal.Scopes, "jkt": proof.Thumbprint,
	})
}

func (s *Server) requireDPoP(requiredScopes []string, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		token, ok := parseAuthorization(r.Header.Values("Authorization"), "DPoP")
		if !ok {
			w.Header().Set("WWW-Authenticate", `DPoP realm="opendrop"`)
			writeError(w, http.StatusUnauthorized, "InvalidToken", "one DPoP access token is required")
			return
		}
		session, err := s.store.GetSession(r.Context(), token)
		if errors.Is(err, store.ErrNotFound) {
			writeError(w, http.StatusUnauthorized, "InvalidToken", "DPoP access token is expired or unknown")
			return
		}
		if err != nil {
			s.internalError(w, r, err)
			return
		}
		if !hasAllScopes(session.Scopes, requiredScopes) {
			writeError(w, http.StatusForbidden, "InsufficientScope", "the access token lacks a required scope")
			return
		}
		proofHeader := singleHeader(r.Header.Values("DPoP"))
		if proofHeader == "" {
			writeError(w, http.StatusUnauthorized, "InvalidDPoPProof", "DPoP proof is required")
			return
		}
		_, err = dpop.Verify(r.Context(), proofHeader, dpop.VerifyOptions{
			Method: r.Method, URL: s.requestURL(r), AccessToken: token, RequireATH: true,
			ExpectedJKT: session.JKT, ReplayStore: s.store,
		})
		if err != nil {
			s.logger.Info("rejected storage DPoP proof", "error", err, "subject", session.Subject)
			writeError(w, http.StatusUnauthorized, "InvalidDPoPProof", "DPoP proof is invalid or replayed")
			return
		}
		principal := Principal{Subject: session.Subject, ClientID: session.ClientID, Scopes: session.Scopes, JKT: session.JKT, Token: token}
		next.ServeHTTP(w, r.WithContext(context.WithValue(r.Context(), principalKey{}, principal)))
	})
}

func (s *Server) handleGetSession(w http.ResponseWriter, r *http.Request) {
	principal, _ := principalFromContext(r.Context())
	writeJSON(w, http.StatusOK, map[string]any{"subject": principal.Subject, "clientId": principal.ClientID, "scopes": principal.Scopes, "jkt": principal.JKT})
}

func parseAuthorization(values []string, scheme string) (string, bool) {
	if len(values) != 1 {
		return "", false
	}
	parts := strings.Fields(values[0])
	if len(parts) != 2 || !strings.EqualFold(parts[0], scheme) || parts[1] == "" || strings.ContainsAny(parts[1], "\r\n") {
		return "", false
	}
	return parts[1], true
}

func singleHeader(values []string) string {
	if len(values) != 1 || strings.TrimSpace(values[0]) == "" || strings.ContainsAny(values[0], "\r\n") {
		return ""
	}
	return strings.TrimSpace(values[0])
}

func hasAllScopes(actual, required []string) bool {
	set := make(map[string]struct{}, len(actual))
	for _, scope := range actual {
		set[scope] = struct{}{}
	}
	for _, scope := range required {
		if _, ok := set[scope]; !ok {
			return false
		}
	}
	return true
}

func minExpiry(principal oauth.Principal, ttl time.Duration) time.Time {
	expiry := time.Now().UTC().Add(ttl)
	if principal.ExpiresAt.Before(expiry) {
		return principal.ExpiresAt
	}
	return expiry
}
