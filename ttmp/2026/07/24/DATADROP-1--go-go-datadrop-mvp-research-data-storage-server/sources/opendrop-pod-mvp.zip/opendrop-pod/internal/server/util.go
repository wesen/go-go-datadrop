package server

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime"
	"net/http"
	"net/url"
	"path"
	"regexp"
	"strconv"
	"strings"

	"github.com/go-go-golems/opendrop-pod/internal/store"
	"github.com/go-go-golems/opendrop-pod/internal/weborigin"
)

var (
	spacePattern      = regexp.MustCompile(`^[a-z][a-z0-9-]{0,62}$`)
	namePattern       = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$`)
	collectionPattern = regexp.MustCompile(`^[A-Za-z][A-Za-z0-9.-]{0,127}$`)
	rkeyPattern       = regexp.MustCompile(`^[A-Za-z0-9._~:-]{1,256}$`)
)

func (s *Server) requestURL(r *http.Request) string {
	copy := *s.publicURL
	copy.Path = r.URL.Path
	copy.RawPath = ""
	copy.RawQuery = ""
	copy.Fragment = ""
	return copy.String()
}

func (s *Server) cors(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		origin := strings.TrimSpace(r.Header.Get("Origin"))
		if origin != "" && !s.originAllowed(origin) {
			writeError(w, http.StatusForbidden, "OriginDenied", "origin is not allowed")
			return
		}
		if origin != "" {
			w.Header().Set("Access-Control-Allow-Origin", origin)
			w.Header().Set("Vary", "Origin")
			w.Header().Set("Access-Control-Allow-Headers", "Authorization, DPoP, Content-Type")
			w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
			w.Header().Set("Access-Control-Expose-Headers", "ETag, DPoP-Nonce")
			w.Header().Set("Access-Control-Max-Age", "600")
		}
		if r.Method == http.MethodOptions {
			if origin == "" {
				writeError(w, http.StatusForbidden, "OriginDenied", "origin is required for preflight")
				return
			}
			w.WriteHeader(http.StatusNoContent)
			return
		}
		next.ServeHTTP(w, r)
	})
}

func (s *Server) originAllowed(raw string) bool {
	origin, err := canonicalOrigin(raw)
	if err != nil {
		return false
	}
	if _, ok := s.origins[origin]; ok {
		return true
	}
	if s.siteBaseURL == nil {
		return false
	}
	candidate, _ := url.Parse(origin)
	if candidate.Scheme != s.siteBaseURL.Scheme || candidate.Port() != s.siteBaseURL.Port() {
		return false
	}
	baseHost := strings.ToLower(s.siteBaseURL.Hostname())
	host := strings.ToLower(candidate.Hostname())
	if !strings.HasSuffix(host, "."+baseHost) {
		return false
	}
	prefix := strings.TrimSuffix(host, "."+baseHost)
	labels := strings.Split(prefix, ".")
	return len(labels) == 2 && namePattern.MatchString(labels[0]) && spacePattern.MatchString(labels[1])
}

func canonicalOrigin(raw string) (string, error) {
	return weborigin.Canonical(raw)
}

func decodeBody(w http.ResponseWriter, r *http.Request, limit int64, target any) bool {
	if limit <= 0 {
		limit = 1 << 20
	}
	r.Body = http.MaxBytesReader(w, r.Body, limit)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", "request body must be valid JSON: "+err.Error())
		return false
	}
	var extra any
	if err := decoder.Decode(&extra); err != io.EOF {
		writeError(w, http.StatusBadRequest, "InvalidRequest", "request body must contain exactly one JSON value")
		return false
	}
	return true
}

func writeJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}

func writeError(w http.ResponseWriter, status int, code, message string) {
	writeJSON(w, status, map[string]any{"error": code, "message": message})
}

func (s *Server) internalError(w http.ResponseWriter, r *http.Request, err error) {
	s.logger.Error("request failed", "error", err, "method", r.Method, "path", r.URL.Path)
	writeError(w, http.StatusInternalServerError, "InternalError", "the request could not be completed")
}

func (s *Server) mapStoreError(w http.ResponseWriter, r *http.Request, err error) {
	switch {
	case errors.Is(err, store.ErrNotFound):
		writeError(w, http.StatusNotFound, "NotFound", "the requested object does not exist")
	case errors.Is(err, store.ErrForbidden):
		writeError(w, http.StatusForbidden, "Forbidden", "the authenticated subject is not allowed to perform this operation")
	case errors.Is(err, store.ErrConflict):
		writeError(w, http.StatusConflict, "Conflict", "the operation conflicts with current state")
	default:
		s.internalError(w, r, err)
	}
}

func requireSpace(value string) error {
	if !spacePattern.MatchString(value) {
		return errors.New("space must match [a-z][a-z0-9-]{0,62}")
	}
	return nil
}

func requireName(label, value string) error {
	if !namePattern.MatchString(value) {
		return fmt.Errorf("%s contains unsupported characters or is too long", label)
	}
	return nil
}

func requireCollection(value string) error {
	if !collectionPattern.MatchString(value) {
		return errors.New("collection must be an NSID-like identifier")
	}
	return nil
}

func requireRKey(value string) error {
	if !rkeyPattern.MatchString(value) {
		return errors.New("record key contains unsupported characters or is too long")
	}
	return nil
}

func parseInt64(raw string, fallback int64) int64 {
	if strings.TrimSpace(raw) == "" {
		return fallback
	}
	value, err := strconv.ParseInt(raw, 10, 64)
	if err != nil || value < 0 {
		return fallback
	}
	return value
}

func cleanSitePath(value string) (string, error) {
	value = strings.TrimPrefix(strings.TrimSpace(value), "/")
	cleaned := path.Clean(value)
	if cleaned == "." || cleaned == "" || cleaned == ".." || strings.HasPrefix(cleaned, "../") || len(cleaned) > 512 {
		return "", errors.New("site file path is invalid")
	}
	return cleaned, nil
}

func normalizeContentType(value, filePath string) string {
	value = strings.TrimSpace(value)
	if value != "" {
		if mediaType, _, err := mime.ParseMediaType(value); err == nil {
			return mediaType
		}
	}
	if guessed := mime.TypeByExtension(path.Ext(filePath)); guessed != "" {
		return guessed
	}
	return "application/octet-stream"
}
