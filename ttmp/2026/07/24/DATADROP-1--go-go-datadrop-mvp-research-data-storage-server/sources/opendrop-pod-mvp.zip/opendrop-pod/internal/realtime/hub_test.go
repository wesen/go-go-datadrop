package realtime

import (
	"testing"

	"github.com/go-go-golems/opendrop-pod/internal/store"
)

func TestHubRoutesBySpace(t *testing.T) {
	hub := NewHub(2)
	left, cancelLeft := hub.Subscribe("left")
	defer cancelLeft()
	right, cancelRight := hub.Subscribe("right")
	defer cancelRight()
	hub.Publish(store.Change{Space: "left", Cursor: 1})
	select {
	case change := <-left:
		if change.Cursor != 1 {
			t.Fatalf("cursor=%d", change.Cursor)
		}
	default:
		t.Fatal("left subscriber did not receive change")
	}
	select {
	case <-right:
		t.Fatal("right subscriber received change for another space")
	default:
	}
}

func TestHubDisconnectsSlowSubscriber(t *testing.T) {
	hub := NewHub(1)
	channel, cancel := hub.Subscribe("space")
	defer cancel()
	hub.Publish(store.Change{Space: "space", Cursor: 1})
	hub.Publish(store.Change{Space: "space", Cursor: 2})
	first, ok := <-channel
	if !ok || first.Cursor != 1 {
		t.Fatalf("first=%#v ok=%v", first, ok)
	}
	if _, ok := <-channel; ok {
		t.Fatal("slow subscriber channel should be closed")
	}
}
