package store

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
)

func (s *Store) PutRecord(ctx context.Context, actor, space, collection, rkey string, value json.RawMessage, swapRev *int64) (Record, Change, error) {
	compacted, err := compactJSON(value)
	if err != nil {
		return Record{}, Change{}, err
	}
	now := s.now().UTC()
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return Record{}, Change{}, err
	}
	defer tx.Rollback()
	var currentRev int64
	var created string
	err = tx.QueryRowContext(ctx, `SELECT rev,created_at FROM records WHERE space_name=? AND collection=? AND rkey=?`, space, collection, rkey).Scan(&currentRev, &created)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return Record{}, Change{}, err
	}
	exists := err == nil
	if swapRev != nil {
		if (!exists && *swapRev != 0) || (exists && currentRev != *swapRev) {
			return Record{}, Change{}, ErrConflict
		}
	}
	record := Record{
		URI:        recordURI(space, collection, rkey),
		Space:      space,
		Collection: collection,
		RKey:       rkey,
		Value:      compacted,
		Rev:        currentRev + 1,
		Digest:     digestJSON(compacted),
		UpdatedAt:  now,
	}
	if exists {
		record.CreatedAt, err = parseTime(created)
		if err != nil {
			return Record{}, Change{}, err
		}
		_, err = tx.ExecContext(ctx, `UPDATE records SET value_json=?,rev=?,digest=?,updated_at=? WHERE space_name=? AND collection=? AND rkey=?`, compacted, record.Rev, record.Digest, utcText(now), space, collection, rkey)
	} else {
		record.CreatedAt = now
		_, err = tx.ExecContext(ctx, `INSERT INTO records(space_name,collection,rkey,value_json,rev,digest,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)`, space, collection, rkey, compacted, record.Rev, record.Digest, utcText(now), utcText(now))
	}
	if err != nil {
		return Record{}, Change{}, err
	}
	kind := "record.create"
	if exists {
		kind = "record.update"
	}
	change, err := insertJSONChange(ctx, tx, Change{Type: "change", Space: space, Kind: kind, Collection: collection, RKey: rkey, Actor: actor, CreatedAt: now}, record)
	if err != nil {
		return Record{}, Change{}, err
	}
	if err := tx.Commit(); err != nil {
		return Record{}, Change{}, err
	}
	return record, change, nil
}

func (s *Store) GetRecord(ctx context.Context, space, collection, rkey string) (Record, error) {
	var item Record
	var created, updated string
	err := s.db.QueryRowContext(ctx, `SELECT value_json,rev,digest,created_at,updated_at FROM records WHERE space_name=? AND collection=? AND rkey=?`, space, collection, rkey).
		Scan(&item.Value, &item.Rev, &item.Digest, &created, &updated)
	if errors.Is(err, sql.ErrNoRows) {
		return Record{}, ErrNotFound
	}
	if err != nil {
		return Record{}, err
	}
	item.Space, item.Collection, item.RKey = space, collection, rkey
	item.URI = recordURI(space, collection, rkey)
	item.CreatedAt, err = parseTime(created)
	if err != nil {
		return Record{}, err
	}
	item.UpdatedAt, err = parseTime(updated)
	return item, err
}

func (s *Store) ListRecords(ctx context.Context, space, collection, cursor string, limit int) ([]Record, string, error) {
	if limit <= 0 || limit > 500 {
		limit = 100
	}
	rows, err := s.db.QueryContext(ctx, `SELECT rkey,value_json,rev,digest,created_at,updated_at FROM records WHERE space_name=? AND collection=? AND rkey>? ORDER BY rkey LIMIT ?`, space, collection, cursor, limit+1)
	if err != nil {
		return nil, "", err
	}
	defer rows.Close()
	items := make([]Record, 0, limit)
	next := ""
	for rows.Next() {
		var item Record
		var created, updated string
		if err := rows.Scan(&item.RKey, &item.Value, &item.Rev, &item.Digest, &created, &updated); err != nil {
			return nil, "", err
		}
		if len(items) == limit {
			next = items[len(items)-1].RKey
			break
		}
		item.Space, item.Collection = space, collection
		item.URI = recordURI(space, collection, item.RKey)
		item.CreatedAt, err = parseTime(created)
		if err != nil {
			return nil, "", err
		}
		item.UpdatedAt, err = parseTime(updated)
		if err != nil {
			return nil, "", err
		}
		items = append(items, item)
	}
	if err := rows.Err(); err != nil {
		return nil, "", err
	}
	return items, next, nil
}

func (s *Store) DeleteRecord(ctx context.Context, actor, space, collection, rkey string, swapRev *int64) (Change, error) {
	now := s.now().UTC()
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return Change{}, err
	}
	defer tx.Rollback()
	var currentRev int64
	err = tx.QueryRowContext(ctx, `SELECT rev FROM records WHERE space_name=? AND collection=? AND rkey=?`, space, collection, rkey).Scan(&currentRev)
	if errors.Is(err, sql.ErrNoRows) {
		return Change{}, ErrNotFound
	}
	if err != nil {
		return Change{}, err
	}
	if swapRev != nil && currentRev != *swapRev {
		return Change{}, ErrConflict
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM records WHERE space_name=? AND collection=? AND rkey=?`, space, collection, rkey); err != nil {
		return Change{}, err
	}
	change, err := insertJSONChange(ctx, tx, Change{Type: "change", Space: space, Kind: "record.delete", Collection: collection, RKey: rkey, Actor: actor, CreatedAt: now}, map[string]any{"uri": recordURI(space, collection, rkey), "rev": currentRev})
	if err != nil {
		return Change{}, err
	}
	if err := tx.Commit(); err != nil {
		return Change{}, err
	}
	return change, nil
}

func recordURI(space, collection, rkey string) string {
	return fmt.Sprintf("odrop://%s/%s/%s", space, collection, rkey)
}
