package store

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/go-go-golems/opendrop-pod/internal/dpop"
)

func (s *Store) CreateSession(ctx context.Context, subject, clientID string, scopes []string, jkt string, expiresAt time.Time) (string, error) {
	token, err := randomOpaque(32)
	if err != nil {
		return "", err
	}
	now := s.now().UTC()
	scopeJSON, err := json.Marshal(scopes)
	if err != nil {
		return "", err
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return "", err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, `DELETE FROM dpop_sessions WHERE expires_at <= ?`, utcText(now)); err != nil {
		return "", err
	}
	if _, err := tx.ExecContext(ctx, `INSERT INTO dpop_sessions(token_hash,subject,client_id,scopes_json,jkt,expires_at,created_at) VALUES(?,?,?,?,?,?,?)`,
		hashOpaque(token), subject, clientID, scopeJSON, jkt, utcText(expiresAt), utcText(now)); err != nil {
		return "", fmt.Errorf("insert DPoP session: %w", err)
	}
	if err := tx.Commit(); err != nil {
		return "", err
	}
	return token, nil
}

func (s *Store) GetSession(ctx context.Context, token string) (Session, error) {
	var session Session
	var scopesJSON []byte
	var expiry string
	err := s.db.QueryRowContext(ctx, `SELECT subject,client_id,scopes_json,jkt,expires_at FROM dpop_sessions WHERE token_hash=?`, hashOpaque(token)).
		Scan(&session.Subject, &session.ClientID, &scopesJSON, &session.JKT, &expiry)
	if errors.Is(err, sql.ErrNoRows) {
		return Session{}, ErrNotFound
	}
	if err != nil {
		return Session{}, err
	}
	if err := json.Unmarshal(scopesJSON, &session.Scopes); err != nil {
		return Session{}, fmt.Errorf("decode stored scopes: %w", err)
	}
	session.ExpiresAt, err = parseTime(expiry)
	if err != nil {
		return Session{}, err
	}
	if !s.now().UTC().Before(session.ExpiresAt) {
		_, _ = s.db.ExecContext(ctx, `DELETE FROM dpop_sessions WHERE token_hash=?`, hashOpaque(token))
		return Session{}, ErrNotFound
	}
	return session, nil
}

// UseDPoPProof implements dpop.ReplayStore with an atomic unique insert.
func (s *Store) UseDPoPProof(ctx context.Context, thumbprint, jti string, expiresAt time.Time) error {
	now := s.now().UTC()
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, `DELETE FROM dpop_replays WHERE expires_at <= ?`, utcText(now)); err != nil {
		return err
	}
	if _, err := tx.ExecContext(ctx, `INSERT INTO dpop_replays(jkt,jti,expires_at) VALUES(?,?,?)`, thumbprint, jti, utcText(expiresAt)); err != nil {
		if isSQLiteConstraint(err) {
			return dpop.ErrReplay
		}
		return err
	}
	return tx.Commit()
}

func (s *Store) CreateWSTicket(ctx context.Context, ticket WSTicket, ttl time.Duration) (string, error) {
	if ttl <= 0 {
		ttl = 30 * time.Second
	}
	now := s.now().UTC()
	ticket.ExpiresAt = now.Add(ttl)
	value, err := randomOpaque(24)
	if err != nil {
		return "", err
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return "", err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, `DELETE FROM websocket_tickets WHERE expires_at <= ? OR used_at IS NOT NULL`, utcText(now)); err != nil {
		return "", err
	}
	_, err = tx.ExecContext(ctx, `INSERT INTO websocket_tickets(ticket_hash,subject,jkt,space_name,cursor,origin,expires_at,used_at) VALUES(?,?,?,?,?,?,?,NULL)`,
		hashOpaque(value), ticket.Subject, ticket.JKT, ticket.Space, ticket.Cursor, ticket.Origin, utcText(ticket.ExpiresAt))
	if err != nil {
		return "", err
	}
	if err := tx.Commit(); err != nil {
		return "", err
	}
	return value, nil
}

func (s *Store) ConsumeWSTicket(ctx context.Context, value string) (WSTicket, error) {
	now := s.now().UTC()
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return WSTicket{}, err
	}
	defer tx.Rollback()
	var ticket WSTicket
	var expiry string
	var used sql.NullString
	err = tx.QueryRowContext(ctx, `SELECT subject,jkt,space_name,cursor,origin,expires_at,used_at FROM websocket_tickets WHERE ticket_hash=?`, hashOpaque(value)).
		Scan(&ticket.Subject, &ticket.JKT, &ticket.Space, &ticket.Cursor, &ticket.Origin, &expiry, &used)
	if errors.Is(err, sql.ErrNoRows) {
		return WSTicket{}, ErrNotFound
	}
	if err != nil {
		return WSTicket{}, err
	}
	ticket.ExpiresAt, err = parseTime(expiry)
	if err != nil {
		return WSTicket{}, err
	}
	if used.Valid {
		return WSTicket{}, ErrTicketUsed
	}
	if !now.Before(ticket.ExpiresAt) {
		return WSTicket{}, ErrTicketExpiry
	}
	result, err := tx.ExecContext(ctx, `UPDATE websocket_tickets SET used_at=? WHERE ticket_hash=? AND used_at IS NULL`, utcText(now), hashOpaque(value))
	if err != nil {
		return WSTicket{}, err
	}
	rows, err := result.RowsAffected()
	if err != nil || rows != 1 {
		return WSTicket{}, ErrTicketUsed
	}
	if err := tx.Commit(); err != nil {
		return WSTicket{}, err
	}
	return ticket, nil
}

func isSQLiteConstraint(err error) bool {
	if err == nil {
		return false
	}
	message := err.Error()
	return containsAny(message, "UNIQUE constraint failed", "constraint failed")
}

func containsAny(value string, candidates ...string) bool {
	for _, candidate := range candidates {
		if len(candidate) != 0 && len(value) >= len(candidate) {
			for index := 0; index+len(candidate) <= len(value); index++ {
				if value[index:index+len(candidate)] == candidate {
					return true
				}
			}
		}
	}
	return false
}
