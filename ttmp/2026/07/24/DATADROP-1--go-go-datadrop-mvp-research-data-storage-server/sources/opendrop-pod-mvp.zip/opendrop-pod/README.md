# OpenDrop Pod

OpenDrop Pod is a browser-first, PDS-shaped storage service for static applications. It embeds [tiny-idp](https://github.com/go-go-golems/tiny-idp), uses OAuth authorization code plus PKCE in browsers, upgrades the resulting bearer token into a DPoP-bound storage session, exposes XRPC-shaped record and stream methods, maintains resumable realtime cursors, and runs owner-managed CommonJS functions through [go-go-goja](https://github.com/go-go-golems/go-go-goja).

It is a runnable MVP, not an AT Protocol PDS implementation. It does not yet implement AT Protocol repositories, Merkle Search Trees, CAR synchronization, handle resolution, federation, or AppViews. The reusable part is the PDS interaction model: identity discovery, user-owned spaces, records, blobs/sites, XRPC-shaped methods, and cursor-based synchronization.

## What is included

- Embedded tiny-idp issuer with persistent SQLite state.
- Browser OAuth code flow with PKCE and a non-extractable WebCrypto P-256 key.
- CLI OAuth device flow.
- DPoP-bound opaque storage sessions and replay detection.
- Private spaces with owner, writer, and reader roles.
- Revisioned JSON records with compare-and-swap support.
- Append-only streams with per-stream sequence numbers.
- A durable global change cursor for each space.
- Fetch-based NDJSON subscriptions.
- WebSocket subscriptions through short-lived, one-use, origin-bound tickets plus a post-upgrade DPoP key-possession challenge.
- Versioned goja scripts, manual invocation, stream triggers, execution deadlines, capability limits, and run receipts.
- Static site releases stored in SQLite and served from per-site origins.
- A dependency-free browser SDK and administration console.
- `dropctl` for login, records, streams, scripts, sites, and live tailing.

## Security model in one diagram

```text
Browser static page
    │ OAuth code + PKCE
    ▼
embedded tiny-idp                     CLI
    │ opaque bearer token              │ OAuth device flow
    └───────────────┬───────────────────┘
                    │ bearer token + fresh DPoP proof
                    ▼
          POST io.opendrop.session.createDPoP
                    │
                    ▼
     opaque storage token bound to P-256 JWK thumbprint
                    │
                    ├── records / streams / scripts / sites
                    ├── fetch NDJSON feed
                    └── one-use WebSocket ticket
```

The tiny-idp strict engine in the pinned release does not yet issue sender-constrained DPoP access tokens. Consequently, the initial bearer-to-DPoP exchange is a bridge: storage requests are sender-constrained after exchange, but theft of the original OAuth bearer token before its first exchange is not prevented. Replacing the bridge with end-to-end issuer DPoP is a defined follow-up.

## Requirements

- Go 1.26.5 or newer.
- A C toolchain because `go-sqlite3` uses CGO.
- A modern browser with WebCrypto, IndexedDB, Fetch streams, and ES modules.

## Start locally

```bash
git clone <this repository>
cd opendrop-pod

go mod tidy
make test build

OPENDROP_SEED_PASSWORD='correct horse battery staple' \
  ./bin/opendrop-pod \
  --addr 127.0.0.1:8080 \
  --public-url http://127.0.0.1:8080 \
  --state-dir ./var
```

Open `http://127.0.0.1:8080`, select **Log in**, and use:

```text
login:    alice
password: value of OPENDROP_SEED_PASSWORD
```

State is written to:

```text
var/
├── identity/
│   ├── identity.sqlite
│   ├── resource-client.secret
│   └── token.secret
└── data/
    └── opendrop.sqlite
```

The secret files must remain mode `0600`; startup fails closed if their permissions change.

## CLI

The CLI generates its own P-256 DPoP key, completes a tiny-idp device flow, and stores an opaque storage session plus private JWK in an owner-only credentials file.

```bash
./bin/dropctl login --server http://127.0.0.1:8080
./bin/dropctl whoami

./bin/dropctl space-create --title Greenhouse greenhouse
./bin/dropctl put greenhouse io.opendrop.sensor.profile sensor-7 \
  '{"label":"north bed","unit":"Cel"}'
./bin/dropctl append greenhouse readings \
  '{"sensor":"sensor-7","temperature":21.7,"humidity":0.48}'
./bin/dropctl tail greenhouse
```

Install and run a script:

```bash
./bin/dropctl script-put --trigger readings \
  greenhouse frost-check examples/scripts/frost-check.js

./bin/dropctl script-run greenhouse frost-check \
  '{"temperature":2.4}'

./bin/dropctl script-runs greenhouse
```

The credentials path is `${XDG_CONFIG_HOME:-~/.config}/opendrop/credentials.json`. Override it with `OPENDROP_CREDENTIALS`.

## Browser SDK

The console serves `/opendrop-client.js`. A separate static page can import it as an ES module:

```js
import { OpenDropClient } from "https://pod.example/opendrop-client.js";

const pod = await new OpenDropClient({
  server: "https://pod.example",
  issuer: "https://pod.example/idp",
  clientId: "opendrop-browser",
  resource: "https://pod.example/api",
  redirectUri: `${location.origin}/auth/callback`,
}).initialize();

await pod.beginLogin();
```

On the callback page:

```js
await pod.handleRedirect();
await pod.append("greenhouse", "readings", {
  sensor: "sensor-7",
  temperature: 21.7,
});
```

Fetch-stream subscription:

```js
const controller = new AbortController();

pod.subscribe("greenhouse", 0, change => {
  console.log(change.cursor, change.kind, change.data);
}, { signal: controller.signal });
```

WebSocket subscription:

```js
const socket = await pod.openWebSocket("greenhouse", 0);
socket.onmessage = event => console.log(JSON.parse(event.data));
```

The SDK first obtains a DPoP-authenticated, origin-bound, one-use ticket. The ticket is placed in the WebSocket URL because the browser `WebSocket` constructor cannot attach `Authorization` and `DPoP` request headers. After upgrade, the Pod sends a nonce challenge; the browser signs the HTTP upgrade target with the same non-extractable proof key, and no history or live data is released until that proof validates.

## XRPC-shaped API

All authenticated storage methods require:

```http
Authorization: DPoP <opaque-storage-token>
DPoP: <fresh-ES256-proof-with-ath>
```

| Method | Procedure | Purpose |
|---|---|---|
| POST | `io.opendrop.session.createDPoP` | Exchange a tiny-idp bearer token plus proof for a DPoP storage session |
| GET | `io.opendrop.identity.getSession` | Current subject, scopes, client, and proof-key thumbprint |
| POST | `io.opendrop.repo.createSpace` | Create a private space |
| GET | `io.opendrop.repo.listSpaces` | List accessible spaces |
| GET | `io.opendrop.repo.getRecord` | Read one record |
| GET | `io.opendrop.repo.listRecords` | Page through a collection |
| POST | `io.opendrop.repo.putRecord` | Create/update a record, optionally with `swapRev` |
| POST | `io.opendrop.repo.deleteRecord` | Delete a record, optionally with `swapRev` |
| POST | `io.opendrop.stream.append` | Append one event |
| GET | `io.opendrop.stream.list` | Read a stream range |
| GET | `io.opendrop.sync.subscribe` | Resumable NDJSON change feed |
| POST | `io.opendrop.sync.createWebSocketTicket` | Mint a one-use ticket |
| GET | `io.opendrop.sync.websocket` | Upgrade using that ticket |
| POST | `io.opendrop.script.put` | Install a script version |
| GET | `io.opendrop.script.list` | List scripts |
| POST | `io.opendrop.script.run` | Invoke a script manually |
| GET | `io.opendrop.script.listRuns` | Read execution receipts |
| POST | `io.opendrop.site.put` | Create/update a site manifest |
| POST | `io.opendrop.site.putFile` | Upload a site file |
| GET | `io.opendrop.site.list` | List site releases |

See [docs/PROTOCOL.md](docs/PROTOCOL.md) for request bodies and feed semantics.

## goja scripts

A script is synchronous CommonJS:

```js
module.exports = function (ctx) {
  const latest = ctx.opendrop.getRecord(
    "io.opendrop.sensor.profile",
    "sensor-7"
  );

  const event = ctx.opendrop.append("audit", {
    operation: "profile-read",
    uri: latest.uri,
  }, { script: "example" });

  return { latest, event };
};
```

The invocation object is:

```text
ctx.actor                 authenticated subject or script owner
ctx.space                 fixed space capability
ctx.trigger               manual or stream:<name>
ctx.input                 JSON input
ctx.opendrop.getRecord    read one record in ctx.space
ctx.opendrop.putRecord    write one record in ctx.space
ctx.opendrop.append       append one event in ctx.space
ctx.opendrop.listEvents   read one stream in ctx.space
ctx.opendrop.now          current RFC 3339 timestamp
```

Runtime restrictions in this MVP:

- A fresh go-go-goja runtime per invocation.
- Safe module-selection middleware.
- No storage credentials exposed to JavaScript.
- Space fixed by the invocation; scripts cannot choose another space.
- 500 ms default execution deadline.
- 128 capability calls per invocation.
- 256 KiB source, input, output, and individual capability-payload limits.
- `listEvents` is capped at 100 events per capability call.
- Synchronous functions only.
- No recursive stream-trigger dispatch from script-generated events.

Goja is an isolation aid, not a hostile multi-tenant security boundary. It has no hard heap quota and executes in the storage process. Only space owners/writers with the `opendrop.script` scope should install code. A production hostile-code tier should move each invocation into a separately constrained process, WASI runtime, microVM, or container.

## Static site origins

Do not serve user-authored applications from the same origin as the identity provider or administration console. That would allow one tenant’s JavaScript to inspect another application’s same-origin IndexedDB session.

OpenDrop Pod therefore supports a wildcard site base:

```bash
./bin/opendrop-pod \
  --public-url http://127.0.0.1:8080 \
  --site-base-url http://sites.lvh.me:8080 \
  --redirect-uris http://dashboard.greenhouse.sites.lvh.me:8080/auth/callback
```

A site named `dashboard` in space `greenhouse` is published at:

```text
http://dashboard.greenhouse.sites.lvh.me:8080/
```

Each `<site>.<space>` pair receives a separate browser origin. `lvh.me` resolves wildcard subdomains to loopback and is suitable only for local development. Production requires wildcard DNS, HTTPS, and a wildcard or on-demand certificate strategy.

Deploy the example:

```bash
./bin/dropctl site-config --public greenhouse dashboard
./bin/dropctl site-put --path index.html greenhouse dashboard examples/site/index.html
./bin/dropctl site-put --path auth/callback greenhouse dashboard examples/site/index.html
```

## Realtime guarantees

The `changes` table is authoritative. The in-process hub only reduces latency.

1. A record/event/site/script transaction writes its domain row and its change row atomically.
2. The handler commits the transaction.
3. The handler publishes the committed change to the in-process hub.
4. A subscriber first registers with the hub, then reads durable history after its cursor.
5. Duplicate live messages are skipped by cursor.
6. A slow subscriber is disconnected and receives a reset hint; it reconnects with its last durable cursor.

This yields resumable at-least-once delivery. Consumers must treat `cursor` as the deduplication key.

## Deliberate MVP boundaries

- Development-mode embedded tiny-idp only. Production-mode tiny-idp requires a production audit sink, production-ready rate limiting/address resolution, HTTPS cookies, and the full password-work policy.
- No end-to-end issuer DPoP in the strict tiny-idp path yet.
- No AT Protocol MST/CAR/federation compatibility.
- No blob store beyond site files in SQLite.
- No schema registry or JSON Schema enforcement.
- No retention/compaction for streams and changes.
- No query language; reads are key/range operations and scripts.
- No remote script packages or dependency installation.
- Trigger queue overflow is logged but not durably retried.
- Single-process realtime hub; clustered deployments need a bus or database notification layer.

See [SECURITY.md](SECURITY.md) before exposing the service outside a development environment.

## Production hardening path

1. Extend tiny-idp strict token issuance and refresh rotation with RFC 9449 DPoP binding; remove the bridge.
2. Run the embedded provider in production mode with durable audit, HTTPS, production rate limiting, trusted-proxy handling, and maintenance monitoring.
3. Move script execution to a hard-isolated worker tier with CPU, memory, filesystem, network, and syscall controls.
4. Put site releases in object storage and keep each site on a distinct origin.
5. Add PostgreSQL or a replicated storage engine; publish committed changes through NATS JetStream or a transactional outbox worker.
6. Add JSON Schema/Lexicon validation, per-space retention, quotas, and encrypted backups.
7. Add repository exports, signed snapshots, DIDs, and optional AT Protocol publication records.

## Repository layout

```text
cmd/opendrop-pod       server entry point
cmd/dropctl            device-login CLI
internal/identity      tiny-idp embedding and client bootstrap
internal/oauth         strict RFC 7662 resource introspection
internal/dpop          ES256 proofs, thumbprints, replay checks, signer
internal/store         SQLite domain and security state
internal/realtime      low-latency in-process change hub
internal/script        go-go-goja runner and trigger dispatcher
internal/server        XRPC, feeds, WebSocket tickets, site host routing
internal/client        CLI OAuth/DPoP client
internal/webassets     browser console and browser SDK
examples               script and static-site examples
```

## Validation and release status

This source tree has been formatted, its browser JavaScript has passed syntax checks, pure DPoP/origin/realtime tests have passed, the SQLite schema has passed a smoke execution, and all Go packages have compiled against API-shaped dependency stubs. The current container could not resolve the real Go module graph, so a dependency-resolved `go test ./...` and browser end-to-end run remain required. See [BUILD-REPORT.md](BUILD-REPORT.md) for the exact boundary.

## License

Apache License 2.0. See [LICENSE](LICENSE).
