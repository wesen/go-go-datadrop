package identity

import (
	"context"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/go-go-golems/opendrop-pod/internal/oauth"
	"github.com/go-go-golems/opendrop-pod/internal/weborigin"
	"github.com/go-go-golems/tiny-idp/pkg/embeddedidp"
	"github.com/go-go-golems/tiny-idp/pkg/idpaccounts"
	"github.com/go-go-golems/tiny-idp/pkg/idpstore"
	"github.com/go-go-golems/tiny-idp/pkg/idpui"
	"github.com/go-go-golems/tiny-idp/pkg/sqlitestore"
	"golang.org/x/crypto/bcrypt"
)

const (
	BrowserClientID  = "opendrop-browser"
	DeviceClientID   = "opendrop-cli"
	ResourceClientID = "opendrop-resource"
)

var DefaultScopes = []string{
	"openid", "profile", "email",
	"opendrop.read", "opendrop.write", "opendrop.script", "opendrop.site",
}

type Config struct {
	StateRoot    string
	PublicURL    string
	RedirectURIs []string
	SeedLogin    string
	SeedPassword string
	SeedEmail    string
}

type Identity struct {
	Issuer       string
	Audience     string
	Provider     *embeddedidp.Provider
	Store        *sqlitestore.Store
	Introspector *oauth.Introspector
}

func New(ctx context.Context, cfg Config) (_ *Identity, retErr error) {
	if ctx == nil {
		return nil, errors.New("identity context is required")
	}
	if strings.TrimSpace(cfg.StateRoot) == "" || strings.TrimSpace(cfg.SeedLogin) == "" || cfg.SeedPassword == "" {
		return nil, errors.New("public URL, state root, seed login, and seed password are required")
	}
	publicURL, err := weborigin.Canonical(cfg.PublicURL)
	if err != nil {
		return nil, fmt.Errorf("public URL: %w", err)
	}
	cfg.PublicURL = publicURL
	if len(cfg.RedirectURIs) == 0 {
		cfg.RedirectURIs = []string{cfg.PublicURL + "/auth/callback"}
	}
	if cfg.SeedEmail == "" {
		cfg.SeedEmail = cfg.SeedLogin + "@example.test"
	}
	identityRoot := filepath.Join(cfg.StateRoot, "identity")
	if err := os.MkdirAll(identityRoot, 0o700); err != nil {
		return nil, fmt.Errorf("create identity root: %w", err)
	}
	store, err := sqlitestore.Open(ctx, sqlitestore.DefaultConfig(filepath.Join(identityRoot, "identity.sqlite")))
	if err != nil {
		return nil, fmt.Errorf("open tiny-idp store: %w", err)
	}
	owned := false
	defer func() {
		if retErr != nil && !owned {
			_ = store.Close()
		}
	}()
	accounts, err := idpaccounts.NewService(store, idpaccounts.Options{})
	if err != nil {
		return nil, fmt.Errorf("create account service: %w", err)
	}
	if err := seedUser(ctx, store, accounts, cfg); err != nil {
		return nil, err
	}
	issuer := cfg.PublicURL + "/idp"
	audience := cfg.PublicURL + "/api"
	resourceSecretBytes, err := loadOrCreateSecret(filepath.Join(identityRoot, "resource-client.secret"), 32)
	if err != nil {
		return nil, err
	}
	resourceSecret := base64.RawURLEncoding.EncodeToString(resourceSecretBytes)
	zero(resourceSecretBytes)
	if err := ensureResourceClient(ctx, store, resourceSecret, audience); err != nil {
		return nil, err
	}
	browser := embeddedidp.BrowserClient(BrowserClientID, cfg.RedirectURIs, []string{cfg.PublicURL + "/"}, DefaultScopes)
	browser.Client.AllowedAudiences = []string{audience}
	device := embeddedidp.DeviceClient(DeviceClientID, DefaultScopes)
	device.Client.AllowedAudiences = []string{audience}
	if _, err := embeddedidp.Bootstrap(ctx, store, embeddedidp.BootstrapConfig{
		Mode:         embeddedidp.DevMode,
		Clients:      []embeddedidp.ClientSpec{browser, device},
		SigningKeyID: "opendrop-development-key",
	}); err != nil {
		return nil, fmt.Errorf("bootstrap tiny-idp: %w", err)
	}
	tokenSecret, err := loadOrCreateSecret(filepath.Join(identityRoot, "token.secret"), 32)
	if err != nil {
		return nil, err
	}
	renderer, err := idpui.NewDefaultRenderer()
	if err != nil {
		zero(tokenSecret)
		return nil, err
	}
	provider, err := embeddedidp.New(ctx, embeddedidp.Options{
		Issuer: issuer,
		Mode:   embeddedidp.DevMode,
		Store:  store,
		Cookie: embeddedidp.CookieConfig{
			Secure:      strings.HasPrefix(cfg.PublicURL, "https://"),
			SameSite:    http.SameSiteLaxMode,
			SessionName: "opendrop_idp_session",
			CSRFName:    "opendrop_idp_csrf",
			Path:        "/idp",
		},
		Token:         embeddedidp.TokenConfig{SecretKey: tokenSecret},
		Authenticator: accounts,
		UI: embeddedidp.UIConfig{
			Renderer:                   renderer,
			DeviceVerificationRenderer: renderer,
		},
	})
	zero(tokenSecret)
	if err != nil {
		return nil, fmt.Errorf("create embedded tiny-idp: %w", err)
	}
	transport, err := embeddedidp.NewInProcessIssuerTransport(issuer, provider.Handler(), embeddedidp.InProcessTransportOptions{})
	if err != nil {
		_ = provider.Close(context.Background())
		return nil, fmt.Errorf("create in-process issuer transport: %w", err)
	}
	introspector, err := oauth.New(ctx, oauth.Config{
		Issuer: issuer, ClientID: ResourceClientID, ClientSecret: resourceSecret, Audience: audience,
		HTTPClient: &http.Client{Transport: transport, Timeout: 10 * time.Second},
	})
	if err != nil {
		_ = provider.Close(context.Background())
		return nil, err
	}
	identity := &Identity{Issuer: issuer, Audience: audience, Provider: provider, Store: store, Introspector: introspector}
	owned = true
	return identity, nil
}

func (i *Identity) Close(ctx context.Context) error {
	if i == nil {
		return nil
	}
	var first error
	if i.Provider != nil {
		if err := i.Provider.Close(ctx); err != nil {
			first = err
		}
	}
	if i.Store != nil {
		if err := i.Store.Close(); err != nil && first == nil {
			first = err
		}
	}
	return first
}

func seedUser(ctx context.Context, store idpstore.Store, accounts *idpaccounts.Service, cfg Config) error {
	request := idpaccounts.CreateRequest{
		ID: "local-" + cfg.SeedLogin, Subject: "local-" + cfg.SeedLogin,
		Login: cfg.SeedLogin, Password: []byte(cfg.SeedPassword), Email: cfg.SeedEmail,
		EmailVerified: true, Name: cfg.SeedLogin, PreferredUsername: cfg.SeedLogin,
	}
	if _, err := accounts.Create(ctx, request); err == nil {
		return nil
	} else if !errors.Is(err, idpstore.ErrDuplicate) {
		return fmt.Errorf("seed development user: %w", err)
	}
	existing, err := store.GetUserByLogin(ctx, cfg.SeedLogin)
	if err != nil {
		return fmt.Errorf("load existing development user: %w", err)
	}
	if existing.Sub != request.Subject || existing.Email != request.Email {
		return errors.New("existing seed user conflicts with configured identity")
	}
	return nil
}

func ensureResourceClient(ctx context.Context, store idpstore.Store, secret, audience string) error {
	desired := idpstore.Client{
		ID: ResourceClientID, Public: false,
		AllowedGrantTypes: []string{idpstore.GrantAuthorizationCode},
		AllowedAudiences:  []string{audience}, CanIntrospect: true,
		AccessTokenTTL: time.Hour, IDTokenTTL: time.Hour, RefreshTokenTTL: 24 * time.Hour,
	}
	existing, err := store.GetClient(ctx, ResourceClientID)
	if errors.Is(err, idpstore.ErrNotFound) {
		desired.SecretHash, err = bcrypt.GenerateFromPassword([]byte(secret), bcrypt.DefaultCost)
		if err != nil {
			return err
		}
		now := time.Now().UTC()
		desired.CreatedAt, desired.UpdatedAt = now, now
		if err := desired.Validate(idpstore.DevMode); err != nil {
			return fmt.Errorf("validate resource client: %w", err)
		}
		if err := store.PutClient(ctx, desired); err != nil {
			return fmt.Errorf("create resource client: %w", err)
		}
		return nil
	}
	if err != nil {
		return err
	}
	if existing.Public || !existing.CanIntrospect || existing.Disabled || len(existing.AllowedAudiences) != 1 || existing.AllowedAudiences[0] != audience {
		return errors.New("existing resource client conflicts with OpenDrop configuration")
	}
	if bcrypt.CompareHashAndPassword(existing.SecretHash, []byte(secret)) != nil {
		return errors.New("resource client secret conflicts with persisted state")
	}
	return nil
}

func loadOrCreateSecret(path string, size int) ([]byte, error) {
	if value, err := os.ReadFile(path); err == nil {
		if len(value) != size {
			return nil, fmt.Errorf("secret %s has %d bytes, want %d", path, len(value), size)
		}
		info, statErr := os.Stat(path)
		if statErr != nil {
			return nil, statErr
		}
		if info.Mode().Perm() != 0o600 {
			return nil, fmt.Errorf("secret %s permissions are %#o, want 0600", path, info.Mode().Perm())
		}
		return value, nil
	} else if !os.IsNotExist(err) {
		return nil, err
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return nil, err
	}
	value := make([]byte, size)
	if _, err := rand.Read(value); err != nil {
		return nil, err
	}
	file, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
	if os.IsExist(err) {
		return loadOrCreateSecret(path, size)
	}
	if err != nil {
		return nil, err
	}
	if _, err := file.Write(value); err != nil {
		_ = file.Close()
		_ = os.Remove(path)
		return nil, err
	}
	if err := file.Sync(); err != nil {
		_ = file.Close()
		_ = os.Remove(path)
		return nil, err
	}
	if err := file.Close(); err != nil {
		return nil, err
	}
	return value, nil
}

func zero(value []byte) {
	for index := range value {
		value[index] = 0
	}
}
