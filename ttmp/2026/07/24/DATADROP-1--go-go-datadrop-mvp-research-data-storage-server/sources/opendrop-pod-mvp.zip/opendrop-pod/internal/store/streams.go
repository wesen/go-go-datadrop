package store

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
)

func (s *Store) AppendEvent(ctx context.Context, actor, space, stream string, data, meta json.RawMessage) (Event, Change, error) {
	compactedData, err := compactJSON(data)
	if err != nil {
		return Event{}, Change{}, err
	}
	var compactedMeta json.RawMessage
	if len(meta) != 0 && string(meta) != "null" {
		compactedMeta, err = compactJSON(meta)
		if err != nil {
			return Event{}, Change{}, err
		}
	}
	now := s.now().UTC()
	eventID, err := randomOpaque(18)
	if err != nil {
		return Event{}, Change{}, err
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return Event{}, Change{}, err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, `INSERT INTO stream_heads(space_name,stream,sequence) VALUES(?,?,0) ON CONFLICT(space_name,stream) DO NOTHING`, space, stream); err != nil {
		return Event{}, Change{}, err
	}
	var sequence int64
	if err := tx.QueryRowContext(ctx, `SELECT sequence FROM stream_heads WHERE space_name=? AND stream=?`, space, stream).Scan(&sequence); err != nil {
		return Event{}, Change{}, err
	}
	sequence++
	if _, err := tx.ExecContext(ctx, `UPDATE stream_heads SET sequence=? WHERE space_name=? AND stream=?`, sequence, space, stream); err != nil {
		return Event{}, Change{}, err
	}
	event := Event{ID: eventID, Space: space, Stream: stream, Sequence: sequence, Subject: actor, Time: now, Data: compactedData, Meta: compactedMeta, CreatedAt: now}
	if _, err := tx.ExecContext(ctx, `INSERT INTO stream_events(space_name,stream,sequence,event_id,subject,event_time,data_json,meta_json,created_at) VALUES(?,?,?,?,?,?,?,?,?)`,
		space, stream, sequence, eventID, actor, utcText(now), compactedData, nullableBytes(compactedMeta), utcText(now)); err != nil {
		return Event{}, Change{}, err
	}
	change, err := insertJSONChange(ctx, tx, Change{Type: "change", Space: space, Kind: "stream.append", Stream: stream, Sequence: sequence, Actor: actor, CreatedAt: now}, event)
	if err != nil {
		return Event{}, Change{}, err
	}
	if err := tx.Commit(); err != nil {
		return Event{}, Change{}, err
	}
	return event, change, nil
}

func (s *Store) ListEvents(ctx context.Context, space, stream string, after int64, limit int) ([]Event, error) {
	if limit <= 0 || limit > 1000 {
		limit = 100
	}
	rows, err := s.db.QueryContext(ctx, `SELECT sequence,event_id,subject,event_time,data_json,meta_json,created_at FROM stream_events WHERE space_name=? AND stream=? AND sequence>? ORDER BY sequence LIMIT ?`, space, stream, after, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]Event, 0, limit)
	for rows.Next() {
		var item Event
		var eventTime, created string
		var meta []byte
		if err := rows.Scan(&item.Sequence, &item.ID, &item.Subject, &eventTime, &item.Data, &meta, &created); err != nil {
			return nil, err
		}
		item.Space, item.Stream = space, stream
		item.Meta = meta
		item.Time, err = parseTime(eventTime)
		if err != nil {
			return nil, err
		}
		item.CreatedAt, err = parseTime(created)
		if err != nil {
			return nil, err
		}
		items = append(items, item)
	}
	return items, rows.Err()
}

func (s *Store) ListChanges(ctx context.Context, space string, after int64, limit int) ([]Change, error) {
	if limit <= 0 || limit > 2000 {
		limit = 500
	}
	rows, err := s.db.QueryContext(ctx, `SELECT cursor,kind,collection,rkey,stream,sequence,actor_sub,data_json,created_at FROM changes WHERE space_name=? AND cursor>? ORDER BY cursor LIMIT ?`, space, after, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]Change, 0, limit)
	for rows.Next() {
		var item Change
		var collection, rkey, stream sql.NullString
		var sequence sql.NullInt64
		var data []byte
		var created string
		if err := rows.Scan(&item.Cursor, &item.Kind, &collection, &rkey, &stream, &sequence, &item.Actor, &data, &created); err != nil {
			return nil, err
		}
		item.Type, item.Space = "change", space
		item.Collection, item.RKey, item.Stream = collection.String, rkey.String, stream.String
		item.Sequence = sequence.Int64
		item.Data = data
		item.CreatedAt, err = parseTime(created)
		if err != nil {
			return nil, err
		}
		items = append(items, item)
	}
	return items, rows.Err()
}

func insertJSONChange(ctx context.Context, tx *sql.Tx, change Change, value any) (Change, error) {
	data, err := json.Marshal(value)
	if err != nil {
		return Change{}, fmt.Errorf("encode change data: %w", err)
	}
	change.Data = data
	return insertChange(ctx, tx, change)
}

func insertChange(ctx context.Context, tx *sql.Tx, change Change) (Change, error) {
	result, err := tx.ExecContext(ctx, `INSERT INTO changes(space_name,kind,collection,rkey,stream,sequence,actor_sub,data_json,created_at) VALUES(?,?,?,?,?,?,?,?,?)`,
		change.Space, change.Kind, nullableString(change.Collection), nullableString(change.RKey), nullableString(change.Stream), nullableInt64(change.Sequence), change.Actor, nullableBytes(change.Data), utcText(change.CreatedAt))
	if err != nil {
		return Change{}, err
	}
	change.Cursor, err = result.LastInsertId()
	if err != nil {
		return Change{}, err
	}
	change.Type = "change"
	return change, nil
}

func nullableString(value string) any {
	if value == "" {
		return nil
	}
	return value
}

func nullableInt64(value int64) any {
	if value == 0 {
		return nil
	}
	return value
}

func nullableBytes(value []byte) any {
	if len(value) == 0 {
		return nil
	}
	return value
}
