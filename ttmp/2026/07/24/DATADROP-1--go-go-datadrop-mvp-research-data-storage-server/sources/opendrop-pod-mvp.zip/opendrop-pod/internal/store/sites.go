package store

import (
	"context"
	"database/sql"
	"errors"
)

func (s *Store) PutSite(ctx context.Context, actor, space, name string, public bool, entrypoint string) (Site, Change, error) {
	now := s.now().UTC()
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return Site{}, Change{}, err
	}
	defer tx.Rollback()
	var created string
	err = tx.QueryRowContext(ctx, `SELECT created_at FROM sites WHERE space_name=? AND name=?`, space, name).Scan(&created)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return Site{}, Change{}, err
	}
	exists := err == nil
	item := Site{Space: space, Name: name, Public: public, Entrypoint: entrypoint, UpdatedAt: now}
	if exists {
		item.CreatedAt, err = parseTime(created)
		if err != nil {
			return Site{}, Change{}, err
		}
		_, err = tx.ExecContext(ctx, `UPDATE sites SET public=?,entrypoint=?,updated_at=? WHERE space_name=? AND name=?`, boolInt(public), entrypoint, utcText(now), space, name)
	} else {
		item.CreatedAt = now
		_, err = tx.ExecContext(ctx, `INSERT INTO sites(space_name,name,public,entrypoint,created_at,updated_at) VALUES(?,?,?,?,?,?)`, space, name, boolInt(public), entrypoint, utcText(now), utcText(now))
	}
	if err != nil {
		return Site{}, Change{}, err
	}
	change, err := insertJSONChange(ctx, tx, Change{Type: "change", Space: space, Kind: "site.put", Actor: actor, CreatedAt: now}, item)
	if err != nil {
		return Site{}, Change{}, err
	}
	if err := tx.Commit(); err != nil {
		return Site{}, Change{}, err
	}
	return item, change, nil
}

func (s *Store) GetSite(ctx context.Context, space, name string) (Site, error) {
	var item Site
	var public int
	var created, updated string
	err := s.db.QueryRowContext(ctx, `SELECT public,entrypoint,created_at,updated_at FROM sites WHERE space_name=? AND name=?`, space, name).
		Scan(&public, &item.Entrypoint, &created, &updated)
	if errors.Is(err, sql.ErrNoRows) {
		return Site{}, ErrNotFound
	}
	if err != nil {
		return Site{}, err
	}
	item.Space, item.Name, item.Public = space, name, public != 0
	item.CreatedAt, err = parseTime(created)
	if err != nil {
		return Site{}, err
	}
	item.UpdatedAt, err = parseTime(updated)
	return item, err
}

func (s *Store) ListSites(ctx context.Context, space string) ([]Site, error) {
	rows, err := s.db.QueryContext(ctx, `SELECT name,public,entrypoint,created_at,updated_at FROM sites WHERE space_name=? ORDER BY name`, space)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]Site, 0)
	for rows.Next() {
		var item Site
		var public int
		var created, updated string
		if err := rows.Scan(&item.Name, &public, &item.Entrypoint, &created, &updated); err != nil {
			return nil, err
		}
		item.Space, item.Public = space, public != 0
		item.CreatedAt, err = parseTime(created)
		if err != nil {
			return nil, err
		}
		item.UpdatedAt, err = parseTime(updated)
		if err != nil {
			return nil, err
		}
		items = append(items, item)
	}
	return items, rows.Err()
}

func (s *Store) PutSiteFile(ctx context.Context, actor, space, siteName, path, contentType string, body []byte) (SiteFile, Change, error) {
	now := s.now().UTC()
	item := SiteFile{Space: space, Site: siteName, Path: path, ContentType: contentType, Body: append([]byte(nil), body...), Digest: digestJSON(body), UpdatedAt: now}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return SiteFile{}, Change{}, err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, `INSERT INTO site_files(space_name,site_name,path,content_type,body,digest,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(space_name,site_name,path) DO UPDATE SET content_type=excluded.content_type,body=excluded.body,digest=excluded.digest,updated_at=excluded.updated_at`,
		space, siteName, path, contentType, body, item.Digest, utcText(now)); err != nil {
		if isSQLiteConstraint(err) {
			return SiteFile{}, Change{}, ErrNotFound
		}
		return SiteFile{}, Change{}, err
	}
	change, err := insertJSONChange(ctx, tx, Change{Type: "change", Space: space, Kind: "site.file.put", Actor: actor, CreatedAt: now}, map[string]any{"site": siteName, "path": path, "contentType": contentType, "digest": item.Digest})
	if err != nil {
		return SiteFile{}, Change{}, err
	}
	if err := tx.Commit(); err != nil {
		return SiteFile{}, Change{}, err
	}
	return item, change, nil
}

func (s *Store) GetSiteFile(ctx context.Context, space, siteName, path string) (SiteFile, error) {
	var item SiteFile
	var updated string
	err := s.db.QueryRowContext(ctx, `SELECT content_type,body,digest,updated_at FROM site_files WHERE space_name=? AND site_name=? AND path=?`, space, siteName, path).
		Scan(&item.ContentType, &item.Body, &item.Digest, &updated)
	if errors.Is(err, sql.ErrNoRows) {
		return SiteFile{}, ErrNotFound
	}
	if err != nil {
		return SiteFile{}, err
	}
	item.Space, item.Site, item.Path = space, siteName, path
	item.UpdatedAt, err = parseTime(updated)
	return item, err
}
