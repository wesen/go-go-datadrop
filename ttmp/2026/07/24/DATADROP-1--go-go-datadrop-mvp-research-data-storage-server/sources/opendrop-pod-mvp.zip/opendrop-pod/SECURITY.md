# Security policy and deployment boundary

OpenDrop Pod is an implementation MVP. Its defaults are intended for local development and controlled evaluation, not direct Internet exposure.

## Security properties implemented

- OAuth login is provided by embedded tiny-idp.
- Browser authorization uses code flow with PKCE.
- CLI authorization uses the device grant.
- Storage tokens are opaque, stored only as SHA-256 hashes, short-lived, and bound to an ES256 P-256 JWK thumbprint.
- Every protected storage call requires a fresh DPoP proof with method, URI, issue time, unique identifier, and access-token hash binding.
- DPoP replay identifiers are committed through a unique SQLite constraint.
- WebSocket tickets are opaque, hashed at rest, one-use, short-lived, origin-bound, and proof-key-bound.
- A WebSocket releases no data until a post-upgrade nonce proof demonstrates possession of the bound DPoP key.
- Identity and token secrets are generated from cryptographic randomness and startup rejects permissive secret-file modes.
- User-authored sites are served from separate per-site origins rather than the identity or administration origin.
- goja scripts receive fixed space-scoped capabilities rather than OAuth tokens, storage tokens, database handles, filesystem handles, or network clients.
- Script source, input, output, capability calls, payloads, list sizes, and wall-clock execution are bounded.
- Record/event mutations and their durable change cursors commit in one SQLite transaction.

## Known limitations

### Development identity mode

The embedded tiny-idp is configured in development mode. Production operation requires the provider's production mode, a durable audit sink, production password policy, HTTPS cookies, rate limiting, trusted-proxy policy, maintenance monitoring, and operational key rotation.

### Bearer-to-DPoP bootstrap gap

The tiny-idp access token used for `io.opendrop.session.createDPoP` is a bearer token. The exchange request includes an `ath`-bound proof, but theft of the bearer token before or during its first legitimate exchange is not prevented by issuer-side sender constraining. Storage calls after exchange are DPoP-bound. Replace this bridge when tiny-idp provides end-to-end DPoP token issuance and refresh binding.

### In-process JavaScript

Goja interruption bounds execution time, but the runtime has no hard memory quota. A malicious script may consume process memory before interruption. `MiddlewareSafe` removes filesystem, operating-system, process-execution, and database modules, but JavaScript still executes in the storage process. Do not grant script installation to untrusted tenants. A production hostile-code tier should use a separate constrained process, WASI runtime, container, or microVM.

### Browser code and XSS

DPoP does not protect a browser after malicious JavaScript executes in the approved origin. Such code can direct the non-extractable key to sign requests. Keep site releases immutable, pin dependencies, use a strict Content Security Policy, avoid `eval`, and isolate third-party plugins in workers or sandboxed frames behind a capability broker.

### WebSocket ticket URLs

The ticket is present in the WebSocket URL. It is one-use and short-lived, but reverse proxies and access logs must redact query strings on the WebSocket endpoint. TLS is mandatory outside loopback development.

### Single-node architecture

SQLite and the in-process realtime hub assume one process. Multi-process deployment without a transactional outbox worker or external bus can miss low-latency notifications, although durable cursors remain in SQLite. There is no quota, retention, compaction, backup scheduler, or tenant-level resource accounting in this MVP.

## Deployment requirements

Before exposing the service:

1. Set a strong `OPENDROP_SEED_PASSWORD`; never use `opendrop-dev`.
2. Terminate HTTPS at the process or a correctly configured trusted reverse proxy.
3. Set `--public-url` to the exact browser-visible HTTPS origin.
4. Use a dedicated wildcard domain for `--site-base-url`; do not share it with unrelated hosting.
5. Register each site callback with `--redirect-uris`.
6. Restrict `--allowed-origins` to exact origins.
7. Ensure the state directory and credential files are readable only by the service account.
8. Redact `Authorization`, `DPoP`, OAuth codes, refresh tokens, and WebSocket query strings from logs.
9. Put request-rate and connection limits in front of the service.
10. Back up both identity and data SQLite databases consistently, including WAL state.
11. Run the release gate in `BUILD-REPORT.md`.

## Reporting vulnerabilities

Do not include credentials, tokens, private records, or exploit payloads containing user data in a public issue. Publish a private security contact before operating a public instance. Until a project contact is established, treat this repository as evaluation source rather than a supported public service.
