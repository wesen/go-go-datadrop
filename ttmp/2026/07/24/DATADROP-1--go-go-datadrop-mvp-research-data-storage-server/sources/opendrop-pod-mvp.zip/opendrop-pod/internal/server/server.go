package server

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"log/slog"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/go-go-golems/opendrop-pod/internal/identity"
	"github.com/go-go-golems/opendrop-pod/internal/oauth"
	"github.com/go-go-golems/opendrop-pod/internal/realtime"
	"github.com/go-go-golems/opendrop-pod/internal/script"
	"github.com/go-go-golems/opendrop-pod/internal/store"
	"github.com/go-go-golems/opendrop-pod/internal/webassets"
	"github.com/go-go-golems/opendrop-pod/internal/weborigin"
)

type Config struct {
	PublicURL       string
	SiteBaseURL     string
	AllowedOrigins  []string
	SessionTTL      time.Duration
	WSTicketTTL     time.Duration
	MaxRequestBytes int64
	Logger          *slog.Logger
}

type Server struct {
	cfg          Config
	mux          *http.ServeMux
	identity     *identity.Identity
	introspector *oauth.Introspector
	store        *store.Store
	hub          *realtime.Hub
	runner       *script.Runner
	dispatcher   *script.Dispatcher
	logger       *slog.Logger
	origins      map[string]struct{}
	publicURL    *url.URL
	siteBaseURL  *url.URL
	static       http.Handler
}

func New(cfg Config, id *identity.Identity, dataStore *store.Store, hub *realtime.Hub, runner *script.Runner, dispatcher *script.Dispatcher) (*Server, error) {
	if id == nil || id.Provider == nil || id.Introspector == nil || dataStore == nil || hub == nil || runner == nil {
		return nil, errors.New("identity, store, realtime hub, and script runner are required")
	}
	publicURL, err := weborigin.Parse(cfg.PublicURL)
	if err != nil {
		return nil, fmt.Errorf("public URL: %w", err)
	}
	cfg.PublicURL = publicURL.String()
	if cfg.SessionTTL <= 0 {
		cfg.SessionTTL = time.Hour
	}
	if cfg.WSTicketTTL <= 0 {
		cfg.WSTicketTTL = 30 * time.Second
	}
	if cfg.MaxRequestBytes <= 0 {
		cfg.MaxRequestBytes = 2 << 20
	}
	if cfg.Logger == nil {
		cfg.Logger = slog.Default()
	}
	server := &Server{
		cfg: cfg, mux: http.NewServeMux(), identity: id, introspector: id.Introspector,
		store: dataStore, hub: hub, runner: runner, dispatcher: dispatcher,
		logger: cfg.Logger, origins: make(map[string]struct{}), publicURL: publicURL,
	}
	server.origins[publicURL.Scheme+"://"+publicURL.Host] = struct{}{}
	for _, raw := range cfg.AllowedOrigins {
		origin, err := canonicalOrigin(raw)
		if err != nil {
			return nil, fmt.Errorf("allowed origin %q: %w", raw, err)
		}
		server.origins[origin] = struct{}{}
	}
	if strings.TrimSpace(cfg.SiteBaseURL) != "" {
		server.siteBaseURL, err = weborigin.Parse(cfg.SiteBaseURL)
		if err != nil {
			return nil, fmt.Errorf("site base URL: %w", err)
		}
		if net.ParseIP(server.siteBaseURL.Hostname()) != nil {
			return nil, errors.New("site base URL must use a DNS hostname for per-site subdomains")
		}
		cfg.SiteBaseURL = server.siteBaseURL.String()
		server.cfg.SiteBaseURL = cfg.SiteBaseURL
	}
	assetFS, err := fs.Sub(webassets.FS, "web")
	if err != nil {
		return nil, err
	}
	server.static = http.FileServer(http.FS(assetFS))
	server.routes()
	return server, nil
}

func (s *Server) routes() {
	s.mux.Handle("/idp/", s.identity.Provider.Handler())
	s.mux.HandleFunc("GET /idp", func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, "/idp/", http.StatusTemporaryRedirect)
	})

	s.mux.HandleFunc("GET /healthz", s.handleHealth)
	s.mux.HandleFunc("GET /readyz", s.handleReady)
	s.mux.HandleFunc("GET /config.js", s.handleBrowserConfig)

	s.mux.HandleFunc("POST /xrpc/io.opendrop.session.createDPoP", s.handleCreateDPoPSession)
	s.mux.Handle("GET /xrpc/io.opendrop.identity.getSession", s.requireDPoP([]string{"opendrop.read"}, http.HandlerFunc(s.handleGetSession)))

	s.mux.Handle("POST /xrpc/io.opendrop.repo.createSpace", s.requireDPoP([]string{"opendrop.write"}, http.HandlerFunc(s.handleCreateSpace)))
	s.mux.Handle("GET /xrpc/io.opendrop.repo.listSpaces", s.requireDPoP([]string{"opendrop.read"}, http.HandlerFunc(s.handleListSpaces)))
	s.mux.Handle("GET /xrpc/io.opendrop.repo.getRecord", s.requireDPoP([]string{"opendrop.read"}, http.HandlerFunc(s.handleGetRecord)))
	s.mux.Handle("GET /xrpc/io.opendrop.repo.listRecords", s.requireDPoP([]string{"opendrop.read"}, http.HandlerFunc(s.handleListRecords)))
	s.mux.Handle("POST /xrpc/io.opendrop.repo.putRecord", s.requireDPoP([]string{"opendrop.write"}, http.HandlerFunc(s.handlePutRecord)))
	s.mux.Handle("POST /xrpc/io.opendrop.repo.deleteRecord", s.requireDPoP([]string{"opendrop.write"}, http.HandlerFunc(s.handleDeleteRecord)))

	s.mux.Handle("POST /xrpc/io.opendrop.stream.append", s.requireDPoP([]string{"opendrop.write"}, http.HandlerFunc(s.handleAppendEvent)))
	s.mux.Handle("GET /xrpc/io.opendrop.stream.list", s.requireDPoP([]string{"opendrop.read"}, http.HandlerFunc(s.handleListEvents)))
	s.mux.Handle("GET /xrpc/io.opendrop.sync.subscribe", s.requireDPoP([]string{"opendrop.read"}, http.HandlerFunc(s.handleSubscribe)))
	s.mux.Handle("POST /xrpc/io.opendrop.sync.createWebSocketTicket", s.requireDPoP([]string{"opendrop.read"}, http.HandlerFunc(s.handleCreateWSTicket)))
	s.mux.HandleFunc("GET /xrpc/io.opendrop.sync.websocket", s.handleWebSocket)

	s.mux.Handle("POST /xrpc/io.opendrop.script.put", s.requireDPoP([]string{"opendrop.script"}, http.HandlerFunc(s.handlePutScript)))
	s.mux.Handle("GET /xrpc/io.opendrop.script.list", s.requireDPoP([]string{"opendrop.script"}, http.HandlerFunc(s.handleListScripts)))
	s.mux.Handle("POST /xrpc/io.opendrop.script.run", s.requireDPoP([]string{"opendrop.script"}, http.HandlerFunc(s.handleRunScript)))
	s.mux.Handle("GET /xrpc/io.opendrop.script.listRuns", s.requireDPoP([]string{"opendrop.script"}, http.HandlerFunc(s.handleListScriptRuns)))

	s.mux.Handle("POST /xrpc/io.opendrop.site.put", s.requireDPoP([]string{"opendrop.site"}, http.HandlerFunc(s.handlePutSite)))
	s.mux.Handle("POST /xrpc/io.opendrop.site.putFile", s.requireDPoP([]string{"opendrop.site"}, http.HandlerFunc(s.handlePutSiteFile)))
	s.mux.Handle("GET /xrpc/io.opendrop.site.list", s.requireDPoP([]string{"opendrop.site"}, http.HandlerFunc(s.handleListSites)))

	s.mux.HandleFunc("GET /auth/callback", s.handleStatic)
	s.mux.HandleFunc("GET /", s.handleStatic)
}

func (s *Server) Handler() http.Handler {
	return s.cors(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if s.siteBaseURL != nil && s.isSiteHost(r.Host) {
			s.handlePublishedSite(w, r)
			return
		}
		s.mux.ServeHTTP(w, r)
	}))
}

func (s *Server) handleStatic(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path == "/auth/callback" {
		r.URL.Path = "/"
	}
	s.static.ServeHTTP(w, r)
}

func (s *Server) handleHealth(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (s *Server) handleReady(w http.ResponseWriter, r *http.Request) {
	if err := s.store.Ping(r.Context()); err != nil {
		writeError(w, http.StatusServiceUnavailable, "StoreUnavailable", "storage is unavailable")
		return
	}
	report := s.identity.Provider.Readiness(r.Context())
	if !report.Ready {
		writeJSON(w, http.StatusServiceUnavailable, report)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "identity": report})
}

func (s *Server) handleBrowserConfig(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Content-Type", "application/javascript; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	config := map[string]any{
		"server": s.publicURL.String(), "issuer": s.identity.Issuer,
		"clientId": identity.BrowserClientID, "resource": s.identity.Audience,
		"scopes": identity.DefaultScopes, "siteBaseURL": s.cfg.SiteBaseURL,
	}
	encoded, _ := json.Marshal(config)
	_, _ = fmt.Fprintf(w, "globalThis.OPENDROP_CONFIG = %s;\n", encoded)
}
