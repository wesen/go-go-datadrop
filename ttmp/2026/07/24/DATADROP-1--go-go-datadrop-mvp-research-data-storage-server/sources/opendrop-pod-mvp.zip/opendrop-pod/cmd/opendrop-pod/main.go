package main

import (
	"context"
	"flag"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/go-go-golems/opendrop-pod/internal/app"
)

func main() {
	var (
		addr            = flag.String("addr", "127.0.0.1:8080", "HTTP listen address")
		publicURL       = flag.String("public-url", "http://127.0.0.1:8080", "canonical browser-visible origin")
		siteBaseURL     = flag.String("site-base-url", "", "optional wildcard site base, for example http://sites.lvh.me:8080")
		stateDir        = flag.String("state-dir", "./var", "owner-only persistent state directory")
		redirectURIs    = flag.String("redirect-uris", "", "comma-separated additional browser OAuth redirect URIs")
		allowedOrigins  = flag.String("allowed-origins", "", "comma-separated additional CORS origins")
		seedLogin       = flag.String("seed-login", envOr("OPENDROP_SEED_LOGIN", "alice"), "development login")
		seedPassword    = flag.String("seed-password", envOr("OPENDROP_SEED_PASSWORD", "opendrop-dev"), "development password")
		seedEmail       = flag.String("seed-email", envOr("OPENDROP_SEED_EMAIL", "alice@example.test"), "development email")
		sessionTTL      = flag.Duration("session-ttl", time.Hour, "DPoP storage session lifetime")
		wsTicketTTL     = flag.Duration("ws-ticket-ttl", 30*time.Second, "one-use WebSocket ticket lifetime")
		scriptTimeout   = flag.Duration("script-timeout", 500*time.Millisecond, "per-invocation goja deadline")
		scriptWorkers   = flag.Int("script-workers", 2, "triggered-script worker count")
		maxRequestBytes = flag.Int64("max-request-bytes", 2<<20, "default JSON request limit")
		logJSON         = flag.Bool("log-json", false, "emit JSON logs")
	)
	flag.Parse()

	loggerOptions := &slog.HandlerOptions{Level: slog.LevelInfo}
	var handler slog.Handler
	if *logJSON {
		handler = slog.NewJSONHandler(os.Stderr, loggerOptions)
	} else {
		handler = slog.NewTextHandler(os.Stderr, loggerOptions)
	}
	logger := slog.New(handler)
	slog.SetDefault(logger)
	if *seedPassword == "opendrop-dev" {
		logger.Warn("using the default development password; set OPENDROP_SEED_PASSWORD before exposing this service")
	}

	redirects := splitCSV(*redirectURIs)
	defaultRedirect := strings.TrimRight(*publicURL, "/") + "/auth/callback"
	redirects = append([]string{defaultRedirect}, redirects...)
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()
	application, err := app.New(ctx, app.Config{
		StateDir: *stateDir, PublicURL: *publicURL, SiteBaseURL: *siteBaseURL,
		RedirectURIs: redirects, AllowedOrigins: splitCSV(*allowedOrigins),
		SeedLogin: *seedLogin, SeedPassword: *seedPassword, SeedEmail: *seedEmail,
		SessionTTL: *sessionTTL, WSTicketTTL: *wsTicketTTL,
		ScriptTimeout: *scriptTimeout, ScriptWorkers: *scriptWorkers,
		MaxRequestBytes: *maxRequestBytes, Logger: logger,
	})
	if err != nil {
		logger.Error("initialize OpenDrop Pod", "error", err)
		os.Exit(1)
	}
	defer application.Close(context.Background())

	httpServer := &http.Server{
		Addr: *addr, Handler: application.Handler(),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       15 * time.Second,
		WriteTimeout:      0,
		IdleTimeout:       2 * time.Minute,
		MaxHeaderBytes:    32 << 10,
	}
	errChannel := make(chan error, 1)
	go func() {
		logger.Info("OpenDrop Pod listening", "addr", *addr, "public_url", *publicURL, "site_base_url", *siteBaseURL)
		errChannel <- httpServer.ListenAndServe()
	}()
	select {
	case <-ctx.Done():
	case err := <-errChannel:
		if err != nil && err != http.ErrServerClosed {
			logger.Error("HTTP server failed", "error", err)
		}
		stop()
	}
	shutdownContext, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	if err := httpServer.Shutdown(shutdownContext); err != nil {
		logger.Error("HTTP shutdown failed", "error", err)
	}
	if err := application.Close(shutdownContext); err != nil {
		logger.Error("application shutdown failed", "error", err)
	}
}

func splitCSV(raw string) []string {
	parts := strings.Split(raw, ",")
	output := make([]string, 0, len(parts))
	seen := map[string]struct{}{}
	for _, value := range parts {
		value = strings.TrimSpace(value)
		if value == "" {
			continue
		}
		if _, ok := seen[value]; ok {
			continue
		}
		seen[value] = struct{}{}
		output = append(output, value)
	}
	return output
}

func envOr(name, fallback string) string {
	if value := strings.TrimSpace(os.Getenv(name)); value != "" {
		return value
	}
	return fallback
}
