package realtime

import (
	"sync"

	"github.com/go-go-golems/opendrop-pod/internal/store"
)

// Hub distributes committed changes to in-process subscribers. Persistence and
// resumption come from the changes table; the hub is only a low-latency hint.
type Hub struct {
	mu     sync.Mutex
	nextID uint64
	spaces map[string]map[uint64]chan store.Change
	buffer int
}

func NewHub(buffer int) *Hub {
	if buffer <= 0 {
		buffer = 256
	}
	return &Hub{spaces: make(map[string]map[uint64]chan store.Change), buffer: buffer}
}

// Subscribe returns a channel and an idempotent cancellation function. A slow
// subscriber is disconnected; it resumes from its last durable cursor.
func (h *Hub) Subscribe(space string) (<-chan store.Change, func()) {
	h.mu.Lock()
	h.nextID++
	id := h.nextID
	channel := make(chan store.Change, h.buffer)
	if h.spaces[space] == nil {
		h.spaces[space] = make(map[uint64]chan store.Change)
	}
	h.spaces[space][id] = channel
	h.mu.Unlock()

	var once sync.Once
	cancel := func() {
		once.Do(func() {
			h.mu.Lock()
			if subscribers := h.spaces[space]; subscribers != nil {
				if current, ok := subscribers[id]; ok {
					delete(subscribers, id)
					close(current)
				}
				if len(subscribers) == 0 {
					delete(h.spaces, space)
				}
			}
			h.mu.Unlock()
		})
	}
	return channel, cancel
}

func (h *Hub) Publish(change store.Change) {
	h.mu.Lock()
	defer h.mu.Unlock()
	subscribers := h.spaces[change.Space]
	for id, channel := range subscribers {
		select {
		case channel <- change:
		default:
			delete(subscribers, id)
			close(channel)
		}
	}
	if len(subscribers) == 0 {
		delete(h.spaces, change.Space)
	}
}
