package store

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
)

func (s *Store) PutScript(ctx context.Context, actor, space, name, source string, enabled bool, triggerStream string) (Script, Change, error) {
	now := s.now().UTC()
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return Script{}, Change{}, err
	}
	defer tx.Rollback()
	var currentVersion int64
	var created string
	err = tx.QueryRowContext(ctx, `SELECT version,created_at FROM scripts WHERE space_name=? AND name=?`, space, name).Scan(&currentVersion, &created)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return Script{}, Change{}, err
	}
	exists := err == nil
	item := Script{Space: space, Name: name, Source: source, Enabled: enabled, TriggerStream: triggerStream, Version: currentVersion + 1, Owner: actor, UpdatedAt: now}
	if exists {
		item.CreatedAt, err = parseTime(created)
		if err != nil {
			return Script{}, Change{}, err
		}
		_, err = tx.ExecContext(ctx, `UPDATE scripts SET source=?,enabled=?,trigger_stream=?,version=?,owner_sub=?,updated_at=? WHERE space_name=? AND name=?`, source, boolInt(enabled), nullableString(triggerStream), item.Version, actor, utcText(now), space, name)
	} else {
		item.CreatedAt = now
		_, err = tx.ExecContext(ctx, `INSERT INTO scripts(space_name,name,source,enabled,trigger_stream,version,owner_sub,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)`, space, name, source, boolInt(enabled), nullableString(triggerStream), item.Version, actor, utcText(now), utcText(now))
	}
	if err != nil {
		return Script{}, Change{}, err
	}
	publicItem := item
	publicItem.Source = ""
	change, err := insertJSONChange(ctx, tx, Change{Type: "change", Space: space, Kind: "script.put", Actor: actor, CreatedAt: now}, publicItem)
	if err != nil {
		return Script{}, Change{}, err
	}
	if err := tx.Commit(); err != nil {
		return Script{}, Change{}, err
	}
	return item, change, nil
}

func (s *Store) GetScript(ctx context.Context, space, name string) (Script, error) {
	var item Script
	var enabled int
	var trigger sql.NullString
	var created, updated string
	err := s.db.QueryRowContext(ctx, `SELECT source,enabled,trigger_stream,version,owner_sub,created_at,updated_at FROM scripts WHERE space_name=? AND name=?`, space, name).
		Scan(&item.Source, &enabled, &trigger, &item.Version, &item.Owner, &created, &updated)
	if errors.Is(err, sql.ErrNoRows) {
		return Script{}, ErrNotFound
	}
	if err != nil {
		return Script{}, err
	}
	item.Space, item.Name, item.Enabled, item.TriggerStream = space, name, enabled != 0, trigger.String
	item.CreatedAt, err = parseTime(created)
	if err != nil {
		return Script{}, err
	}
	item.UpdatedAt, err = parseTime(updated)
	return item, err
}

func (s *Store) ListScripts(ctx context.Context, space string, includeSource bool) ([]Script, error) {
	rows, err := s.db.QueryContext(ctx, `SELECT name,source,enabled,trigger_stream,version,owner_sub,created_at,updated_at FROM scripts WHERE space_name=? ORDER BY name`, space)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]Script, 0)
	for rows.Next() {
		var item Script
		var enabled int
		var trigger sql.NullString
		var created, updated string
		if err := rows.Scan(&item.Name, &item.Source, &enabled, &trigger, &item.Version, &item.Owner, &created, &updated); err != nil {
			return nil, err
		}
		item.Space, item.Enabled, item.TriggerStream = space, enabled != 0, trigger.String
		if !includeSource {
			item.Source = ""
		}
		item.CreatedAt, err = parseTime(created)
		if err != nil {
			return nil, err
		}
		item.UpdatedAt, err = parseTime(updated)
		if err != nil {
			return nil, err
		}
		items = append(items, item)
	}
	return items, rows.Err()
}

func (s *Store) TriggeredScripts(ctx context.Context, space, stream string) ([]Script, error) {
	rows, err := s.db.QueryContext(ctx, `SELECT name,source,enabled,trigger_stream,version,owner_sub,created_at,updated_at FROM scripts WHERE space_name=? AND trigger_stream=? AND enabled=1 ORDER BY name`, space, stream)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]Script, 0)
	for rows.Next() {
		var item Script
		var enabled int
		var trigger sql.NullString
		var created, updated string
		if err := rows.Scan(&item.Name, &item.Source, &enabled, &trigger, &item.Version, &item.Owner, &created, &updated); err != nil {
			return nil, err
		}
		item.Space, item.Enabled, item.TriggerStream = space, enabled != 0, trigger.String
		item.CreatedAt, err = parseTime(created)
		if err != nil {
			return nil, err
		}
		item.UpdatedAt, err = parseTime(updated)
		if err != nil {
			return nil, err
		}
		items = append(items, item)
	}
	return items, rows.Err()
}

func (s *Store) RecordScriptRun(ctx context.Context, run ScriptRun) error {
	_, err := s.db.ExecContext(ctx, `INSERT INTO script_runs(space_name,script_name,script_version,trigger_kind,status,output_json,error_text,started_at,finished_at) VALUES(?,?,?,?,?,?,?,?,?)`,
		run.Space, run.ScriptName, run.Version, run.Trigger, run.Status, nullableBytes(run.Output), nullableString(run.Error), utcText(run.StartedAt), utcText(run.FinishedAt))
	return err
}

func (s *Store) ListScriptRuns(ctx context.Context, space string, limit int) ([]ScriptRun, error) {
	if limit <= 0 || limit > 500 {
		limit = 100
	}
	rows, err := s.db.QueryContext(ctx, `SELECT id,script_name,script_version,trigger_kind,status,output_json,error_text,started_at,finished_at FROM script_runs WHERE space_name=? ORDER BY id DESC LIMIT ?`, space, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]ScriptRun, 0, limit)
	for rows.Next() {
		var item ScriptRun
		var output []byte
		var errorText sql.NullString
		var started, finished string
		if err := rows.Scan(&item.ID, &item.ScriptName, &item.Version, &item.Trigger, &item.Status, &output, &errorText, &started, &finished); err != nil {
			return nil, err
		}
		item.Space, item.Output, item.Error = space, json.RawMessage(output), errorText.String
		item.StartedAt, err = parseTime(started)
		if err != nil {
			return nil, err
		}
		item.FinishedAt, err = parseTime(finished)
		if err != nil {
			return nil, err
		}
		items = append(items, item)
	}
	return items, rows.Err()
}
