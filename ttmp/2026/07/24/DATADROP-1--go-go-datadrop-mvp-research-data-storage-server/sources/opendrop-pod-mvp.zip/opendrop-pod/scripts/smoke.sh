#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$root"

gofmt -w $(find . -name '*.go' -type f)
node --check internal/webassets/web/opendrop-client.js
node --check internal/webassets/web/app.js
node --check examples/scripts/frost-check.js

go test ./internal/dpop ./internal/realtime
