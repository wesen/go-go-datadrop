# OpenDrop Pod implementation architecture

## 1. Objective

OpenDrop Pod removes the application-specific server from a common web application topology. Static HTML, JavaScript, and WebAssembly authenticate directly to a user-owned storage host. The host provides identity integration, authorization, durable records, append-only streams, realtime replay, site assets, and bounded scripts.

```text
static page / CLI
       │
       │ OAuth + DPoP
       ▼
OpenDrop Pod
├── tiny-idp issuer
├── DPoP storage-session layer
├── records and streams
├── durable change cursor
├── fetch and WebSocket feeds
├── goja function runtime
└── static-site release store
       │
       ▼
SQLite + WAL
```

The service is PDS-shaped: accounts own spaces and applications connect to the storage service instead of an application backend. It is not yet an AT Protocol PDS and does not implement signed MST repositories, CAR synchronization, DIDs, handle resolution, federation, or AppViews.

## 2. Process structure

One `opendrop-pod` process embeds all control and data-plane components:

```text
cmd/opendrop-pod
  └── internal/app
      ├── internal/identity
      │   └── tiny-idp embedded provider
      ├── internal/store
      │   └── SQLite domain/security store
      ├── internal/realtime
      │   └── in-process low-latency hub
      ├── internal/script
      │   └── go-go-goja runtime and dispatcher
      └── internal/server
          └── HTTP/XRPC, feeds, sites, browser assets
```

Identity and application data use separate SQLite databases under the same state root. This keeps tiny-idp's schema and lifecycle independent from OpenDrop's storage schema.

## 3. Authentication flow

### 3.1 Browser

1. The static page creates a non-extractable P-256 key using WebCrypto and stores the `CryptoKeyPair` in IndexedDB.
2. The page begins tiny-idp authorization code flow with PKCE.
3. Tiny-idp returns an ordinary bearer access token and rotating refresh token.
4. The page sends the bearer token to `io.opendrop.session.createDPoP` with an ES256 proof whose `ath` covers that bearer token.
5. The Pod introspects the token through an in-process issuer transport and verifies issuer, audience, expiry, subject, client, and scopes.
6. The Pod creates a random opaque storage token, stores only its SHA-256 hash, and binds the session to the proof JWK thumbprint.
7. Every later storage request carries `Authorization: DPoP <token>` and a fresh proof whose `ath` covers the storage token.

### 3.2 CLI

`dropctl` performs the tiny-idp device grant, creates a local P-256 key, performs the same exchange, and stores its private JWK and opaque storage token in an owner-only JSON file.

### 3.3 Request proof

The verifier accepts ES256 only. It validates:

- `typ=dpop+jwt`;
- a public EC P-256 JWK with no private fields;
- JWS signature;
- exact HTTP method;
- normalized absolute HTTP(S) target URI without query or fragment;
- bounded `iat`;
- required `ath` when an access token is involved;
- expected JWK thumbprint;
- expected nonce when challenged;
- unique `(thumbprint, jti)` through a durable replay table.

## 4. Storage model

### 4.1 Space

A space is the authorization and synchronization boundary. Each space has an owner and membership rows with `owner`, `writer`, or `reader` roles. The current API creates spaces and enforces roles; membership management is present in the store layer but is not yet exposed as a public XRPC procedure.

### 4.2 Records

A record is addressed by:

```text
(space, collection, record key)
```

Values are parsed as one JSON value and re-encoded into normalized compact bytes. Each update increments a revision and stores a SHA-256 digest. `swapRev` supplies optimistic concurrency:

- omitted: unconditional create/update;
- `0`: create only;
- positive revision: update only when the current revision matches.

### 4.3 Streams

A stream is append-only and has a monotonically increasing per-stream sequence. Each event receives a random identifier, actor, event time, data, optional metadata, and ingest time.

### 4.4 Changes

Every domain mutation writes a `changes` row in the same SQLite transaction. `changes.cursor` is the durable global ordering key; subscribers filter it by space. The in-process hub only wakes live clients and is never the source of truth.

## 5. Realtime delivery

### 5.1 Fetch stream

`io.opendrop.sync.subscribe` is a DPoP-authenticated NDJSON response. The server:

1. registers the subscriber with the hub;
2. reads durable history after the requested cursor;
3. emits live changes with larger cursors;
4. emits heartbeats;
5. sends a reset hint and closes if the subscriber's bounded queue overflows.

Registering before history prevents the snapshot/live race. Duplicate live values are discarded by cursor. Delivery is resumable and at least once.

### 5.2 WebSocket

Browsers cannot attach arbitrary authorization headers to the standard WebSocket constructor, so the flow has two authenticated stages:

1. A normal DPoP request creates a one-use ticket bound to subject, JWK thumbprint, space, cursor, origin, and expiry.
2. The browser upgrades using the ticket URL.
3. The Pod atomically consumes the ticket and validates the `Origin`.
4. The Pod sends a random nonce and canonical HTTP upgrade target.
5. The browser signs a DPoP proof with the same key.
6. The Pod verifies the thumbprint and nonce, sends `ready`, then releases history and live changes.

## 6. Script runtime

Scripts are synchronous CommonJS modules:

```js
module.exports = function (ctx) {
  return ctx.opendrop.append("audit", { operation: "ran" }, null);
};
```

Each invocation receives a new `go-go-goja` runtime configured with `MiddlewareSafe`. The selected native modules are the data-safe set (`crypto`, `events`, `path`, `time`, and `timer`, including aliases); filesystem, OS, execution, and database modules are not installed.

The host injects only:

```text
ctx.actor
ctx.space
ctx.trigger
ctx.input
ctx.opendrop.getRecord
ctx.opendrop.putRecord
ctx.opendrop.append
ctx.opendrop.listEvents
ctx.opendrop.now
```

The space is fixed by the invocation. Capabilities call Go code directly and never expose credentials or the raw database. The runtime has wall-clock interruption and count/size limits, but no hard heap quota. This is suitable for trusted owner-managed automation, not hostile multi-tenant code.

Triggered scripts are selected by `(space, trigger stream)`. Event ingestion does not wait for script execution. The dispatcher uses a bounded non-blocking queue; overflow is logged and is a deliberate MVP limitation.

## 7. Static sites

Site manifests and files are stored in SQLite. A site is published only when its manifest is public. The server maps:

```text
<site>.<space>.<site-base-domain>
```

onto one site release and serves its files with content-type sniffing disabled, ETags, bounded caching, referrer policy, and a restrictive permissions policy. This two-label hostname gives each site/space pair a distinct browser origin. The identity provider and administration console remain on the main origin.

Static applications import `/opendrop-client.js`, run their own login redirect, and interact with the storage API directly. Each callback URI must be registered when the Pod starts.

## 8. Transaction and failure behavior

For record, event, script, and site mutations:

```text
begin transaction
  write domain state
  append change row
commit
publish committed change to hub
```

If the process exits after commit but before hub publication, connected clients may not receive the low-latency notification. They recover from the durable cursor on reconnect. No committed mutation is omitted from replay.

SQLite is configured with foreign keys, WAL, a busy timeout, `synchronous=FULL`, and one open connection. This favors predictable single-process semantics over write concurrency.

## 9. Deployment profiles

### Development

```text
one process
loopback HTTP
SQLite
lvh.me wildcard sites
seeded development account
```

### Production direction

```text
HTTPS
production tiny-idp policy and audit
PostgreSQL or replicated storage
object storage for site/blob bytes
transactional outbox worker
NATS JetStream or database notifications
hard-isolated script workers
per-space quotas and retention
signed exports and ATproto publication plane
```

## 10. Next protocol steps

The most valuable next work is:

1. issuer-native DPoP tokens and refresh rotation, removing the bridge;
2. exposed membership and capability administration;
3. idempotency keys and atomic batch writes;
4. JSON Schema/Lexicon validation;
5. durable trigger jobs;
6. immutable site releases rather than mutable manifests;
7. export/import and signed snapshots;
8. DID service discovery and a real public ATproto repository plane;
9. local-first browser replicas using IndexedDB/OPFS and optional SQLite-Wasm;
10. retention, quotas, backups, and cluster-safe realtime notifications.
