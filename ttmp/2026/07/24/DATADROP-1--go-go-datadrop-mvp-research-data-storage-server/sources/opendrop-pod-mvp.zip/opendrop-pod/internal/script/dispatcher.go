package script

import (
	"context"
	"encoding/json"
	"log/slog"
	"sync"
	"time"

	"github.com/go-go-golems/opendrop-pod/internal/store"
)

type Dispatcher struct {
	store   *store.Store
	runner  *Runner
	queue   chan store.Event
	workers int
	logger  *slog.Logger
	wg      sync.WaitGroup
}

func NewDispatcher(dataStore *store.Store, runner *Runner, workers, queueSize int, logger *slog.Logger) *Dispatcher {
	if workers <= 0 {
		workers = 2
	}
	if queueSize <= 0 {
		queueSize = 256
	}
	if logger == nil {
		logger = slog.Default()
	}
	return &Dispatcher{store: dataStore, runner: runner, queue: make(chan store.Event, queueSize), workers: workers, logger: logger}
}

func (d *Dispatcher) Start(ctx context.Context) {
	for index := 0; index < d.workers; index++ {
		d.wg.Add(1)
		go d.worker(ctx)
	}
}

func (d *Dispatcher) Wait() { d.wg.Wait() }

// Enqueue is deliberately non-blocking. Durable event ingestion must not be
// held hostage by script capacity. Failed enqueueing is visible in logs.
func (d *Dispatcher) Enqueue(event store.Event) bool {
	select {
	case d.queue <- event:
		return true
	default:
		d.logger.Error("script trigger queue is full", "space", event.Space, "stream", event.Stream, "sequence", event.Sequence)
		return false
	}
}

func (d *Dispatcher) worker(ctx context.Context) {
	defer d.wg.Done()
	for {
		select {
		case <-ctx.Done():
			return
		case event := <-d.queue:
			d.runTriggered(ctx, event)
		}
	}
}

func (d *Dispatcher) runTriggered(ctx context.Context, event store.Event) {
	scripts, err := d.store.TriggeredScripts(ctx, event.Space, event.Stream)
	if err != nil {
		d.logger.Error("list triggered scripts", "error", err, "space", event.Space, "stream", event.Stream)
		return
	}
	input, _ := json.Marshal(map[string]any{"event": event})
	for _, item := range scripts {
		started := time.Now().UTC()
		output, runErr := d.runner.Run(ctx, item.Source, Invocation{Actor: item.Owner, Space: item.Space, Trigger: "stream:" + event.Stream, Input: input})
		finished := time.Now().UTC()
		run := store.ScriptRun{Space: item.Space, ScriptName: item.Name, Version: item.Version, Trigger: "stream:" + event.Stream, StartedAt: started, FinishedAt: finished, Output: output, Status: "ok"}
		if runErr != nil {
			run.Status, run.Error = "error", runErr.Error()
			d.logger.Warn("triggered script failed", "error", runErr, "space", item.Space, "script", item.Name, "version", item.Version)
		}
		if err := d.store.RecordScriptRun(ctx, run); err != nil {
			d.logger.Error("record script run", "error", err, "space", item.Space, "script", item.Name)
		}
	}
}
