package store

import (
	"encoding/json"
	"errors"
	"time"
)

var (
	ErrNotFound       = errors.New("not found")
	ErrForbidden      = errors.New("forbidden")
	ErrConflict       = errors.New("conflict")
	ErrReplay         = errors.New("replay")
	ErrOAuthTokenUsed = errors.New("OAuth access token already exchanged")
	ErrTicketUsed     = errors.New("ticket already used")
	ErrTicketExpiry   = errors.New("ticket expired")
)

type Session struct {
	Subject   string
	ClientID  string
	Scopes    []string
	JKT       string
	ExpiresAt time.Time
}

type WSTicket struct {
	Subject   string
	JKT       string
	Space     string
	Cursor    int64
	Origin    string
	ExpiresAt time.Time
}

type Space struct {
	Name      string    `json:"name"`
	Title     string    `json:"title"`
	Owner     string    `json:"owner"`
	Role      string    `json:"role"`
	CreatedAt time.Time `json:"createdAt"`
}

type Record struct {
	URI        string          `json:"uri"`
	Space      string          `json:"space"`
	Collection string          `json:"collection"`
	RKey       string          `json:"rkey"`
	Value      json.RawMessage `json:"value"`
	Rev        int64           `json:"rev"`
	Digest     string          `json:"digest"`
	CreatedAt  time.Time       `json:"createdAt"`
	UpdatedAt  time.Time       `json:"updatedAt"`
}

type Event struct {
	ID        string          `json:"id"`
	Space     string          `json:"space"`
	Stream    string          `json:"stream"`
	Sequence  int64           `json:"sequence"`
	Subject   string          `json:"subject"`
	Time      time.Time       `json:"time"`
	Data      json.RawMessage `json:"data"`
	Meta      json.RawMessage `json:"meta,omitempty"`
	CreatedAt time.Time       `json:"createdAt"`
}

type Change struct {
	Type       string          `json:"type"`
	Cursor     int64           `json:"cursor"`
	Space      string          `json:"space"`
	Kind       string          `json:"kind"`
	Collection string          `json:"collection,omitempty"`
	RKey       string          `json:"rkey,omitempty"`
	Stream     string          `json:"stream,omitempty"`
	Sequence   int64           `json:"sequence,omitempty"`
	Actor      string          `json:"actor"`
	Data       json.RawMessage `json:"data,omitempty"`
	CreatedAt  time.Time       `json:"createdAt"`
}

type Script struct {
	Space         string    `json:"space"`
	Name          string    `json:"name"`
	Source        string    `json:"source,omitempty"`
	Enabled       bool      `json:"enabled"`
	TriggerStream string    `json:"triggerStream,omitempty"`
	Version       int64     `json:"version"`
	Owner         string    `json:"owner"`
	CreatedAt     time.Time `json:"createdAt"`
	UpdatedAt     time.Time `json:"updatedAt"`
}

type ScriptRun struct {
	ID         int64           `json:"id"`
	Space      string          `json:"space"`
	ScriptName string          `json:"scriptName"`
	Version    int64           `json:"version"`
	Trigger    string          `json:"trigger"`
	Status     string          `json:"status"`
	Output     json.RawMessage `json:"output,omitempty"`
	Error      string          `json:"error,omitempty"`
	StartedAt  time.Time       `json:"startedAt"`
	FinishedAt time.Time       `json:"finishedAt"`
}

type Site struct {
	Space      string    `json:"space"`
	Name       string    `json:"name"`
	Public     bool      `json:"public"`
	Entrypoint string    `json:"entrypoint"`
	CreatedAt  time.Time `json:"createdAt"`
	UpdatedAt  time.Time `json:"updatedAt"`
}

type SiteFile struct {
	Space       string    `json:"space"`
	Site        string    `json:"site"`
	Path        string    `json:"path"`
	ContentType string    `json:"contentType"`
	Body        []byte    `json:"-"`
	Digest      string    `json:"digest"`
	UpdatedAt   time.Time `json:"updatedAt"`
}
