package store

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"database/sql"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"

	_ "github.com/mattn/go-sqlite3"
)

type Store struct {
	db   *sql.DB
	path string
	now  func() time.Time
}

func Open(ctx context.Context, path string) (*Store, error) {
	if ctx == nil {
		return nil, errors.New("store context is required")
	}
	if strings.TrimSpace(path) == "" {
		return nil, errors.New("store path is required")
	}
	absolutePath, err := filepath.Abs(path)
	if err != nil {
		return nil, fmt.Errorf("resolve store path: %w", err)
	}
	directory := filepath.Dir(absolutePath)
	if err := os.MkdirAll(directory, 0o700); err != nil {
		return nil, fmt.Errorf("create store directory: %w", err)
	}
	if err := os.Chmod(directory, 0o700); err != nil {
		return nil, fmt.Errorf("secure store directory: %w", err)
	}
	if info, err := os.Lstat(absolutePath); err == nil {
		if info.Mode()&os.ModeSymlink != 0 || !info.Mode().IsRegular() {
			return nil, errors.New("store path must be a regular file, not a symlink")
		}
	} else if !os.IsNotExist(err) {
		return nil, fmt.Errorf("inspect store path: %w", err)
	}
	dsnURL := &url.URL{Scheme: "file", Path: filepath.ToSlash(absolutePath)}
	query := dsnURL.Query()
	query.Set("_foreign_keys", "on")
	query.Set("_journal_mode", "WAL")
	query.Set("_busy_timeout", "5000")
	query.Set("_synchronous", "FULL")
	dsnURL.RawQuery = query.Encode()
	db, err := sql.Open("sqlite3", dsnURL.String())
	if err != nil {
		return nil, fmt.Errorf("open SQLite: %w", err)
	}
	db.SetMaxOpenConns(1)
	db.SetMaxIdleConns(1)
	store := &Store{db: db, path: absolutePath, now: time.Now}
	if err := db.PingContext(ctx); err != nil {
		_ = db.Close()
		return nil, fmt.Errorf("ping SQLite: %w", err)
	}
	if err := store.migrate(ctx); err != nil {
		_ = db.Close()
		return nil, err
	}
	if err := store.secureFiles(); err != nil {
		_ = db.Close()
		return nil, err
	}
	return store, nil
}

func (s *Store) Close() error {
	if s == nil || s.db == nil {
		return nil
	}
	err := s.db.Close()
	if permissionErr := s.secureFiles(); err == nil {
		err = permissionErr
	}
	return err
}

func (s *Store) secureFiles() error {
	if s == nil || s.path == "" {
		return nil
	}
	for _, candidate := range []string{s.path, s.path + "-wal", s.path + "-shm"} {
		info, err := os.Lstat(candidate)
		if os.IsNotExist(err) {
			continue
		}
		if err != nil {
			return fmt.Errorf("inspect SQLite file %s: %w", candidate, err)
		}
		if info.Mode()&os.ModeSymlink != 0 || !info.Mode().IsRegular() {
			return fmt.Errorf("SQLite file %s is not a regular file", candidate)
		}
		if err := os.Chmod(candidate, 0o600); err != nil {
			return fmt.Errorf("secure SQLite file %s: %w", candidate, err)
		}
	}
	return nil
}

func (s *Store) Ping(ctx context.Context) error {
	if s == nil || s.db == nil {
		return errors.New("store is closed")
	}
	return s.db.PingContext(ctx)
}

func (s *Store) migrate(ctx context.Context) error {
	const schema = `
CREATE TABLE IF NOT EXISTS spaces (
    name TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    owner_sub TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS space_members (
    space_name TEXT NOT NULL REFERENCES spaces(name) ON DELETE CASCADE,
    subject TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('owner','writer','reader')),
    created_at TEXT NOT NULL,
    PRIMARY KEY (space_name, subject)
);
CREATE INDEX IF NOT EXISTS idx_space_members_subject ON space_members(subject, space_name);

CREATE TABLE IF NOT EXISTS records (
    space_name TEXT NOT NULL REFERENCES spaces(name) ON DELETE CASCADE,
    collection TEXT NOT NULL,
    rkey TEXT NOT NULL,
    value_json BLOB NOT NULL,
    rev INTEGER NOT NULL,
    digest TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (space_name, collection, rkey)
);
CREATE INDEX IF NOT EXISTS idx_records_collection ON records(space_name, collection, rkey);

CREATE TABLE IF NOT EXISTS stream_heads (
    space_name TEXT NOT NULL REFERENCES spaces(name) ON DELETE CASCADE,
    stream TEXT NOT NULL,
    sequence INTEGER NOT NULL,
    PRIMARY KEY (space_name, stream)
);
CREATE TABLE IF NOT EXISTS stream_events (
    space_name TEXT NOT NULL REFERENCES spaces(name) ON DELETE CASCADE,
    stream TEXT NOT NULL,
    sequence INTEGER NOT NULL,
    event_id TEXT NOT NULL,
    subject TEXT NOT NULL,
    event_time TEXT NOT NULL,
    data_json BLOB NOT NULL,
    meta_json BLOB,
    created_at TEXT NOT NULL,
    PRIMARY KEY (space_name, stream, sequence),
    UNIQUE (event_id)
);
CREATE INDEX IF NOT EXISTS idx_stream_events_time ON stream_events(space_name, stream, event_time);

CREATE TABLE IF NOT EXISTS changes (
    cursor INTEGER PRIMARY KEY AUTOINCREMENT,
    space_name TEXT NOT NULL REFERENCES spaces(name) ON DELETE CASCADE,
    kind TEXT NOT NULL,
    collection TEXT,
    rkey TEXT,
    stream TEXT,
    sequence INTEGER,
    actor_sub TEXT NOT NULL,
    data_json BLOB,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_changes_space_cursor ON changes(space_name, cursor);

CREATE TABLE IF NOT EXISTS scripts (
    space_name TEXT NOT NULL REFERENCES spaces(name) ON DELETE CASCADE,
    name TEXT NOT NULL,
    source TEXT NOT NULL,
    enabled INTEGER NOT NULL,
    trigger_stream TEXT,
    version INTEGER NOT NULL,
    owner_sub TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (space_name, name)
);
CREATE INDEX IF NOT EXISTS idx_scripts_trigger ON scripts(space_name, trigger_stream, enabled);
CREATE TABLE IF NOT EXISTS script_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    space_name TEXT NOT NULL,
    script_name TEXT NOT NULL,
    script_version INTEGER NOT NULL,
    trigger_kind TEXT NOT NULL,
    status TEXT NOT NULL,
    output_json BLOB,
    error_text TEXT,
    started_at TEXT NOT NULL,
    finished_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_script_runs_space ON script_runs(space_name, id DESC);

CREATE TABLE IF NOT EXISTS sites (
    space_name TEXT NOT NULL REFERENCES spaces(name) ON DELETE CASCADE,
    name TEXT NOT NULL,
    public INTEGER NOT NULL,
    entrypoint TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (space_name, name)
);
CREATE TABLE IF NOT EXISTS site_files (
    space_name TEXT NOT NULL,
    site_name TEXT NOT NULL,
    path TEXT NOT NULL,
    content_type TEXT NOT NULL,
    body BLOB NOT NULL,
    digest TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (space_name, site_name, path),
    FOREIGN KEY (space_name, site_name) REFERENCES sites(space_name, name) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS dpop_sessions (
    token_hash BLOB PRIMARY KEY,
    subject TEXT NOT NULL,
    client_id TEXT NOT NULL,
    scopes_json BLOB NOT NULL,
    jkt TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_dpop_sessions_expiry ON dpop_sessions(expires_at);
CREATE TABLE IF NOT EXISTS oauth_exchanges (
    token_hash BLOB PRIMARY KEY,
    subject TEXT NOT NULL,
    jkt TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    used_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_oauth_exchanges_expiry ON oauth_exchanges(expires_at);
CREATE TABLE IF NOT EXISTS dpop_replays (
    jkt TEXT NOT NULL,
    jti TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    PRIMARY KEY (jkt, jti)
);
CREATE INDEX IF NOT EXISTS idx_dpop_replays_expiry ON dpop_replays(expires_at);
CREATE TABLE IF NOT EXISTS websocket_tickets (
    ticket_hash BLOB PRIMARY KEY,
    subject TEXT NOT NULL,
    jkt TEXT NOT NULL,
    space_name TEXT NOT NULL,
    cursor INTEGER NOT NULL,
    origin TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    used_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_websocket_tickets_expiry ON websocket_tickets(expires_at);
`
	if _, err := s.db.ExecContext(ctx, schema); err != nil {
		return fmt.Errorf("apply storage schema: %w", err)
	}
	return nil
}

func utcText(value time.Time) string { return value.UTC().Format(time.RFC3339Nano) }

func parseTime(value string) (time.Time, error) {
	parsed, err := time.Parse(time.RFC3339Nano, value)
	if err != nil {
		return time.Time{}, err
	}
	return parsed.UTC(), nil
}

func compactJSON(raw json.RawMessage) (json.RawMessage, error) {
	if len(raw) == 0 {
		return nil, errors.New("JSON value is required")
	}
	var value any
	decoder := json.NewDecoder(strings.NewReader(string(raw)))
	decoder.UseNumber()
	if err := decoder.Decode(&value); err != nil {
		return nil, fmt.Errorf("decode JSON: %w", err)
	}
	var extra any
	if err := decoder.Decode(&extra); err != io.EOF {
		if err == nil {
			return nil, errors.New("multiple JSON values are not allowed")
		}
		return nil, fmt.Errorf("decode trailing JSON: %w", err)
	}
	encoded, err := json.Marshal(value)
	if err != nil {
		return nil, fmt.Errorf("encode JSON: %w", err)
	}
	return encoded, nil
}

func digestJSON(raw []byte) string {
	digest := sha256.Sum256(raw)
	return hex.EncodeToString(digest[:])
}

func hashOpaque(value string) []byte {
	digest := sha256.Sum256([]byte(value))
	return digest[:]
}

func randomOpaque(size int) (string, error) {
	value := make([]byte, size)
	if _, err := rand.Read(value); err != nil {
		return "", fmt.Errorf("read randomness: %w", err)
	}
	return base64.RawURLEncoding.EncodeToString(value), nil
}

func boolInt(value bool) int {
	if value {
		return 1
	}
	return 0
}
