module github.com/go-go-golems/opendrop-pod

go 1.26.4

toolchain go1.26.5

require (
	github.com/dop251/goja v0.0.0-20251103141225-af2ceb9156d7
	github.com/go-go-golems/go-go-goja v0.10.5-0.20260717152521-c6e464c5bbc6
	github.com/go-go-golems/tiny-idp v0.0.3
	github.com/gorilla/websocket v1.5.3
	github.com/mattn/go-sqlite3 v1.14.42
	golang.org/x/crypto v0.53.0
)
