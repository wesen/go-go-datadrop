package weborigin

import "testing"

func TestCanonical(t *testing.T) {
	tests := map[string]string{
		"HTTPS://Example.COM:443/": "https://example.com",
		"http://Example.COM:80":    "http://example.com",
		"https://Example.COM:8443": "https://example.com:8443",
		"http://[::1]:80":          "http://[::1]",
	}
	for input, wanted := range tests {
		got, err := Canonical(input)
		if err != nil {
			t.Fatalf("Canonical(%q): %v", input, err)
		}
		if got != wanted {
			t.Fatalf("Canonical(%q)=%q want %q", input, got, wanted)
		}
	}
}

func TestRejectsNonOrigins(t *testing.T) {
	for _, input := range []string{
		"example.com",
		"ftp://example.com",
		"https://user@example.com",
		"https://example.com/path",
		"https://example.com/?query=1",
		"https://example.com/#fragment",
	} {
		if _, err := Canonical(input); err == nil {
			t.Fatalf("Canonical(%q) unexpectedly succeeded", input)
		}
	}
}
