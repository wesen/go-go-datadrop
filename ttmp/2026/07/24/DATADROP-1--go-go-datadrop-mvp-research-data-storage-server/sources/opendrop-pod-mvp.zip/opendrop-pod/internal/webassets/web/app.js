import { OpenDropClient } from "/opendrop-client.js";

const client = new OpenDropClient();
const output = document.querySelector("#output");
const feed = document.querySelector("#feed");
const status = document.querySelector("#status");
let feedAbort = null;

function show(value) {
  output.textContent = typeof value === "string" ? value : JSON.stringify(value, null, 2);
}
function formObject(form) { return Object.fromEntries(new FormData(form)); }
function setSessionUI() {
  const active = Boolean(client.storageSession?.accessToken);
  status.textContent = active ? `signed in as ${client.storageSession.subject}` : "signed out";
  document.querySelector("#login").hidden = active;
  document.querySelector("#logout").hidden = !active;
}
async function run(task) {
  try { show(await task()); await refreshSpaces(); }
  catch (error) { show({ error: error.message, stack: error.stack }); }
}
async function refreshSpaces() {
  if (!client.storageSession) return;
  const result = await client.listSpaces();
  document.querySelector("#spaces").innerHTML = result.spaces.map(space => `<span class="chip">${space.name} · ${space.role}</span>`).join("") || "No spaces yet.";
}

await client.initialize();
try { if (await client.handleRedirect()) show("Login completed."); }
catch (error) { show({ error: error.message }); }
setSessionUI();
if (client.storageSession) refreshSpaces().catch(error => show({ error: error.message }));

document.querySelector("#login").addEventListener("click", () => client.beginLogin());
document.querySelector("#logout").addEventListener("click", async () => { await client.logout(); setSessionUI(); show("Local session cleared."); });
document.querySelector("#refresh-spaces").addEventListener("click", () => run(refreshSpaces));

document.querySelector("#create-space").addEventListener("submit", event => {
  event.preventDefault(); const value = formObject(event.currentTarget);
  run(() => client.createSpace(value.name, value.title));
});
document.querySelector("#put-record").addEventListener("submit", event => {
  event.preventDefault(); const value = formObject(event.currentTarget);
  run(() => client.putRecord(value.space, value.collection, value.rkey, JSON.parse(value.record)));
});
document.querySelector("#append-event").addEventListener("submit", event => {
  event.preventDefault(); const value = formObject(event.currentTarget);
  run(() => client.append(value.space, value.stream, JSON.parse(value.data)));
});
document.querySelector("#put-script").addEventListener("submit", event => {
  event.preventDefault(); const value = formObject(event.currentTarget);
  run(() => client.putScript(value.space, value.name, value.source, { enabled: true, triggerStream: value.trigger }));
});
document.querySelector("#run-script").addEventListener("click", () => {
  const value = formObject(document.querySelector("#put-script"));
  run(() => client.runScript(value.space, value.name, { temperature: 2.2 }));
});
document.querySelector("#feed-controls").addEventListener("submit", event => {
  event.preventDefault();
  if (feedAbort) feedAbort.abort();
  feedAbort = new AbortController();
  const { space } = formObject(event.currentTarget);
  feed.textContent = "";
  client.subscribe(space, 0, message => {
    feed.textContent += `${JSON.stringify(message)}\n`;
    feed.scrollTop = feed.scrollHeight;
  }, { signal: feedAbort.signal }).catch(error => {
    if (error.name !== "AbortError") feed.textContent += `ERROR ${error.message}\n`;
  });
});
document.querySelector("#disconnect").addEventListener("click", () => { feedAbort?.abort(); feedAbort = null; });
