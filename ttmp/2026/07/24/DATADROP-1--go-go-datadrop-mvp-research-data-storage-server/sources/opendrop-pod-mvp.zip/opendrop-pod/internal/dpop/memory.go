package dpop

import (
	"context"
	"sync"
	"time"
)

// MemoryReplayStore is useful for tests and single-process demonstrations.
type MemoryReplayStore struct {
	mu      sync.Mutex
	entries map[string]time.Time
	now     func() time.Time
}

func NewMemoryReplayStore(now func() time.Time) *MemoryReplayStore {
	if now == nil {
		now = time.Now
	}
	return &MemoryReplayStore{entries: make(map[string]time.Time), now: now}
}

func (s *MemoryReplayStore) UseDPoPProof(ctx context.Context, thumbprint, jti string, expiresAt time.Time) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	key := thumbprint + "\x00" + jti
	now := s.now().UTC()
	s.mu.Lock()
	defer s.mu.Unlock()
	for candidate, expiry := range s.entries {
		if !now.Before(expiry) {
			delete(s.entries, candidate)
		}
	}
	if _, exists := s.entries[key]; exists {
		return ErrReplay
	}
	s.entries[key] = expiresAt.UTC()
	return nil
}
