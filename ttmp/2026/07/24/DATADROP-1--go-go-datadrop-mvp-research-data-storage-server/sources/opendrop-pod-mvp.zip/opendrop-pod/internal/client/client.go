package client

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/go-go-golems/opendrop-pod/internal/dpop"
	"github.com/go-go-golems/opendrop-pod/internal/identity"
	"github.com/go-go-golems/opendrop-pod/internal/weborigin"
)

type Credentials struct {
	Server    string          `json:"server"`
	Token     string          `json:"token"`
	ExpiresAt time.Time       `json:"expiresAt"`
	Subject   string          `json:"subject"`
	Key       dpop.PrivateJWK `json:"key"`
}

type Client struct {
	credentials Credentials
	signer      *dpop.Signer
	httpClient  *http.Client
}

type APIError struct {
	Status  int
	Code    string
	Message string
}

func (e *APIError) Error() string {
	return fmt.Sprintf("OpenDrop API returned %d %s: %s", e.Status, e.Code, e.Message)
}

func DefaultCredentialsPath() (string, error) {
	if value := strings.TrimSpace(os.Getenv("OPENDROP_CREDENTIALS")); value != "" {
		return value, nil
	}
	root, err := os.UserConfigDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(root, "opendrop", "credentials.json"), nil
}

func LoadCredentials(path string) (Credentials, error) {
	info, err := os.Stat(path)
	if err != nil {
		return Credentials{}, err
	}
	if info.Mode().Perm()&0o077 != 0 {
		return Credentials{}, fmt.Errorf("credentials file %s permissions are %#o; remove group/other access", path, info.Mode().Perm())
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return Credentials{}, err
	}
	var credentials Credentials
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&credentials); err != nil {
		return Credentials{}, fmt.Errorf("decode credentials: %w", err)
	}
	var extra any
	if err := decoder.Decode(&extra); err != io.EOF {
		return Credentials{}, errors.New("credentials file must contain exactly one JSON value")
	}
	if credentials.Server == "" || credentials.Token == "" || credentials.ExpiresAt.IsZero() {
		return Credentials{}, errors.New("credentials file is incomplete")
	}
	return credentials, nil
}

func SaveCredentials(path string, credentials Credentials) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return err
	}
	encoded, err := json.MarshalIndent(credentials, "", "  ")
	if err != nil {
		return err
	}
	temporary := path + ".tmp"
	if err := os.WriteFile(temporary, append(encoded, '\n'), 0o600); err != nil {
		return err
	}
	if err := os.Chmod(temporary, 0o600); err != nil {
		return err
	}
	return os.Rename(temporary, path)
}

func New(credentials Credentials) (*Client, error) {
	canonicalServer, err := weborigin.Canonical(credentials.Server)
	if err != nil {
		return nil, fmt.Errorf("credentials server URL: %w", err)
	}
	signer, err := dpop.SignerFromJWK(credentials.Key)
	if err != nil {
		return nil, fmt.Errorf("load DPoP key: %w", err)
	}
	credentials.Server = canonicalServer
	return &Client{credentials: credentials, signer: signer, httpClient: &http.Client{}}, nil
}

func (c *Client) Credentials() Credentials { return c.credentials }

func (c *Client) Call(ctx context.Context, method, procedure string, query url.Values, input any, output any) error {
	if ctx == nil {
		ctx = context.Background()
	}
	if _, hasDeadline := ctx.Deadline(); !hasDeadline {
		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(ctx, 30*time.Second)
		defer cancel()
	}
	endpoint := c.credentials.Server + "/xrpc/" + procedure
	if len(query) != 0 {
		endpoint += "?" + query.Encode()
	}
	var body io.Reader
	if input != nil {
		encoded, err := json.Marshal(input)
		if err != nil {
			return err
		}
		body = bytes.NewReader(encoded)
	}
	request, err := http.NewRequestWithContext(ctx, method, endpoint, body)
	if err != nil {
		return err
	}
	if input != nil {
		request.Header.Set("Content-Type", "application/json")
	}
	response, err := c.do(request)
	if err != nil {
		return err
	}
	defer response.Body.Close()
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		return decodeAPIError(response)
	}
	if output == nil || response.StatusCode == http.StatusNoContent {
		return nil
	}
	decoder := json.NewDecoder(io.LimitReader(response.Body, 16<<20))
	if err := decoder.Decode(output); err != nil {
		return fmt.Errorf("decode API response: %w", err)
	}
	return nil
}

func (c *Client) Subscribe(ctx context.Context, space string, cursor int64, callback func(json.RawMessage) error) error {
	if ctx == nil {
		ctx = context.Background()
	}
	endpoint, _ := url.Parse(c.credentials.Server + "/xrpc/io.opendrop.sync.subscribe")
	query := endpoint.Query()
	query.Set("space", space)
	query.Set("cursor", fmt.Sprintf("%d", cursor))
	endpoint.RawQuery = query.Encode()
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, endpoint.String(), nil)
	if err != nil {
		return err
	}
	response, err := c.do(request)
	if err != nil {
		return err
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return decodeAPIError(response)
	}
	scanner := bufio.NewScanner(response.Body)
	scanner.Buffer(make([]byte, 64<<10), 2<<20)
	for scanner.Scan() {
		line := append(json.RawMessage(nil), scanner.Bytes()...)
		if err := callback(line); err != nil {
			return err
		}
	}
	return scanner.Err()
}

func (c *Client) do(request *http.Request) (*http.Response, error) {
	if !time.Now().UTC().Before(c.credentials.ExpiresAt) {
		return nil, errors.New("stored DPoP session is expired; run dropctl login")
	}
	proof, err := c.signer.Sign(request.Method, request.URL.String(), c.credentials.Token, time.Now().UTC(), "")
	if err != nil {
		return nil, err
	}
	request.Header.Set("Authorization", "DPoP "+c.credentials.Token)
	request.Header.Set("DPoP", proof)
	return c.httpClient.Do(request)
}

func LoginDevice(ctx context.Context, server string, output io.Writer) (Credentials, error) {
	canonicalServer, err := weborigin.Canonical(server)
	if err != nil {
		return Credentials{}, fmt.Errorf("server URL: %w", err)
	}
	server = canonicalServer
	httpClient := &http.Client{Timeout: 15 * time.Second}
	issuer := server + "/idp"
	request, _ := http.NewRequestWithContext(ctx, http.MethodGet, issuer+"/.well-known/openid-configuration", nil)
	response, err := httpClient.Do(request)
	if err != nil {
		return Credentials{}, fmt.Errorf("discover issuer: %w", err)
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return Credentials{}, fmt.Errorf("issuer discovery returned %d", response.StatusCode)
	}
	var discovery struct {
		Issuer                      string `json:"issuer"`
		TokenEndpoint               string `json:"token_endpoint"`
		DeviceAuthorizationEndpoint string `json:"device_authorization_endpoint"`
	}
	if err := json.NewDecoder(response.Body).Decode(&discovery); err != nil {
		return Credentials{}, err
	}
	if discovery.Issuer != issuer || discovery.TokenEndpoint == "" || discovery.DeviceAuthorizationEndpoint == "" {
		return Credentials{}, errors.New("issuer discovery is incomplete")
	}
	resource := server + "/api"
	deviceForm := url.Values{
		"client_id": {identity.DeviceClientID},
		"scope":     {strings.Join(identity.DefaultScopes, " ")},
		"resource":  {resource},
	}
	deviceRequest, _ := http.NewRequestWithContext(ctx, http.MethodPost, discovery.DeviceAuthorizationEndpoint, strings.NewReader(deviceForm.Encode()))
	deviceRequest.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	deviceResponse, err := httpClient.Do(deviceRequest)
	if err != nil {
		return Credentials{}, err
	}
	defer deviceResponse.Body.Close()
	var device struct {
		DeviceCode              string `json:"device_code"`
		UserCode                string `json:"user_code"`
		VerificationURI         string `json:"verification_uri"`
		VerificationURIComplete string `json:"verification_uri_complete"`
		ExpiresIn               int    `json:"expires_in"`
		Interval                int    `json:"interval"`
	}
	if err := json.NewDecoder(deviceResponse.Body).Decode(&device); err != nil {
		return Credentials{}, err
	}
	if deviceResponse.StatusCode != http.StatusOK || device.DeviceCode == "" {
		return Credentials{}, fmt.Errorf("device authorization returned %d", deviceResponse.StatusCode)
	}
	verification := device.VerificationURIComplete
	if verification == "" {
		verification = device.VerificationURI
	}
	_, _ = fmt.Fprintf(output, "Open %s\nEnter code: %s\n", verification, device.UserCode)
	interval := time.Duration(device.Interval) * time.Second
	if interval < 2*time.Second {
		interval = 2 * time.Second
	}
	deadline := time.Now().Add(time.Duration(device.ExpiresIn) * time.Second)
	var token struct {
		AccessToken string `json:"access_token"`
		TokenType   string `json:"token_type"`
		ExpiresIn   int    `json:"expires_in"`
	}
	for time.Now().Before(deadline) {
		select {
		case <-ctx.Done():
			return Credentials{}, ctx.Err()
		case <-time.After(interval):
		}
		form := url.Values{
			"grant_type":  {"urn:ietf:params:oauth:grant-type:device_code"},
			"device_code": {device.DeviceCode},
			"client_id":   {identity.DeviceClientID},
			"resource":    {resource},
		}
		pollRequest, _ := http.NewRequestWithContext(ctx, http.MethodPost, discovery.TokenEndpoint, strings.NewReader(form.Encode()))
		pollRequest.Header.Set("Content-Type", "application/x-www-form-urlencoded")
		pollResponse, err := httpClient.Do(pollRequest)
		if err != nil {
			return Credentials{}, err
		}
		var payload map[string]any
		err = json.NewDecoder(io.LimitReader(pollResponse.Body, 1<<20)).Decode(&payload)
		pollResponse.Body.Close()
		if err != nil {
			return Credentials{}, err
		}
		if pollResponse.StatusCode == http.StatusOK {
			encoded, _ := json.Marshal(payload)
			if err := json.Unmarshal(encoded, &token); err != nil {
				return Credentials{}, err
			}
			break
		}
		errorCode, _ := payload["error"].(string)
		switch errorCode {
		case "authorization_pending":
			continue
		case "slow_down":
			interval += 5 * time.Second
			continue
		case "access_denied":
			return Credentials{}, errors.New("device authorization was denied")
		default:
			return Credentials{}, fmt.Errorf("device token request failed: %s", errorCode)
		}
	}
	if token.AccessToken == "" {
		return Credentials{}, errors.New("device authorization expired")
	}
	signer, err := dpop.GenerateSigner()
	if err != nil {
		return Credentials{}, err
	}
	exchangeURL := server + "/xrpc/io.opendrop.session.createDPoP"
	proof, err := signer.Sign(http.MethodPost, exchangeURL, token.AccessToken, time.Now().UTC(), "")
	if err != nil {
		return Credentials{}, err
	}
	exchangeRequest, _ := http.NewRequestWithContext(ctx, http.MethodPost, exchangeURL, nil)
	exchangeRequest.Header.Set("Authorization", "Bearer "+token.AccessToken)
	exchangeRequest.Header.Set("DPoP", proof)
	exchangeResponse, err := httpClient.Do(exchangeRequest)
	if err != nil {
		return Credentials{}, err
	}
	defer exchangeResponse.Body.Close()
	if exchangeResponse.StatusCode != http.StatusCreated {
		return Credentials{}, decodeAPIError(exchangeResponse)
	}
	var session struct {
		AccessToken string    `json:"accessToken"`
		ExpiresAt   time.Time `json:"expiresAt"`
		Subject     string    `json:"subject"`
	}
	if err := json.NewDecoder(exchangeResponse.Body).Decode(&session); err != nil {
		return Credentials{}, err
	}
	privateJWK, err := signer.PrivateJWK()
	if err != nil {
		return Credentials{}, err
	}
	return Credentials{Server: server, Token: session.AccessToken, ExpiresAt: session.ExpiresAt, Subject: session.Subject, Key: privateJWK}, nil
}

func decodeAPIError(response *http.Response) error {
	var payload struct {
		Error   string `json:"error"`
		Message string `json:"message"`
	}
	_ = json.NewDecoder(io.LimitReader(response.Body, 1<<20)).Decode(&payload)
	if payload.Error == "" {
		payload.Error = http.StatusText(response.StatusCode)
	}
	return &APIError{Status: response.StatusCode, Code: payload.Error, Message: payload.Message}
}
