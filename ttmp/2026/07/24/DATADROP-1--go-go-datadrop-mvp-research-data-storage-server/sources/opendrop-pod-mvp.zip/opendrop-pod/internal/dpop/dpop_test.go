package dpop

import (
	"context"
	"errors"
	"testing"
	"time"
)

func TestSignVerifyAndReplay(t *testing.T) {
	now := time.Unix(1_800_000_000, 0).UTC()
	signer, err := GenerateSigner()
	if err != nil {
		t.Fatal(err)
	}
	proof, err := signer.Sign("POST", "https://pod.example/xrpc/test?ignored=1", "token-value", now, "proof-1")
	if err != nil {
		t.Fatal(err)
	}
	replays := NewMemoryReplayStore(func() time.Time { return now })
	options := VerifyOptions{
		Method:      "POST",
		URL:         "https://pod.example/xrpc/test?different=2",
		AccessToken: "token-value",
		RequireATH:  true,
		Now:         func() time.Time { return now },
		ReplayStore: replays,
	}
	verified, err := Verify(context.Background(), proof, options)
	if err != nil {
		t.Fatal(err)
	}
	wantJKT, _ := signer.Thumbprint()
	if verified.Thumbprint != wantJKT {
		t.Fatalf("thumbprint=%q want %q", verified.Thumbprint, wantJKT)
	}
	if _, err := Verify(context.Background(), proof, options); !errors.Is(err, ErrReplay) {
		t.Fatalf("second verification error=%v, want ErrReplay", err)
	}
}

func TestRejectsWrongATHAndMethod(t *testing.T) {
	now := time.Unix(1_800_000_000, 0).UTC()
	signer, _ := GenerateSigner()
	proof, _ := signer.Sign("GET", "https://pod.example/resource", "right", now, "proof-2")
	base := VerifyOptions{
		Method:      "GET",
		URL:         "https://pod.example/resource",
		AccessToken: "wrong",
		RequireATH:  true,
		Now:         func() time.Time { return now },
	}
	if _, err := Verify(context.Background(), proof, base); !errors.Is(err, ErrInvalidProof) {
		t.Fatalf("wrong ath error=%v", err)
	}
	base.AccessToken = "right"
	base.Method = "POST"
	if _, err := Verify(context.Background(), proof, base); !errors.Is(err, ErrInvalidProof) {
		t.Fatalf("wrong method error=%v", err)
	}
}

func TestPrivateJWKRoundTrip(t *testing.T) {
	signer, err := GenerateSigner()
	if err != nil {
		t.Fatal(err)
	}
	jwk, err := signer.PrivateJWK()
	if err != nil {
		t.Fatal(err)
	}
	restored, err := SignerFromJWK(jwk)
	if err != nil {
		t.Fatal(err)
	}
	left, _ := signer.Thumbprint()
	right, _ := restored.Thumbprint()
	if left != right {
		t.Fatalf("restored thumbprint=%q want %q", right, left)
	}
}

func TestNonceBinding(t *testing.T) {
	now := time.Unix(1_800_000_000, 0).UTC()
	signer, err := GenerateSigner()
	if err != nil {
		t.Fatal(err)
	}
	proof, err := signer.SignWithNonce("GET", "https://pod.example/xrpc/io.opendrop.sync.websocket", "", now, "proof-nonce", "server-nonce")
	if err != nil {
		t.Fatal(err)
	}
	jkt, _ := signer.Thumbprint()
	_, err = Verify(context.Background(), proof, VerifyOptions{
		Method: "GET", URL: "https://pod.example/xrpc/io.opendrop.sync.websocket",
		ExpectedJKT: jkt, ExpectedNonce: "server-nonce", Now: func() time.Time { return now },
	})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := Verify(context.Background(), proof, VerifyOptions{
		Method: "GET", URL: "https://pod.example/xrpc/io.opendrop.sync.websocket",
		ExpectedJKT: jkt, ExpectedNonce: "different", Now: func() time.Time { return now },
	}); !errors.Is(err, ErrInvalidProof) {
		t.Fatalf("wrong nonce error=%v", err)
	}
}

func TestCanonicalHTUNormalizesDefaultPort(t *testing.T) {
	got, err := CanonicalHTU("HTTPS://Example.COM:443/path?ignored=1#fragment")
	if err != nil {
		t.Fatal(err)
	}
	if got != "https://example.com/path" {
		t.Fatalf("CanonicalHTU=%q", got)
	}
}

func TestCanonicalHTURejectsNonHTTP(t *testing.T) {
	for _, raw := range []string{"ws://pod.example/feed", "ftp://pod.example/file", "file:///tmp/value"} {
		if _, err := CanonicalHTU(raw); err == nil {
			t.Fatalf("CanonicalHTU(%q) succeeded, want error", raw)
		}
	}
}
