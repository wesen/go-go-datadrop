package dpop

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"math/big"
	"strings"
	"time"
)

// Signer owns one P-256 proof key.
type Signer struct {
	private *ecdsa.PrivateKey
	public  PublicJWK
}

// GenerateSigner creates a fresh proof key.
func GenerateSigner() (*Signer, error) {
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return nil, fmt.Errorf("generate P-256 key: %w", err)
	}
	return NewSigner(key)
}

// NewSigner validates and wraps a private key.
func NewSigner(key *ecdsa.PrivateKey) (*Signer, error) {
	if key == nil || key.Curve != elliptic.P256() || key.D == nil || key.X == nil || key.Y == nil {
		return nil, errors.New("signer requires a P-256 private key")
	}
	return &Signer{private: key, public: PublicJWK{
		Kty: "EC",
		Crv: "P-256",
		X:   coordinate(key.X),
		Y:   coordinate(key.Y),
	}}, nil
}

// Sign creates an ES256 DPoP proof for one HTTP request.
func (s *Signer) Sign(method, rawURL, accessToken string, now time.Time, jti string) (string, error) {
	return s.SignWithNonce(method, rawURL, accessToken, now, jti, "")
}

// SignWithNonce creates a proof carrying a server-provided DPoP nonce.
func (s *Signer) SignWithNonce(method, rawURL, accessToken string, now time.Time, jti, nonce string) (string, error) {
	if s == nil || s.private == nil {
		return "", errors.New("DPoP signer is not initialized")
	}
	htu, err := CanonicalHTU(rawURL)
	if err != nil {
		return "", err
	}
	if now.IsZero() {
		now = time.Now().UTC()
	}
	if strings.TrimSpace(jti) == "" {
		jti, err = randomID(18)
		if err != nil {
			return "", err
		}
	}
	header := proofHeader{Typ: "dpop+jwt", Alg: "ES256", JWK: s.public}
	claims := proofClaims{JTI: jti, HTM: strings.ToUpper(strings.TrimSpace(method)), HTU: htu, IAT: now.Unix(), Nonce: nonce}
	if accessToken != "" {
		claims.ATH = AccessTokenHash(accessToken)
	}
	headerJSON, err := json.Marshal(header)
	if err != nil {
		return "", err
	}
	claimsJSON, err := json.Marshal(claims)
	if err != nil {
		return "", err
	}
	encodedHeader := base64.RawURLEncoding.EncodeToString(headerJSON)
	encodedClaims := base64.RawURLEncoding.EncodeToString(claimsJSON)
	signingInput := encodedHeader + "." + encodedClaims
	digest := sha256.Sum256([]byte(signingInput))
	r, sigS, err := ecdsa.Sign(rand.Reader, s.private, digest[:])
	if err != nil {
		return "", fmt.Errorf("sign DPoP proof: %w", err)
	}
	signature := make([]byte, 64)
	r.FillBytes(signature[:32])
	sigS.FillBytes(signature[32:])
	return signingInput + "." + base64.RawURLEncoding.EncodeToString(signature), nil
}

func (s *Signer) PublicJWK() PublicJWK {
	if s == nil {
		return PublicJWK{}
	}
	return s.public
}

func (s *Signer) Thumbprint() (string, error) {
	if s == nil {
		return "", errors.New("DPoP signer is not initialized")
	}
	return s.public.Thumbprint()
}

func (s *Signer) PrivateJWK() (PrivateJWK, error) {
	if s == nil || s.private == nil {
		return PrivateJWK{}, errors.New("DPoP signer is not initialized")
	}
	return PrivateJWK{
		Kty: "EC", Crv: "P-256", X: s.public.X, Y: s.public.Y,
		D: coordinate(s.private.D),
	}, nil
}

func SignerFromJWK(jwk PrivateJWK) (*Signer, error) {
	if jwk.Kty != "EC" || jwk.Crv != "P-256" || jwk.D == "" {
		return nil, errors.New("private JWK must be EC P-256")
	}
	public := PublicJWK{Kty: jwk.Kty, Crv: jwk.Crv, X: jwk.X, Y: jwk.Y}
	publicKey, err := public.publicKey()
	if err != nil {
		return nil, err
	}
	dBytes, err := base64.RawURLEncoding.DecodeString(jwk.D)
	if err != nil || len(dBytes) != 32 {
		return nil, errors.New("private JWK d coordinate is invalid")
	}
	d := new(big.Int).SetBytes(dBytes)
	if d.Sign() <= 0 || d.Cmp(elliptic.P256().Params().N) >= 0 {
		return nil, errors.New("private JWK scalar is out of range")
	}
	derivedX, derivedY := elliptic.P256().ScalarBaseMult(dBytes)
	if derivedX.Cmp(publicKey.X) != 0 || derivedY.Cmp(publicKey.Y) != 0 {
		return nil, errors.New("private JWK public coordinates do not match d")
	}
	return NewSigner(&ecdsa.PrivateKey{PublicKey: *publicKey, D: d})
}

func coordinate(value *big.Int) string {
	buf := make([]byte, 32)
	value.FillBytes(buf)
	return base64.RawURLEncoding.EncodeToString(buf)
}

func randomID(bytes int) (string, error) {
	value := make([]byte, bytes)
	if _, err := rand.Read(value); err != nil {
		return "", fmt.Errorf("read randomness: %w", err)
	}
	return base64.RawURLEncoding.EncodeToString(value), nil
}
