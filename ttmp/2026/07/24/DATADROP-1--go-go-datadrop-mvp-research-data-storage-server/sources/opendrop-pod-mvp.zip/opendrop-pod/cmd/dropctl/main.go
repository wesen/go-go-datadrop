package main

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"mime"
	"net/http"
	"net/url"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"

	"github.com/go-go-golems/opendrop-pod/internal/client"
)

func main() {
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()
	if err := run(ctx, os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, "dropctl:", err)
		os.Exit(1)
	}
}

func run(ctx context.Context, args []string) error {
	if len(args) == 0 {
		usage()
		return errors.New("command is required")
	}
	credentialsPath, err := client.DefaultCredentialsPath()
	if err != nil {
		return err
	}
	command := args[0]
	if command == "login" {
		flags := flag.NewFlagSet("login", flag.ContinueOnError)
		server := flags.String("server", "http://127.0.0.1:8080", "OpenDrop Pod URL")
		path := flags.String("credentials", credentialsPath, "credentials file")
		if err := flags.Parse(args[1:]); err != nil {
			return err
		}
		credentials, err := client.LoginDevice(ctx, *server, os.Stdout)
		if err != nil {
			return err
		}
		if err := client.SaveCredentials(*path, credentials); err != nil {
			return err
		}
		fmt.Printf("Logged in as %s; credentials saved to %s\n", credentials.Subject, *path)
		return nil
	}

	path := credentialsPath
	if value := os.Getenv("OPENDROP_CREDENTIALS"); value != "" {
		path = value
	}
	credentials, err := client.LoadCredentials(path)
	if err != nil {
		return fmt.Errorf("load %s: %w; run dropctl login", path, err)
	}
	api, err := client.New(credentials)
	if err != nil {
		return err
	}

	switch command {
	case "whoami":
		var output any
		if err := api.Call(ctx, http.MethodGet, "io.opendrop.identity.getSession", nil, nil, &output); err != nil {
			return err
		}
		return printJSON(output)
	case "spaces":
		var output any
		if err := api.Call(ctx, http.MethodGet, "io.opendrop.repo.listSpaces", nil, nil, &output); err != nil {
			return err
		}
		return printJSON(output)
	case "space-create":
		flags := flag.NewFlagSet(command, flag.ContinueOnError)
		title := flags.String("title", "", "display title")
		if err := flags.Parse(args[1:]); err != nil {
			return err
		}
		if flags.NArg() != 1 {
			return errors.New("usage: dropctl space-create [--title TITLE] SPACE")
		}
		name := flags.Arg(0)
		if *title == "" {
			*title = name
		}
		return callAndPrint(ctx, api, http.MethodPost, "io.opendrop.repo.createSpace", nil, map[string]any{"name": name, "title": *title})
	case "put":
		if len(args) != 5 {
			return errors.New("usage: dropctl put SPACE COLLECTION RKEY JSON|@FILE|-")
		}
		value, err := readJSONArgument(args[4])
		if err != nil {
			return err
		}
		return callAndPrint(ctx, api, http.MethodPost, "io.opendrop.repo.putRecord", nil, map[string]any{"space": args[1], "collection": args[2], "rkey": args[3], "record": value})
	case "get":
		if len(args) != 4 {
			return errors.New("usage: dropctl get SPACE COLLECTION RKEY")
		}
		query := url.Values{"space": {args[1]}, "collection": {args[2]}, "rkey": {args[3]}}
		return callAndPrint(ctx, api, http.MethodGet, "io.opendrop.repo.getRecord", query, nil)
	case "records":
		if len(args) < 3 || len(args) > 4 {
			return errors.New("usage: dropctl records SPACE COLLECTION [CURSOR]")
		}
		query := url.Values{"space": {args[1]}, "collection": {args[2]}}
		if len(args) == 4 {
			query.Set("cursor", args[3])
		}
		return callAndPrint(ctx, api, http.MethodGet, "io.opendrop.repo.listRecords", query, nil)
	case "append":
		if len(args) != 4 {
			return errors.New("usage: dropctl append SPACE STREAM JSON|@FILE|-")
		}
		value, err := readJSONArgument(args[3])
		if err != nil {
			return err
		}
		return callAndPrint(ctx, api, http.MethodPost, "io.opendrop.stream.append", nil, map[string]any{"space": args[1], "stream": args[2], "data": value})
	case "events":
		if len(args) < 3 || len(args) > 4 {
			return errors.New("usage: dropctl events SPACE STREAM [AFTER]")
		}
		query := url.Values{"space": {args[1]}, "stream": {args[2]}}
		if len(args) == 4 {
			query.Set("after", args[3])
		}
		return callAndPrint(ctx, api, http.MethodGet, "io.opendrop.stream.list", query, nil)
	case "tail":
		flags := flag.NewFlagSet(command, flag.ContinueOnError)
		cursor := flags.Int64("cursor", 0, "resume cursor")
		if err := flags.Parse(args[1:]); err != nil {
			return err
		}
		if flags.NArg() != 1 {
			return errors.New("usage: dropctl tail [--cursor N] SPACE")
		}
		return api.Subscribe(ctx, flags.Arg(0), *cursor, func(line json.RawMessage) error {
			_, err := os.Stdout.Write(append(line, '\n'))
			return err
		})
	case "script-put":
		flags := flag.NewFlagSet(command, flag.ContinueOnError)
		trigger := flags.String("trigger", "", "stream trigger")
		disabled := flags.Bool("disabled", false, "install disabled")
		if err := flags.Parse(args[1:]); err != nil {
			return err
		}
		if flags.NArg() != 3 {
			return errors.New("usage: dropctl script-put [--trigger STREAM] SPACE NAME FILE")
		}
		source, err := os.ReadFile(flags.Arg(2))
		if err != nil {
			return err
		}
		return callAndPrint(ctx, api, http.MethodPost, "io.opendrop.script.put", nil, map[string]any{"space": flags.Arg(0), "name": flags.Arg(1), "source": string(source), "enabled": !*disabled, "triggerStream": *trigger})
	case "script-run":
		if len(args) < 3 || len(args) > 4 {
			return errors.New("usage: dropctl script-run SPACE NAME [JSON|@FILE|-]")
		}
		var input any = map[string]any{}
		if len(args) == 4 {
			input, err = readJSONArgument(args[3])
			if err != nil {
				return err
			}
		}
		return callAndPrint(ctx, api, http.MethodPost, "io.opendrop.script.run", nil, map[string]any{"space": args[1], "name": args[2], "input": input})
	case "script-runs":
		if len(args) != 2 {
			return errors.New("usage: dropctl script-runs SPACE")
		}
		return callAndPrint(ctx, api, http.MethodGet, "io.opendrop.script.listRuns", url.Values{"space": {args[1]}}, nil)
	case "site-config":
		flags := flag.NewFlagSet(command, flag.ContinueOnError)
		public := flags.Bool("public", false, "publish site")
		entrypoint := flags.String("entrypoint", "index.html", "entrypoint file")
		if err := flags.Parse(args[1:]); err != nil {
			return err
		}
		if flags.NArg() != 2 {
			return errors.New("usage: dropctl site-config [--public] [--entrypoint FILE] SPACE SITE")
		}
		return callAndPrint(ctx, api, http.MethodPost, "io.opendrop.site.put", nil, map[string]any{"space": flags.Arg(0), "name": flags.Arg(1), "public": *public, "entrypoint": *entrypoint})
	case "site-put":
		flags := flag.NewFlagSet(command, flag.ContinueOnError)
		remote := flags.String("path", "", "remote path; defaults to local basename")
		contentType := flags.String("content-type", "", "MIME type")
		if err := flags.Parse(args[1:]); err != nil {
			return err
		}
		if flags.NArg() != 3 {
			return errors.New("usage: dropctl site-put [--path REMOTE] SPACE SITE LOCAL_FILE")
		}
		body, err := os.ReadFile(flags.Arg(2))
		if err != nil {
			return err
		}
		if *remote == "" {
			*remote = filepath.Base(flags.Arg(2))
		}
		if *contentType == "" {
			*contentType = mime.TypeByExtension(filepath.Ext(*remote))
		}
		return callAndPrint(ctx, api, http.MethodPost, "io.opendrop.site.putFile", nil, map[string]any{"space": flags.Arg(0), "site": flags.Arg(1), "path": *remote, "contentType": *contentType, "contentBase64": base64.StdEncoding.EncodeToString(body)})
	case "sites":
		if len(args) != 2 {
			return errors.New("usage: dropctl sites SPACE")
		}
		return callAndPrint(ctx, api, http.MethodGet, "io.opendrop.site.list", url.Values{"space": {args[1]}}, nil)
	default:
		usage()
		return fmt.Errorf("unknown command %q", command)
	}
}

func callAndPrint(ctx context.Context, api *client.Client, method, procedure string, query url.Values, input any) error {
	var output any
	if err := api.Call(ctx, method, procedure, query, input, &output); err != nil {
		return err
	}
	return printJSON(output)
}

func printJSON(value any) error {
	encoder := json.NewEncoder(os.Stdout)
	encoder.SetIndent("", "  ")
	return encoder.Encode(value)
}

func readJSONArgument(argument string) (any, error) {
	var reader io.Reader
	switch {
	case argument == "-":
		reader = os.Stdin
	case strings.HasPrefix(argument, "@"):
		file, err := os.Open(strings.TrimPrefix(argument, "@"))
		if err != nil {
			return nil, err
		}
		defer file.Close()
		reader = file
	default:
		reader = strings.NewReader(argument)
	}
	decoder := json.NewDecoder(reader)
	decoder.UseNumber()
	var value any
	if err := decoder.Decode(&value); err != nil {
		return nil, err
	}
	return value, nil
}

func usage() {
	fmt.Fprintln(os.Stderr, `dropctl commands:
  login --server URL
  whoami
  spaces
  space-create [--title TITLE] SPACE
  put SPACE COLLECTION RKEY JSON|@FILE|-
  get SPACE COLLECTION RKEY
  records SPACE COLLECTION [CURSOR]
  append SPACE STREAM JSON|@FILE|-
  events SPACE STREAM [AFTER]
  tail [--cursor N] SPACE
  script-put [--trigger STREAM] SPACE NAME FILE
  script-run SPACE NAME [JSON|@FILE|-]
  script-runs SPACE
  site-config [--public] SPACE SITE
  site-put [--path REMOTE] SPACE SITE LOCAL_FILE
  sites SPACE`)
}
