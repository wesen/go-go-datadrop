package server

import (
	"encoding/base64"
	"encoding/json"
	"net"
	"net/http"
	"path"
	"strings"
	"time"

	"github.com/go-go-golems/opendrop-pod/internal/script"
	"github.com/go-go-golems/opendrop-pod/internal/store"
)

func (s *Server) handlePutScript(w http.ResponseWriter, r *http.Request) {
	var input struct {
		Space         string `json:"space"`
		Name          string `json:"name"`
		Source        string `json:"source"`
		Enabled       bool   `json:"enabled"`
		TriggerStream string `json:"triggerStream,omitempty"`
	}
	if !decodeBody(w, r, s.cfg.MaxRequestBytes, &input) {
		return
	}
	if err := requireSpace(input.Space); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	if err := requireName("script name", input.Name); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	if len(input.Source) == 0 || len(input.Source) > 256<<10 {
		writeError(w, http.StatusBadRequest, "InvalidRequest", "script source must contain 1..262144 bytes")
		return
	}
	if input.TriggerStream != "" {
		if err := requireName("trigger stream", input.TriggerStream); err != nil {
			writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
			return
		}
	}
	principal, _ := principalFromContext(r.Context())
	if _, err := s.store.RequireSpaceRole(r.Context(), principal.Subject, input.Space, true); err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	item, change, err := s.store.PutScript(r.Context(), principal.Subject, input.Space, input.Name, input.Source, input.Enabled, input.TriggerStream)
	if err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	s.hub.Publish(change)
	writeJSON(w, http.StatusOK, item)
}

func (s *Server) handleListScripts(w http.ResponseWriter, r *http.Request) {
	space := r.URL.Query().Get("space")
	if err := requireSpace(space); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	principal, _ := principalFromContext(r.Context())
	role, err := s.store.RequireSpaceRole(r.Context(), principal.Subject, space, false)
	if err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	items, err := s.store.ListScripts(r.Context(), space, role == "owner" || role == "writer")
	if err != nil {
		s.internalError(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"scripts": items})
}

func (s *Server) handleRunScript(w http.ResponseWriter, r *http.Request) {
	var input struct {
		Space string          `json:"space"`
		Name  string          `json:"name"`
		Input json.RawMessage `json:"input,omitempty"`
	}
	if !decodeBody(w, r, s.cfg.MaxRequestBytes, &input) {
		return
	}
	if err := requireSpace(input.Space); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	if err := requireName("script name", input.Name); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	principal, _ := principalFromContext(r.Context())
	if _, err := s.store.RequireSpaceRole(r.Context(), principal.Subject, input.Space, true); err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	item, err := s.store.GetScript(r.Context(), input.Space, input.Name)
	if err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	started := time.Now().UTC()
	output, runErr := s.runner.Run(r.Context(), item.Source, script.Invocation{Actor: principal.Subject, Space: input.Space, Trigger: "manual", Input: input.Input})
	finished := time.Now().UTC()
	run := store.ScriptRun{Space: item.Space, ScriptName: item.Name, Version: item.Version, Trigger: "manual", Status: "ok", Output: output, StartedAt: started, FinishedAt: finished}
	if runErr != nil {
		run.Status, run.Error = "error", runErr.Error()
	}
	if err := s.store.RecordScriptRun(r.Context(), run); err != nil {
		s.logger.Error("record manual script run", "error", err, "space", item.Space, "script", item.Name)
	}
	if runErr != nil {
		writeError(w, http.StatusUnprocessableEntity, "ScriptFailed", runErr.Error())
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"output": json.RawMessage(output), "version": item.Version})
}

func (s *Server) handleListScriptRuns(w http.ResponseWriter, r *http.Request) {
	space := r.URL.Query().Get("space")
	if err := requireSpace(space); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	principal, _ := principalFromContext(r.Context())
	if _, err := s.store.RequireSpaceRole(r.Context(), principal.Subject, space, false); err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	items, err := s.store.ListScriptRuns(r.Context(), space, int(parseInt64(r.URL.Query().Get("limit"), 100)))
	if err != nil {
		s.internalError(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"runs": items})
}

func (s *Server) handlePutSite(w http.ResponseWriter, r *http.Request) {
	var input struct {
		Space      string `json:"space"`
		Name       string `json:"name"`
		Public     bool   `json:"public"`
		Entrypoint string `json:"entrypoint"`
	}
	if !decodeBody(w, r, s.cfg.MaxRequestBytes, &input) {
		return
	}
	if err := requireSpace(input.Space); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	if err := requireName("site name", input.Name); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	if input.Entrypoint == "" {
		input.Entrypoint = "index.html"
	}
	entrypoint, err := cleanSitePath(input.Entrypoint)
	if err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	principal, _ := principalFromContext(r.Context())
	if _, err := s.store.RequireSpaceRole(r.Context(), principal.Subject, input.Space, true); err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	item, change, err := s.store.PutSite(r.Context(), principal.Subject, input.Space, input.Name, input.Public, entrypoint)
	if err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	s.hub.Publish(change)
	writeJSON(w, http.StatusOK, map[string]any{"site": item, "url": s.siteURL(item)})
}

func (s *Server) handlePutSiteFile(w http.ResponseWriter, r *http.Request) {
	var input struct {
		Space         string `json:"space"`
		Site          string `json:"site"`
		Path          string `json:"path"`
		ContentType   string `json:"contentType,omitempty"`
		ContentBase64 string `json:"contentBase64"`
	}
	if !decodeBody(w, r, 3<<20, &input) {
		return
	}
	if err := requireSpace(input.Space); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	if err := requireName("site name", input.Site); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	filePath, err := cleanSitePath(input.Path)
	if err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	body, err := base64.StdEncoding.DecodeString(input.ContentBase64)
	if err != nil || len(body) > 2<<20 {
		writeError(w, http.StatusBadRequest, "InvalidRequest", "contentBase64 must encode at most 2 MiB")
		return
	}
	principal, _ := principalFromContext(r.Context())
	if _, err := s.store.RequireSpaceRole(r.Context(), principal.Subject, input.Space, true); err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	item, change, err := s.store.PutSiteFile(r.Context(), principal.Subject, input.Space, input.Site, filePath, normalizeContentType(input.ContentType, filePath), body)
	if err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	s.hub.Publish(change)
	item.Body = nil
	writeJSON(w, http.StatusOK, item)
}

func (s *Server) handleListSites(w http.ResponseWriter, r *http.Request) {
	space := r.URL.Query().Get("space")
	if err := requireSpace(space); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	principal, _ := principalFromContext(r.Context())
	if _, err := s.store.RequireSpaceRole(r.Context(), principal.Subject, space, false); err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	items, err := s.store.ListSites(r.Context(), space)
	if err != nil {
		s.internalError(w, r, err)
		return
	}
	output := make([]map[string]any, 0, len(items))
	for _, item := range items {
		output = append(output, map[string]any{"site": item, "url": s.siteURL(item)})
	}
	writeJSON(w, http.StatusOK, map[string]any{"sites": output})
}

func (s *Server) siteURL(item store.Site) string {
	if s.siteBaseURL == nil {
		return ""
	}
	copy := *s.siteBaseURL
	hostname := item.Name + "." + item.Space + "." + s.siteBaseURL.Hostname()
	if port := s.siteBaseURL.Port(); port != "" {
		copy.Host = net.JoinHostPort(hostname, port)
	} else {
		copy.Host = hostname
	}
	copy.Path = "/"
	return copy.String()
}

func (s *Server) isSiteHost(hostPort string) bool {
	if s.siteBaseURL == nil {
		return false
	}
	host, port := requestHostParts(hostPort)
	baseHost := strings.ToLower(s.siteBaseURL.Hostname())
	return port == s.siteBaseURL.Port() && host != baseHost && strings.HasSuffix(host, "."+baseHost)
}

func requestHostParts(hostPort string) (string, string) {
	hostPort = strings.TrimSpace(hostPort)
	if host, port, err := net.SplitHostPort(hostPort); err == nil {
		return strings.ToLower(strings.Trim(host, "[]")), port
	}
	return strings.ToLower(strings.Trim(hostPort, "[]")), ""
}

func (s *Server) handlePublishedSite(w http.ResponseWriter, r *http.Request) {
	baseHost := strings.ToLower(s.siteBaseURL.Hostname())
	host, port := requestHostParts(r.Host)
	if port != s.siteBaseURL.Port() {
		http.NotFound(w, r)
		return
	}
	prefix := strings.TrimSuffix(host, "."+baseHost)
	labels := strings.Split(prefix, ".")
	if len(labels) != 2 || !namePattern.MatchString(labels[0]) || !spacePattern.MatchString(labels[1]) {
		http.NotFound(w, r)
		return
	}
	siteName, space := labels[0], labels[1]
	item, err := s.store.GetSite(r.Context(), space, siteName)
	if err != nil || !item.Public {
		http.NotFound(w, r)
		return
	}
	filePath := strings.TrimPrefix(r.URL.Path, "/")
	if filePath == "" {
		filePath = item.Entrypoint
	}
	filePath = path.Clean(filePath)
	if filePath == "." || strings.HasPrefix(filePath, "../") {
		http.NotFound(w, r)
		return
	}
	file, err := s.store.GetSiteFile(r.Context(), space, siteName, filePath)
	if err != nil {
		http.NotFound(w, r)
		return
	}
	if match := r.Header.Get("If-None-Match"); match == `"`+file.Digest+`"` {
		w.WriteHeader(http.StatusNotModified)
		return
	}
	w.Header().Set("Content-Type", file.ContentType)
	w.Header().Set("ETag", `"`+file.Digest+`"`)
	w.Header().Set("Cache-Control", "public, max-age=60")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Referrer-Policy", "strict-origin-when-cross-origin")
	w.Header().Set("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
	_, _ = w.Write(file.Body)
}
