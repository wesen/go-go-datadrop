package store

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
)

func (s *Store) CreateSpace(ctx context.Context, owner, name, title string) (Space, Change, error) {
	now := s.now().UTC()
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return Space{}, Change{}, err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, `INSERT INTO spaces(name,title,owner_sub,created_at) VALUES(?,?,?,?)`, name, title, owner, utcText(now)); err != nil {
		if isSQLiteConstraint(err) {
			return Space{}, Change{}, ErrConflict
		}
		return Space{}, Change{}, err
	}
	if _, err := tx.ExecContext(ctx, `INSERT INTO space_members(space_name,subject,role,created_at) VALUES(?,?,?,?)`, name, owner, "owner", utcText(now)); err != nil {
		return Space{}, Change{}, err
	}
	space := Space{Name: name, Title: title, Owner: owner, Role: "owner", CreatedAt: now}
	change, err := insertJSONChange(ctx, tx, Change{Type: "change", Space: name, Kind: "space.create", Actor: owner, CreatedAt: now}, space)
	if err != nil {
		return Space{}, Change{}, err
	}
	if err := tx.Commit(); err != nil {
		return Space{}, Change{}, err
	}
	return space, change, nil
}

func (s *Store) ListSpaces(ctx context.Context, subject string) ([]Space, error) {
	rows, err := s.db.QueryContext(ctx, `SELECT s.name,s.title,s.owner_sub,m.role,s.created_at FROM spaces s JOIN space_members m ON m.space_name=s.name WHERE m.subject=? ORDER BY s.name`, subject)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	spaces := make([]Space, 0)
	for rows.Next() {
		var item Space
		var created string
		if err := rows.Scan(&item.Name, &item.Title, &item.Owner, &item.Role, &created); err != nil {
			return nil, err
		}
		item.CreatedAt, err = parseTime(created)
		if err != nil {
			return nil, err
		}
		spaces = append(spaces, item)
	}
	return spaces, rows.Err()
}

func (s *Store) GetSpace(ctx context.Context, subject, name string) (Space, error) {
	var item Space
	var created string
	err := s.db.QueryRowContext(ctx, `SELECT s.name,s.title,s.owner_sub,m.role,s.created_at FROM spaces s JOIN space_members m ON m.space_name=s.name WHERE m.subject=? AND s.name=?`, subject, name).
		Scan(&item.Name, &item.Title, &item.Owner, &item.Role, &created)
	if errors.Is(err, sql.ErrNoRows) {
		return Space{}, ErrNotFound
	}
	if err != nil {
		return Space{}, err
	}
	item.CreatedAt, err = parseTime(created)
	return item, err
}

func (s *Store) RequireSpaceRole(ctx context.Context, subject, name string, write bool) (string, error) {
	var role string
	err := s.db.QueryRowContext(ctx, `SELECT role FROM space_members WHERE space_name=? AND subject=?`, name, subject).Scan(&role)
	if errors.Is(err, sql.ErrNoRows) {
		return "", ErrForbidden
	}
	if err != nil {
		return "", err
	}
	if write && role != "owner" && role != "writer" {
		return "", ErrForbidden
	}
	return role, nil
}

func (s *Store) PutMember(ctx context.Context, actor, space, subject, role string) (Change, error) {
	actorRole, err := s.RequireSpaceRole(ctx, actor, space, true)
	if err != nil {
		return Change{}, err
	}
	if actorRole != "owner" {
		return Change{}, ErrForbidden
	}
	if role != "reader" && role != "writer" && role != "owner" {
		return Change{}, fmt.Errorf("invalid role %q", role)
	}
	now := s.now().UTC()
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return Change{}, err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, `INSERT INTO space_members(space_name,subject,role,created_at) VALUES(?,?,?,?) ON CONFLICT(space_name,subject) DO UPDATE SET role=excluded.role`, space, subject, role, utcText(now)); err != nil {
		return Change{}, err
	}
	change, err := insertJSONChange(ctx, tx, Change{Type: "change", Space: space, Kind: "member.put", Actor: actor, CreatedAt: now}, map[string]any{"subject": subject, "role": role})
	if err != nil {
		return Change{}, err
	}
	if err := tx.Commit(); err != nil {
		return Change{}, err
	}
	return change, nil
}
