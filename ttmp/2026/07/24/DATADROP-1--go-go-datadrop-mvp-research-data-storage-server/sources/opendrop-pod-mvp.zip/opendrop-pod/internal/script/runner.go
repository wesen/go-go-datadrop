package script

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"regexp"
	"strings"
	"time"

	"github.com/dop251/goja"
	"github.com/go-go-golems/go-go-goja/pkg/engine"
	"github.com/go-go-golems/opendrop-pod/internal/store"
)

const (
	defaultTimeout            = 500 * time.Millisecond
	maxSourceBytes            = 256 << 10
	maxInputBytes             = 256 << 10
	maxOutputBytes            = 256 << 10
	maxCapabilityPayloadBytes = 256 << 10
	maxCapabilityOps          = 128
	maxCapabilityListEvents   = 100
)

var (
	capabilityNamePattern       = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$`)
	capabilityCollectionPattern = regexp.MustCompile(`^[A-Za-z][A-Za-z0-9.-]{0,127}$`)
	capabilityRKeyPattern       = regexp.MustCompile(`^[A-Za-z0-9._~:-]{1,256}$`)
)

type Backend interface {
	GetRecord(ctx context.Context, actor, space, collection, rkey string) (store.Record, error)
	PutRecord(ctx context.Context, actor, space, collection, rkey string, value json.RawMessage) (store.Record, error)
	AppendEvent(ctx context.Context, actor, space, stream string, data, meta json.RawMessage) (store.Event, error)
	ListEvents(ctx context.Context, actor, space, stream string, after int64, limit int) ([]store.Event, error)
}

type Invocation struct {
	Actor   string
	Space   string
	Trigger string
	Input   json.RawMessage
}

type Runner struct {
	factory *engine.RuntimeFactory
	backend Backend
	timeout time.Duration
}

func NewRunner(backend Backend, timeout time.Duration) (*Runner, error) {
	if backend == nil {
		return nil, errors.New("script backend is required")
	}
	if timeout <= 0 {
		timeout = defaultTimeout
	}
	factory, err := engine.NewRuntimeFactoryBuilder().
		UseModuleMiddleware(engine.MiddlewareSafe()).
		Build()
	if err != nil {
		return nil, fmt.Errorf("build safe goja runtime factory: %w", err)
	}
	return &Runner{factory: factory, backend: backend, timeout: timeout}, nil
}

// Run executes one synchronous CommonJS function in a fresh safe-mode runtime.
// The source must assign module.exports = function(ctx) { ... }.
func (r *Runner) Run(parent context.Context, source string, invocation Invocation) (json.RawMessage, error) {
	if r == nil || r.factory == nil {
		return nil, errors.New("script runner is not initialized")
	}
	if len(source) == 0 || len(source) > maxSourceBytes {
		return nil, fmt.Errorf("script source must contain 1..%d bytes", maxSourceBytes)
	}
	if len(invocation.Input) > maxInputBytes {
		return nil, fmt.Errorf("script input exceeds %d bytes", maxInputBytes)
	}
	if strings.TrimSpace(invocation.Actor) == "" || strings.TrimSpace(invocation.Space) == "" {
		return nil, errors.New("script actor and space are required")
	}
	if parent == nil {
		parent = context.Background()
	}
	ctx, cancel := context.WithTimeout(parent, r.timeout)
	defer cancel()
	runtime, err := r.factory.NewRuntime(engine.WithStartupContext(ctx), engine.WithLifetimeContext(ctx))
	if err != nil {
		return nil, fmt.Errorf("create goja runtime: %w", err)
	}
	defer runtime.Close(context.Background())
	vm := runtime.VM

	module := vm.NewObject()
	exports := vm.NewObject()
	if err := module.Set("exports", exports); err != nil {
		return nil, err
	}
	if err := vm.Set("module", module); err != nil {
		return nil, err
	}
	if err := vm.Set("exports", exports); err != nil {
		return nil, err
	}

	var input any = map[string]any{}
	if len(invocation.Input) != 0 && string(invocation.Input) != "null" {
		decoder := json.NewDecoder(strings.NewReader(string(invocation.Input)))
		decoder.UseNumber()
		if err := decoder.Decode(&input); err != nil {
			return nil, fmt.Errorf("decode script input: %w", err)
		}
		var extra any
		if err := decoder.Decode(&extra); err != io.EOF {
			return nil, errors.New("script input must contain exactly one JSON value")
		}
	}

	capabilities := &capabilitySet{
		ctx: ctx, backend: r.backend, actor: invocation.Actor, space: invocation.Space,
		remaining: maxCapabilityOps,
	}
	opendrop := vm.NewObject()
	for name, value := range map[string]any{
		"getRecord":  capabilities.getRecord,
		"putRecord":  capabilities.putRecord,
		"append":     capabilities.appendEvent,
		"listEvents": capabilities.listEvents,
		"now":        func() string { return time.Now().UTC().Format(time.RFC3339Nano) },
	} {
		if err := opendrop.Set(name, value); err != nil {
			return nil, fmt.Errorf("install %s capability: %w", name, err)
		}
	}

	interruptDone := make(chan struct{})
	go func() {
		select {
		case <-ctx.Done():
			vm.Interrupt(ctx.Err())
		case <-interruptDone:
		}
	}()
	defer func() {
		close(interruptDone)
		vm.ClearInterrupt()
	}()

	if _, err := vm.RunString("\"use strict\";\n" + source); err != nil {
		return nil, fmt.Errorf("evaluate script: %w", err)
	}
	exported := module.Get("exports")
	function, ok := goja.AssertFunction(exported)
	if !ok {
		return nil, errors.New("script must assign module.exports to a function")
	}
	argument := map[string]any{
		"actor":    invocation.Actor,
		"space":    invocation.Space,
		"trigger":  invocation.Trigger,
		"input":    input,
		"opendrop": opendrop,
	}
	result, err := function(goja.Undefined(), vm.ToValue(argument))
	if err != nil {
		return nil, fmt.Errorf("execute script: %w", err)
	}
	if goja.IsUndefined(result) {
		return json.RawMessage("null"), nil
	}
	if _, async := result.Export().(*goja.Promise); async {
		return nil, errors.New("async functions are not supported; use synchronous capability calls")
	}
	encoded, err := json.Marshal(result.Export())
	if err != nil {
		return nil, fmt.Errorf("encode script result: %w", err)
	}
	if len(encoded) > maxOutputBytes {
		return nil, fmt.Errorf("script output exceeds %d bytes", maxOutputBytes)
	}
	return encoded, nil
}

type capabilitySet struct {
	ctx       context.Context
	backend   Backend
	actor     string
	space     string
	remaining int
}

func (c *capabilitySet) take() error {
	if err := c.ctx.Err(); err != nil {
		return err
	}
	if c.remaining <= 0 {
		return errors.New("script capability call limit exceeded")
	}
	c.remaining--
	return nil
}

func (c *capabilitySet) getRecord(collection, rkey string) (any, error) {
	if err := c.take(); err != nil {
		return nil, err
	}
	if err := validateRecordAddress(collection, rkey); err != nil {
		return nil, err
	}
	item, err := c.backend.GetRecord(c.ctx, c.actor, c.space, collection, rkey)
	if err != nil {
		return nil, err
	}
	return rawJSONMap(item), nil
}

func (c *capabilitySet) putRecord(collection, rkey string, value any) (any, error) {
	if err := c.take(); err != nil {
		return nil, err
	}
	if err := validateRecordAddress(collection, rkey); err != nil {
		return nil, err
	}
	encoded, err := json.Marshal(value)
	if err != nil {
		return nil, err
	}
	if len(encoded) > maxCapabilityPayloadBytes {
		return nil, fmt.Errorf("record payload exceeds %d bytes", maxCapabilityPayloadBytes)
	}
	item, err := c.backend.PutRecord(c.ctx, c.actor, c.space, collection, rkey, encoded)
	if err != nil {
		return nil, err
	}
	return rawJSONMap(item), nil
}

func (c *capabilitySet) appendEvent(stream string, data any, meta any) (any, error) {
	if err := c.take(); err != nil {
		return nil, err
	}
	if !capabilityNamePattern.MatchString(stream) {
		return nil, errors.New("stream contains unsupported characters or is too long")
	}
	encodedData, err := json.Marshal(data)
	if err != nil {
		return nil, err
	}
	if len(encodedData) > maxCapabilityPayloadBytes {
		return nil, fmt.Errorf("event payload exceeds %d bytes", maxCapabilityPayloadBytes)
	}
	var encodedMeta []byte
	if meta != nil {
		encodedMeta, err = json.Marshal(meta)
		if err != nil {
			return nil, err
		}
		if len(encodedMeta) > maxCapabilityPayloadBytes {
			return nil, fmt.Errorf("event metadata exceeds %d bytes", maxCapabilityPayloadBytes)
		}
	}
	item, err := c.backend.AppendEvent(c.ctx, c.actor, c.space, stream, encodedData, encodedMeta)
	if err != nil {
		return nil, err
	}
	return rawJSONMap(item), nil
}

func (c *capabilitySet) listEvents(stream string, after int64, limit int) (any, error) {
	if err := c.take(); err != nil {
		return nil, err
	}
	if !capabilityNamePattern.MatchString(stream) {
		return nil, errors.New("stream contains unsupported characters or is too long")
	}
	if after < 0 || limit <= 0 || limit > maxCapabilityListEvents {
		return nil, fmt.Errorf("listEvents requires after >= 0 and limit in 1..%d", maxCapabilityListEvents)
	}
	items, err := c.backend.ListEvents(c.ctx, c.actor, c.space, stream, after, limit)
	if err != nil {
		return nil, err
	}
	return rawJSONMap(items), nil
}

func validateRecordAddress(collection, rkey string) error {
	if !capabilityCollectionPattern.MatchString(collection) {
		return errors.New("collection must be an NSID-like identifier")
	}
	if !capabilityRKeyPattern.MatchString(rkey) {
		return errors.New("record key contains unsupported characters or is too long")
	}
	return nil
}

func rawJSONMap(value any) any {
	encoded, _ := json.Marshal(value)
	var exported any
	decoder := json.NewDecoder(strings.NewReader(string(encoded)))
	decoder.UseNumber()
	_ = decoder.Decode(&exported)
	return exported
}
