// Package dpop implements the subset of RFC 9449 needed by OpenDrop Pod.
// It intentionally accepts ES256 proofs only.
package dpop

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/big"
	"net"
	"net/url"
	"strings"
	"time"
)

var (
	ErrInvalidProof = errors.New("invalid DPoP proof")
	ErrReplay       = errors.New("DPoP proof replayed")
)

// PublicJWK is the only public-key shape accepted by this implementation.
type PublicJWK struct {
	Kty string `json:"kty"`
	Crv string `json:"crv"`
	X   string `json:"x"`
	Y   string `json:"y"`
}

// PrivateJWK is used by the CLI. Browser keys remain non-extractable and are
// represented by WebCrypto CryptoKey objects instead.
type PrivateJWK struct {
	Kty string `json:"kty"`
	Crv string `json:"crv"`
	X   string `json:"x"`
	Y   string `json:"y"`
	D   string `json:"d"`
}

type proofHeader struct {
	Typ string    `json:"typ"`
	Alg string    `json:"alg"`
	JWK PublicJWK `json:"jwk"`
}

type proofClaims struct {
	JTI   string `json:"jti"`
	HTM   string `json:"htm"`
	HTU   string `json:"htu"`
	IAT   int64  `json:"iat"`
	ATH   string `json:"ath,omitempty"`
	Nonce string `json:"nonce,omitempty"`
}

// Proof is the validated, caller-useful result.
type Proof struct {
	JTI        string
	Thumbprint string
	IssuedAt   time.Time
	PublicKey  *ecdsa.PublicKey
}

// ReplayStore atomically records a proof identifier. It must return ErrReplay
// when the same (thumbprint, jti) pair has already been used.
type ReplayStore interface {
	UseDPoPProof(ctx context.Context, thumbprint, jti string, expiresAt time.Time) error
}

// VerifyOptions describes the HTTP request a proof must bind to.
type VerifyOptions struct {
	Method        string
	URL           string
	AccessToken   string
	RequireATH    bool
	ExpectedJKT   string
	ExpectedNonce string
	Now           func() time.Time
	MaxAge        time.Duration
	FutureSkew    time.Duration
	ReplayStore   ReplayStore
	ReplayExpiry  time.Duration
}

// Verify validates one compact DPoP proof. Query strings and fragments are
// removed from the expected URL before comparing htu, as required by RFC 9449.
func Verify(ctx context.Context, compact string, opts VerifyOptions) (Proof, error) {
	if ctx == nil {
		return Proof{}, fmt.Errorf("%w: context is required", ErrInvalidProof)
	}
	parts := strings.Split(compact, ".")
	if len(parts) != 3 || parts[0] == "" || parts[1] == "" || parts[2] == "" {
		return Proof{}, fmt.Errorf("%w: compact JWS must have three parts", ErrInvalidProof)
	}

	var header proofHeader
	if err := decodeSegment(parts[0], &header); err != nil {
		return Proof{}, fmt.Errorf("%w: decode header: %v", ErrInvalidProof, err)
	}
	if !strings.EqualFold(header.Typ, "dpop+jwt") || header.Alg != "ES256" {
		return Proof{}, fmt.Errorf("%w: typ must be dpop+jwt and alg must be ES256", ErrInvalidProof)
	}
	publicKey, err := header.JWK.publicKey()
	if err != nil {
		return Proof{}, fmt.Errorf("%w: %v", ErrInvalidProof, err)
	}

	signature, err := base64.RawURLEncoding.DecodeString(parts[2])
	if err != nil || len(signature) != 64 {
		return Proof{}, fmt.Errorf("%w: ES256 signature must be 64 raw bytes", ErrInvalidProof)
	}
	digest := sha256.Sum256([]byte(parts[0] + "." + parts[1]))
	r := new(big.Int).SetBytes(signature[:32])
	s := new(big.Int).SetBytes(signature[32:])
	if !ecdsa.Verify(publicKey, digest[:], r, s) {
		return Proof{}, fmt.Errorf("%w: signature verification failed", ErrInvalidProof)
	}

	var claims proofClaims
	if err := decodeSegment(parts[1], &claims); err != nil {
		return Proof{}, fmt.Errorf("%w: decode claims: %v", ErrInvalidProof, err)
	}
	if strings.TrimSpace(claims.JTI) == "" || len(claims.JTI) > 256 || strings.ContainsAny(claims.JTI, "\x00\r\n") {
		return Proof{}, fmt.Errorf("%w: jti is missing or invalid", ErrInvalidProof)
	}
	if !strings.EqualFold(claims.HTM, strings.TrimSpace(opts.Method)) {
		return Proof{}, fmt.Errorf("%w: htm mismatch", ErrInvalidProof)
	}
	expectedURL, err := CanonicalHTU(opts.URL)
	if err != nil {
		return Proof{}, fmt.Errorf("%w: invalid expected URL: %v", ErrInvalidProof, err)
	}
	proofURL, err := CanonicalHTU(claims.HTU)
	if err != nil || proofURL != expectedURL {
		return Proof{}, fmt.Errorf("%w: htu mismatch", ErrInvalidProof)
	}

	now := time.Now().UTC()
	if opts.Now != nil {
		now = opts.Now().UTC()
	}
	maxAge := opts.MaxAge
	if maxAge == 0 {
		maxAge = 5 * time.Minute
	}
	futureSkew := opts.FutureSkew
	if futureSkew == 0 {
		futureSkew = time.Minute
	}
	issuedAt := time.Unix(claims.IAT, 0).UTC()
	if claims.IAT <= 0 || issuedAt.Before(now.Add(-maxAge)) || issuedAt.After(now.Add(futureSkew)) {
		return Proof{}, fmt.Errorf("%w: iat is outside the accepted window", ErrInvalidProof)
	}

	if opts.RequireATH {
		if opts.AccessToken == "" || claims.ATH == "" || claims.ATH != AccessTokenHash(opts.AccessToken) {
			return Proof{}, fmt.Errorf("%w: ath mismatch", ErrInvalidProof)
		}
	} else if claims.ATH != "" && opts.AccessToken != "" && claims.ATH != AccessTokenHash(opts.AccessToken) {
		return Proof{}, fmt.Errorf("%w: ath mismatch", ErrInvalidProof)
	}

	thumbprint, err := header.JWK.Thumbprint()
	if err != nil {
		return Proof{}, fmt.Errorf("%w: calculate key thumbprint: %v", ErrInvalidProof, err)
	}
	if opts.ExpectedJKT != "" && thumbprint != opts.ExpectedJKT {
		return Proof{}, fmt.Errorf("%w: proof key does not match token binding", ErrInvalidProof)
	}
	if opts.ExpectedNonce != "" && claims.Nonce != opts.ExpectedNonce {
		return Proof{}, fmt.Errorf("%w: nonce mismatch", ErrInvalidProof)
	}
	if opts.ReplayStore != nil {
		replayExpiry := opts.ReplayExpiry
		if replayExpiry == 0 {
			replayExpiry = maxAge + futureSkew
		}
		if err := opts.ReplayStore.UseDPoPProof(ctx, thumbprint, claims.JTI, now.Add(replayExpiry)); err != nil {
			if errors.Is(err, ErrReplay) {
				return Proof{}, ErrReplay
			}
			return Proof{}, fmt.Errorf("record DPoP replay key: %w", err)
		}
	}
	return Proof{JTI: claims.JTI, Thumbprint: thumbprint, IssuedAt: issuedAt, PublicKey: publicKey}, nil
}

func decodeSegment(segment string, target any) error {
	data, err := base64.RawURLEncoding.DecodeString(segment)
	if err != nil {
		return err
	}
	decoder := json.NewDecoder(strings.NewReader(string(data)))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		return err
	}
	var extra any
	if err := decoder.Decode(&extra); err != io.EOF {
		if err == nil {
			return errors.New("multiple JSON values")
		}
		return err
	}
	return nil
}

// CanonicalHTU returns an absolute URI without userinfo, query, or fragment.
func CanonicalHTU(raw string) (string, error) {
	parsed, err := url.Parse(strings.TrimSpace(raw))
	if err != nil || parsed.Scheme == "" || parsed.Host == "" || parsed.User != nil {
		return "", errors.New("htu must be an absolute URL without userinfo")
	}
	parsed.RawQuery = ""
	parsed.ForceQuery = false
	parsed.Fragment = ""
	parsed.Scheme = strings.ToLower(parsed.Scheme)
	if parsed.Scheme != "http" && parsed.Scheme != "https" {
		return "", errors.New("htu scheme must be http or https")
	}
	hostname := strings.ToLower(parsed.Hostname())
	port := parsed.Port()
	if (parsed.Scheme == "http" && port == "80") || (parsed.Scheme == "https" && port == "443") {
		port = ""
	}
	if port != "" {
		parsed.Host = net.JoinHostPort(hostname, port)
	} else if strings.Contains(hostname, ":") {
		parsed.Host = "[" + hostname + "]"
	} else {
		parsed.Host = hostname
	}
	if parsed.Path == "" {
		parsed.Path = "/"
	}
	return parsed.String(), nil
}

// AccessTokenHash computes the ath claim value.
func AccessTokenHash(token string) string {
	digest := sha256.Sum256([]byte(token))
	return base64.RawURLEncoding.EncodeToString(digest[:])
}

func (jwk PublicJWK) publicKey() (*ecdsa.PublicKey, error) {
	if jwk.Kty != "EC" || jwk.Crv != "P-256" || jwk.X == "" || jwk.Y == "" {
		return nil, errors.New("jwk must be an EC P-256 public key")
	}
	xBytes, err := base64.RawURLEncoding.DecodeString(jwk.X)
	if err != nil || len(xBytes) != 32 {
		return nil, errors.New("jwk x coordinate is invalid")
	}
	yBytes, err := base64.RawURLEncoding.DecodeString(jwk.Y)
	if err != nil || len(yBytes) != 32 {
		return nil, errors.New("jwk y coordinate is invalid")
	}
	x := new(big.Int).SetBytes(xBytes)
	y := new(big.Int).SetBytes(yBytes)
	if !elliptic.P256().IsOnCurve(x, y) {
		return nil, errors.New("jwk point is not on P-256")
	}
	return &ecdsa.PublicKey{Curve: elliptic.P256(), X: x, Y: y}, nil
}

// Thumbprint computes the RFC 7638 SHA-256 JWK thumbprint.
func (jwk PublicJWK) Thumbprint() (string, error) {
	if _, err := jwk.publicKey(); err != nil {
		return "", err
	}
	canonical := `{"crv":"` + jwk.Crv + `","kty":"` + jwk.Kty + `","x":"` + jwk.X + `","y":"` + jwk.Y + `"}`
	digest := sha256.Sum256([]byte(canonical))
	return base64.RawURLEncoding.EncodeToString(digest[:]), nil
}
