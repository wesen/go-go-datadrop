package server

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/go-go-golems/opendrop-pod/internal/dpop"
	"github.com/go-go-golems/opendrop-pod/internal/store"
	"github.com/gorilla/websocket"
)

func (s *Server) handleSubscribe(w http.ResponseWriter, r *http.Request) {
	space := r.URL.Query().Get("space")
	if err := requireSpace(space); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	principal, _ := principalFromContext(r.Context())
	if _, err := s.store.RequireSpaceRole(r.Context(), principal.Subject, space, false); err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	flusher, ok := w.(http.Flusher)
	if !ok {
		writeError(w, http.StatusInternalServerError, "StreamingUnavailable", "HTTP streaming is unavailable")
		return
	}
	w.Header().Set("Content-Type", "application/x-ndjson; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Accel-Buffering", "no")
	w.WriteHeader(http.StatusOK)
	channel, cancel := s.hub.Subscribe(space)
	defer cancel()
	cursor := parseInt64(r.URL.Query().Get("cursor"), 0)
	encoder := json.NewEncoder(w)
	if !s.writeChangeHistory(r, encoder, flusher, space, &cursor) {
		return
	}
	heartbeat := time.NewTicker(15 * time.Second)
	defer heartbeat.Stop()
	for {
		select {
		case <-r.Context().Done():
			return
		case change, open := <-channel:
			if !open {
				_ = encoder.Encode(map[string]any{"type": "reset", "cursor": cursor, "reason": "slow_consumer"})
				flusher.Flush()
				return
			}
			if change.Cursor <= cursor {
				continue
			}
			if err := encoder.Encode(change); err != nil {
				return
			}
			cursor = change.Cursor
			flusher.Flush()
		case <-heartbeat.C:
			if err := encoder.Encode(map[string]any{"type": "heartbeat", "cursor": cursor, "time": time.Now().UTC()}); err != nil {
				return
			}
			flusher.Flush()
		}
	}
}

func (s *Server) writeChangeHistory(r *http.Request, encoder *json.Encoder, flusher http.Flusher, space string, cursor *int64) bool {
	for {
		changes, err := s.store.ListChanges(r.Context(), space, *cursor, 500)
		if err != nil {
			s.logger.Error("read feed history", "error", err, "space", space)
			return false
		}
		for _, change := range changes {
			if err := encoder.Encode(change); err != nil {
				return false
			}
			*cursor = change.Cursor
		}
		flusher.Flush()
		if len(changes) < 500 {
			return true
		}
	}
}

func (s *Server) handleCreateWSTicket(w http.ResponseWriter, r *http.Request) {
	var input struct {
		Space  string `json:"space"`
		Cursor int64  `json:"cursor,omitempty"`
		Origin string `json:"origin,omitempty"`
	}
	if !decodeBody(w, r, s.cfg.MaxRequestBytes, &input) {
		return
	}
	if err := requireSpace(input.Space); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	principal, _ := principalFromContext(r.Context())
	if _, err := s.store.RequireSpaceRole(r.Context(), principal.Subject, input.Space, false); err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	requestOrigin := strings.TrimSpace(r.Header.Get("Origin"))
	if input.Origin != "" && requestOrigin != "" && input.Origin != requestOrigin {
		writeError(w, http.StatusBadRequest, "InvalidRequest", "body origin does not match the request Origin header")
		return
	}
	origin := requestOrigin
	if origin == "" {
		origin = strings.TrimSpace(input.Origin)
	}
	if origin == "" {
		origin = s.publicURL.Scheme + "://" + s.publicURL.Host
	}
	if !s.originAllowed(origin) {
		writeError(w, http.StatusForbidden, "OriginDenied", "origin is not allowed")
		return
	}
	origin, _ = canonicalOrigin(origin)
	ticket, err := s.store.CreateWSTicket(r.Context(), store.WSTicket{
		Subject: principal.Subject, JKT: principal.JKT, Space: input.Space, Cursor: input.Cursor, Origin: origin,
	}, s.cfg.WSTicketTTL)
	if err != nil {
		s.internalError(w, r, err)
		return
	}
	websocketURL := *s.publicURL
	if websocketURL.Scheme == "https" {
		websocketURL.Scheme = "wss"
	} else {
		websocketURL.Scheme = "ws"
	}
	websocketURL.Path = "/xrpc/io.opendrop.sync.websocket"
	websocketURL.RawQuery = url.Values{"ticket": {ticket}}.Encode()
	writeJSON(w, http.StatusCreated, map[string]any{"ticket": ticket, "url": websocketURL.String(), "expiresIn": int(s.cfg.WSTicketTTL.Seconds())})
}

func (s *Server) authenticateWebSocket(r *http.Request, connection *websocket.Conn, ticket store.WSTicket) error {
	nonceBytes := make([]byte, 24)
	if _, err := rand.Read(nonceBytes); err != nil {
		return err
	}
	nonce := base64.RawURLEncoding.EncodeToString(nonceBytes)
	htu := s.requestURL(r)
	_ = connection.SetReadDeadline(time.Now().Add(10 * time.Second))
	if err := connection.WriteJSON(map[string]any{"type": "dpop_challenge", "nonce": nonce, "htu": htu}); err != nil {
		return err
	}
	messageType, payload, err := connection.ReadMessage()
	if err != nil {
		return err
	}
	if messageType != websocket.TextMessage {
		return errors.New("websocket authentication message must be text JSON")
	}
	var response struct {
		Type  string `json:"type"`
		Proof string `json:"proof"`
	}
	decoder := json.NewDecoder(strings.NewReader(string(payload)))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&response); err != nil {
		return err
	}
	var extra any
	if err := decoder.Decode(&extra); err != io.EOF {
		if err == nil {
			return errors.New("websocket authentication message must contain one JSON value")
		}
		return err
	}
	if response.Type != "dpop_proof" || response.Proof == "" {
		return errors.New("websocket DPoP proof response is invalid")
	}
	if _, err := dpop.Verify(r.Context(), response.Proof, dpop.VerifyOptions{
		Method: http.MethodGet, URL: htu, ExpectedJKT: ticket.JKT, ExpectedNonce: nonce,
		ReplayStore: s.store,
	}); err != nil {
		return err
	}
	if err := connection.WriteJSON(map[string]any{"type": "ready", "cursor": ticket.Cursor}); err != nil {
		return err
	}
	return nil
}

func (s *Server) handleWebSocket(w http.ResponseWriter, r *http.Request) {
	value := r.URL.Query().Get("ticket")
	if value == "" {
		writeError(w, http.StatusUnauthorized, "InvalidTicket", "websocket ticket is required")
		return
	}
	ticket, err := s.store.ConsumeWSTicket(r.Context(), value)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "InvalidTicket", "websocket ticket is invalid, expired, or already used")
		return
	}
	origin := strings.TrimSpace(r.Header.Get("Origin"))
	if origin == "" {
		origin = ticket.Origin
	}
	canonical, err := canonicalOrigin(origin)
	if err != nil || canonical != ticket.Origin {
		writeError(w, http.StatusForbidden, "OriginDenied", "websocket origin does not match the ticket")
		return
	}
	if _, err := s.store.RequireSpaceRole(r.Context(), ticket.Subject, ticket.Space, false); err != nil {
		writeError(w, http.StatusForbidden, "Forbidden", "space access has been revoked")
		return
	}
	upgrader := websocket.Upgrader{
		HandshakeTimeout: 10 * time.Second,
		CheckOrigin: func(request *http.Request) bool {
			raw := strings.TrimSpace(request.Header.Get("Origin"))
			if raw == "" {
				raw = ticket.Origin
			}
			candidate, err := canonicalOrigin(raw)
			return err == nil && candidate == ticket.Origin
		},
	}
	connection, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		return
	}
	defer connection.Close()
	connection.SetReadLimit(16 << 10)
	if err := s.authenticateWebSocket(r, connection, ticket); err != nil {
		s.logger.Info("rejected websocket DPoP challenge", "error", err, "subject", ticket.Subject, "space", ticket.Space)
		_ = connection.WriteControl(websocket.CloseMessage, websocket.FormatCloseMessage(websocket.ClosePolicyViolation, "DPoP proof required"), time.Now().Add(2*time.Second))
		return
	}
	connection.SetReadLimit(1024)
	_ = connection.SetReadDeadline(time.Now().Add(60 * time.Second))
	connection.SetPongHandler(func(string) error {
		return connection.SetReadDeadline(time.Now().Add(60 * time.Second))
	})
	readDone := make(chan struct{})
	go func() {
		defer close(readDone)
		for {
			if _, _, err := connection.ReadMessage(); err != nil {
				return
			}
		}
	}()
	channel, cancel := s.hub.Subscribe(ticket.Space)
	defer cancel()
	cursor := ticket.Cursor
	for {
		changes, err := s.store.ListChanges(r.Context(), ticket.Space, cursor, 500)
		if err != nil {
			return
		}
		for _, change := range changes {
			if err := connection.WriteJSON(change); err != nil {
				return
			}
			cursor = change.Cursor
		}
		if len(changes) < 500 {
			break
		}
	}
	ping := time.NewTicker(25 * time.Second)
	defer ping.Stop()
	for {
		select {
		case <-r.Context().Done():
			return
		case <-readDone:
			return
		case change, open := <-channel:
			if !open {
				_ = connection.WriteJSON(map[string]any{"type": "reset", "cursor": cursor, "reason": "slow_consumer"})
				return
			}
			if change.Cursor <= cursor {
				continue
			}
			if err := connection.WriteJSON(change); err != nil {
				return
			}
			cursor = change.Cursor
		case <-ping.C:
			if err := connection.WriteControl(websocket.PingMessage, []byte("ping"), time.Now().Add(5*time.Second)); err != nil {
				return
			}
		}
	}
}
