package server

import (
	"encoding/json"
	"net/http"
	"strings"
)

func (s *Server) handleCreateSpace(w http.ResponseWriter, r *http.Request) {
	var input struct {
		Name  string `json:"name"`
		Title string `json:"title"`
	}
	if !decodeBody(w, r, s.cfg.MaxRequestBytes, &input) {
		return
	}
	if err := requireSpace(input.Name); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	input.Title = strings.TrimSpace(input.Title)
	if input.Title == "" {
		input.Title = input.Name
	}
	if len(input.Title) > 120 {
		writeError(w, http.StatusBadRequest, "InvalidRequest", "title exceeds 120 characters")
		return
	}
	principal, _ := principalFromContext(r.Context())
	space, change, err := s.store.CreateSpace(r.Context(), principal.Subject, input.Name, input.Title)
	if err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	s.hub.Publish(change)
	writeJSON(w, http.StatusCreated, space)
}

func (s *Server) handleListSpaces(w http.ResponseWriter, r *http.Request) {
	principal, _ := principalFromContext(r.Context())
	spaces, err := s.store.ListSpaces(r.Context(), principal.Subject)
	if err != nil {
		s.internalError(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"spaces": spaces})
}

func (s *Server) handleGetRecord(w http.ResponseWriter, r *http.Request) {
	space, collection, rkey := r.URL.Query().Get("space"), r.URL.Query().Get("collection"), r.URL.Query().Get("rkey")
	if err := validateRecordAddress(space, collection, rkey); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	principal, _ := principalFromContext(r.Context())
	if _, err := s.store.RequireSpaceRole(r.Context(), principal.Subject, space, false); err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	item, err := s.store.GetRecord(r.Context(), space, collection, rkey)
	if err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	w.Header().Set("ETag", `"`+item.Digest+`"`)
	writeJSON(w, http.StatusOK, item)
}

func (s *Server) handleListRecords(w http.ResponseWriter, r *http.Request) {
	space, collection := r.URL.Query().Get("space"), r.URL.Query().Get("collection")
	if err := requireSpace(space); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	if err := requireCollection(collection); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	principal, _ := principalFromContext(r.Context())
	if _, err := s.store.RequireSpaceRole(r.Context(), principal.Subject, space, false); err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	limit := int(parseInt64(r.URL.Query().Get("limit"), 100))
	items, cursor, err := s.store.ListRecords(r.Context(), space, collection, r.URL.Query().Get("cursor"), limit)
	if err != nil {
		s.internalError(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"records": items, "cursor": cursor})
}

func (s *Server) handlePutRecord(w http.ResponseWriter, r *http.Request) {
	var input struct {
		Space      string          `json:"space"`
		Collection string          `json:"collection"`
		RKey       string          `json:"rkey"`
		Record     json.RawMessage `json:"record"`
		SwapRev    *int64          `json:"swapRev,omitempty"`
	}
	if !decodeBody(w, r, s.cfg.MaxRequestBytes, &input) {
		return
	}
	if err := validateRecordAddress(input.Space, input.Collection, input.RKey); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	principal, _ := principalFromContext(r.Context())
	if _, err := s.store.RequireSpaceRole(r.Context(), principal.Subject, input.Space, true); err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	item, change, err := s.store.PutRecord(r.Context(), principal.Subject, input.Space, input.Collection, input.RKey, input.Record, input.SwapRev)
	if err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	s.hub.Publish(change)
	w.Header().Set("ETag", `"`+item.Digest+`"`)
	writeJSON(w, http.StatusOK, item)
}

func (s *Server) handleDeleteRecord(w http.ResponseWriter, r *http.Request) {
	var input struct {
		Space      string `json:"space"`
		Collection string `json:"collection"`
		RKey       string `json:"rkey"`
		SwapRev    *int64 `json:"swapRev,omitempty"`
	}
	if !decodeBody(w, r, s.cfg.MaxRequestBytes, &input) {
		return
	}
	if err := validateRecordAddress(input.Space, input.Collection, input.RKey); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	principal, _ := principalFromContext(r.Context())
	if _, err := s.store.RequireSpaceRole(r.Context(), principal.Subject, input.Space, true); err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	change, err := s.store.DeleteRecord(r.Context(), principal.Subject, input.Space, input.Collection, input.RKey, input.SwapRev)
	if err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	s.hub.Publish(change)
	writeJSON(w, http.StatusOK, map[string]any{"deleted": true, "cursor": change.Cursor})
}

func (s *Server) handleAppendEvent(w http.ResponseWriter, r *http.Request) {
	var input struct {
		Space  string          `json:"space"`
		Stream string          `json:"stream"`
		Data   json.RawMessage `json:"data"`
		Meta   json.RawMessage `json:"meta,omitempty"`
	}
	if !decodeBody(w, r, s.cfg.MaxRequestBytes, &input) {
		return
	}
	if err := requireSpace(input.Space); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	if err := requireName("stream", input.Stream); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	principal, _ := principalFromContext(r.Context())
	if _, err := s.store.RequireSpaceRole(r.Context(), principal.Subject, input.Space, true); err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	event, change, err := s.store.AppendEvent(r.Context(), principal.Subject, input.Space, input.Stream, input.Data, input.Meta)
	if err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	s.hub.Publish(change)
	if s.dispatcher != nil {
		s.dispatcher.Enqueue(event)
	}
	writeJSON(w, http.StatusCreated, event)
}

func (s *Server) handleListEvents(w http.ResponseWriter, r *http.Request) {
	space, stream := r.URL.Query().Get("space"), r.URL.Query().Get("stream")
	if err := requireSpace(space); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	if err := requireName("stream", stream); err != nil {
		writeError(w, http.StatusBadRequest, "InvalidRequest", err.Error())
		return
	}
	principal, _ := principalFromContext(r.Context())
	if _, err := s.store.RequireSpaceRole(r.Context(), principal.Subject, space, false); err != nil {
		s.mapStoreError(w, r, err)
		return
	}
	after := parseInt64(r.URL.Query().Get("after"), 0)
	limit := int(parseInt64(r.URL.Query().Get("limit"), 100))
	items, err := s.store.ListEvents(r.Context(), space, stream, after, limit)
	if err != nil {
		s.internalError(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"events": items})
}

func validateRecordAddress(space, collection, rkey string) error {
	if err := requireSpace(space); err != nil {
		return err
	}
	if err := requireCollection(collection); err != nil {
		return err
	}
	return requireRKey(rkey)
}
