module.exports = function (ctx) {
  const event = ctx.input.event || ctx.input;
  const temperature = Number(event.data?.temperature ?? event.temperature);

  if (!Number.isFinite(temperature)) {
    return { ignored: true, reason: "temperature is missing" };
  }
  if (temperature >= 3) {
    return { ok: true, temperature };
  }

  return ctx.opendrop.append("alerts", {
    kind: "frost-risk",
    temperature,
    sourceEvent: event.id || null,
    detectedAt: ctx.opendrop.now(),
  }, {
    script: "frost-check",
    trigger: ctx.trigger,
  });
};
