# OpenDrop Pod build report

**Report date:** 2026-07-23  
**Source status:** runnable MVP implementation  
**Compatibility claim:** PDS-shaped and XRPC-shaped; not AT Protocol wire-compatible

## Delivered components

The repository contains two Go binaries:

- `opendrop-pod`: embedded identity provider, storage API, DPoP session layer, record and stream storage, realtime feeds, goja script execution, and static-site serving.
- `dropctl`: tiny-idp device login plus DPoP-authenticated storage operations.

The browser bundle contains:

- OAuth authorization-code flow with PKCE;
- an IndexedDB session store;
- a non-extractable WebCrypto P-256 proof key;
- DPoP proof generation;
- record and stream helpers;
- fetch-based NDJSON subscriptions;
- one-use WebSocket tickets with a post-upgrade DPoP nonce proof.

## Validation performed in this environment

| Check | Result | Scope |
|---|---|---|
| `gofmt` | Passed | All Go source files |
| `node --check` | Passed | Browser SDK, administration console, example script |
| DPoP unit tests | Passed | Signature, `ath`, method/URI binding, replay rejection, nonce binding, JWK round-trip, URL normalization, non-HTTP rejection |
| Origin unit tests | Passed | HTTP(S) origin canonicalization |
| Realtime hub unit tests | Passed | Subscription, delivery, and slow-consumer behavior |
| SQLite schema smoke test | Passed | Schema execution, foreign keys, basic record/change cursor insertion |
| Full Go package compile against API-shaped stubs | Passed | Every package and both commands; tests not executed in this mode |
| Upstream API review | Passed manually | tiny-idp v0.0.3 embedding/bootstrap/account/introspection APIs and go-go-goja runtime factory/lifecycle APIs |

## Validation not performed

The active container has Go 1.23.2 and cannot resolve or download the real module graph. The project and pinned dependencies require Go 1.26.x. Consequently, the following checks were not represented as completed:

- dependency-resolved `go mod tidy`;
- dependency-resolved `go test ./...`;
- `go vet ./...` and `go test -race ./...` against the real dependencies;
- CGO integration with the real `go-sqlite3` driver;
- a real tiny-idp OAuth browser/device flow;
- a real go-go-goja script invocation;
- browser WebCrypto, Fetch stream, and WebSocket end-to-end tests;
- Docker image construction.

The API-shaped compile is useful for catching local type errors and validating the expected upstream surface. It is not a substitute for a dependency-resolved build.

## Required release gate

Run on a machine with Go 1.26.5 or newer and a C compiler:

```bash
go mod tidy
go test ./...
go vet ./...
go test -race ./...
make build
./scripts/smoke.sh
```

Then test the browser flow over HTTPS using a dedicated wildcard site domain. A release should not be tagged until those commands and a browser OAuth/realtime scenario pass with the exact committed `go.sum`.

## Upstream assumptions

The implementation pins:

```text
github.com/go-go-golems/tiny-idp v0.0.3
github.com/go-go-golems/go-go-goja v0.10.5-0.20260717152521-c6e464c5bbc6
github.com/dop251/goja v0.0.0-20251103141225-af2ceb9156d7
```

The storage-session bridge exists because the pinned tiny-idp strict engine does not yet provide a complete production sender-constrained DPoP token flow. After the bridge, every storage request is bound to the browser or CLI proof key.

The goja runner uses a fresh `go-go-goja` runtime per call and `MiddlewareSafe`, which selects the data-safe module set. This remains in-process isolation and has no hard heap limit; it is not a hostile multi-tenant sandbox.
