package opendrop

import (
	"context"
	"encoding/json"
	"strings"
	"testing"
	"time"
)

func TestScriptRunnerExecutesBoundedCommonJS(t *testing.T) {
	t.Parallel()
	runner, err := NewScriptRunner()
	if err != nil {
		t.Fatal(err)
	}
	source := `module.exports.render = ({ input }) => ({html: "<h1>" + input.title + "</h1>", version: opendrop.version});`
	if err := runner.Validate(context.Background(), source); err != nil {
		t.Fatal(err)
	}
	result, err := runner.Run(context.Background(), source, ScriptInvocation{
		Export: "render", Input: map[string]any{"input": map[string]any{"title": "Greenhouse"}},
	})
	if err != nil {
		t.Fatal(err)
	}
	var decoded map[string]any
	if err := json.Unmarshal(result, &decoded); err != nil {
		t.Fatal(err)
	}
	if decoded["html"] != "<h1>Greenhouse</h1>" || decoded["version"] != "0.1" {
		t.Fatalf("result = %#v", decoded)
	}
}

func TestScriptRunnerRejectsMissingExportsUnsafeModulesAndPromises(t *testing.T) {
	t.Parallel()
	runner, err := NewScriptRunner()
	if err != nil {
		t.Fatal(err)
	}
	if err := runner.Validate(context.Background(), `module.exports = {};`); err == nil {
		t.Fatal("script without render/transform was accepted")
	}
	if err := runner.Validate(context.Background(), `const fs = require("fs"); module.exports.render = () => fs.readFileSync("/etc/passwd", "utf8");`); err == nil {
		t.Fatal("unsafe fs module was accepted")
	}
	if err := runner.Validate(context.Background(), `const timer = require("timer"); module.exports.render = () => timer;`); err == nil {
		t.Fatal("timer module was accepted")
	}
	_, err = runner.Run(context.Background(), `module.exports.render = () => Promise.resolve({ok:true});`, ScriptInvocation{Export: "render"})
	if err == nil || !strings.Contains(err.Error(), "synchronously") {
		t.Fatalf("promise error = %v", err)
	}
}

func TestScriptRunnerDisablesTimersAndBoundsConsole(t *testing.T) {
	t.Parallel()
	runner, err := NewScriptRunner()
	if err != nil {
		t.Fatal(err)
	}
	result, err := runner.Run(context.Background(), `
		module.exports.render = () => {
			console.log("discarded", {large: "value"});
			return {
				timeout: typeof setTimeout,
				interval: typeof setInterval,
				immediate: typeof setImmediate,
			};
		};
	`, ScriptInvocation{Export: "render"})
	if err != nil {
		t.Fatal(err)
	}
	var decoded map[string]string
	if err := json.Unmarshal(result, &decoded); err != nil {
		t.Fatal(err)
	}
	for name, value := range decoded {
		if value != "undefined" {
			t.Fatalf("%s global type = %q, want undefined", name, value)
		}
	}
}

func TestScriptRunnerInterruptsInfiniteLoop(t *testing.T) {
	runner, err := NewScriptRunner()
	if err != nil {
		t.Fatal(err)
	}
	runner.timeout = 50 * time.Millisecond
	started := time.Now()
	_, err = runner.Run(context.Background(), `module.exports.render = () => { while (true) {} };`, ScriptInvocation{Export: "render"})
	if err == nil || !strings.Contains(err.Error(), "deadline") {
		t.Fatalf("infinite loop error = %v", err)
	}
	if elapsed := time.Since(started); elapsed > 2*time.Second {
		t.Fatalf("interrupt took %s", elapsed)
	}
}
