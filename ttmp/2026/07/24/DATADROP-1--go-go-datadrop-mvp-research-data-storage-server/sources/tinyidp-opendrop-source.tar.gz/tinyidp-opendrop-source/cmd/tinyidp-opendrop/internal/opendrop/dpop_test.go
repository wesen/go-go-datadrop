package opendrop

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"math/big"
	"net/http/httptest"
	"path/filepath"
	"testing"
	"time"
)

func TestDPoPVerifierValidatesBindingAndReplay(t *testing.T) {
	t.Parallel()
	ctx := context.Background()
	store, err := OpenStore(ctx, filepath.Join(t.TempDir(), "opendrop.sqlite"))
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close()
	verifier, err := NewDPoPVerifier("https://drop.example", store)
	if err != nil {
		t.Fatal(err)
	}
	now := time.Date(2026, 7, 23, 18, 42, 31, 0, time.UTC)
	verifier.now = func() time.Time { return now }
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	const accessToken = "bound-access-token"
	request := httptest.NewRequest("POST", "https://internal/xrpc/io.opendrop.record.put?ignored=query", nil)
	proof := signDPoPProof(t, key, "POST", "https://drop.example/xrpc/io.opendrop.record.put", accessToken, "proof-1", now)
	validated, err := verifier.Validate(ctx, request, proof, accessToken, "")
	if err != nil {
		t.Fatal(err)
	}
	if validated.JKT == "" || validated.JTI != "proof-1" {
		t.Fatalf("proof = %#v", validated)
	}
	if _, err := verifier.Validate(ctx, request, proof, accessToken, validated.JKT); err == nil {
		t.Fatal("replayed proof was accepted")
	}

	wrongTokenProof := signDPoPProof(t, key, "POST", "https://drop.example/xrpc/io.opendrop.record.put", "different-token", "proof-2", now)
	if _, err := verifier.Validate(ctx, request, wrongTokenProof, accessToken, validated.JKT); err == nil {
		t.Fatal("proof with wrong ath was accepted")
	}
	wrongMethodProof := signDPoPProof(t, key, "GET", "https://drop.example/xrpc/io.opendrop.record.put", accessToken, "proof-3", now)
	if _, err := verifier.Validate(ctx, request, wrongMethodProof, accessToken, validated.JKT); err == nil {
		t.Fatal("proof with wrong method was accepted")
	}
}

func TestDPoPVerifierRejectsPrivateJWK(t *testing.T) {
	t.Parallel()
	store := &memoryReplayStore{seen: map[string]struct{}{}}
	verifier, err := NewDPoPVerifier("https://drop.example", store)
	if err != nil {
		t.Fatal(err)
	}
	now := time.Now().UTC()
	verifier.now = func() time.Time { return now }
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	proof := signDPoPProofWithPrivateMember(t, key, "GET", "https://drop.example/xrpc/test", "token", "private-jwk", now)
	request := httptest.NewRequest("GET", "https://internal/xrpc/test", nil)
	if _, err := verifier.Validate(context.Background(), request, proof, "token", ""); err == nil {
		t.Fatal("private JWK member was accepted")
	}
}

type memoryReplayStore struct{ seen map[string]struct{} }

func (m *memoryReplayStore) RememberDPoPProof(_ context.Context, jkt, jti string, _ time.Time) error {
	key := jkt + "\x00" + jti
	if _, ok := m.seen[key]; ok {
		return ErrReplay
	}
	m.seen[key] = struct{}{}
	return nil
}

func signDPoPProof(t *testing.T, key *ecdsa.PrivateKey, method, htu, token, jti string, issuedAt time.Time) string {
	t.Helper()
	return signDPoP(t, key, method, htu, token, jti, issuedAt, false)
}

func signDPoPProofWithPrivateMember(t *testing.T, key *ecdsa.PrivateKey, method, htu, token, jti string, issuedAt time.Time) string {
	t.Helper()
	return signDPoP(t, key, method, htu, token, jti, issuedAt, true)
}

func signDPoP(t *testing.T, key *ecdsa.PrivateKey, method, htu, token, jti string, issuedAt time.Time, includePrivate bool) string {
	t.Helper()
	jwk := map[string]any{
		"kty": "EC", "crv": "P-256",
		"x": base64.RawURLEncoding.EncodeToString(paddedCoordinate(key.PublicKey.X)),
		"y": base64.RawURLEncoding.EncodeToString(paddedCoordinate(key.PublicKey.Y)),
	}
	if includePrivate {
		jwk["d"] = base64.RawURLEncoding.EncodeToString(paddedCoordinate(key.D))
	}
	header, err := json.Marshal(map[string]any{"typ": "dpop+jwt", "alg": "ES256", "jwk": jwk})
	if err != nil {
		t.Fatal(err)
	}
	claims, err := json.Marshal(map[string]any{
		"jti": jti, "htm": method, "htu": htu, "iat": issuedAt.Unix(), "ath": accessTokenHash(token),
	})
	if err != nil {
		t.Fatal(err)
	}
	encodedHeader := base64.RawURLEncoding.EncodeToString(header)
	encodedClaims := base64.RawURLEncoding.EncodeToString(claims)
	input := encodedHeader + "." + encodedClaims
	digest := sha256.Sum256([]byte(input))
	r, s, err := ecdsa.Sign(rand.Reader, key, digest[:])
	if err != nil {
		t.Fatal(err)
	}
	signature := append(paddedCoordinate(r), paddedCoordinate(s)...)
	return input + "." + base64.RawURLEncoding.EncodeToString(signature)
}

func paddedCoordinate(value *big.Int) []byte {
	out := make([]byte, 32)
	bytes := value.Bytes()
	copy(out[len(out)-len(bytes):], bytes)
	return out
}
