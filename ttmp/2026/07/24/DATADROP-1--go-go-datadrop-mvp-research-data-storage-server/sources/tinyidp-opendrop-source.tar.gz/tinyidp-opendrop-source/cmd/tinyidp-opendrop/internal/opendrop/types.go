package opendrop

import (
	"encoding/json"
	"errors"
	"fmt"
	"regexp"
	"strings"
	"time"
)

const (
	maxSpaceNameBytes    = 63
	maxCollectionBytes   = 160
	maxRecordKeyBytes    = 256
	maxRecordValueBytes  = 256 << 10
	maxScriptNameBytes   = 80
	maxScriptSourceBytes = 128 << 10
	maxQueryLimit        = 500
)

var (
	spaceNamePattern  = regexp.MustCompile(`^[a-z][a-z0-9-]{0,62}$`)
	collectionPattern = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._:-]{0,159}$`)
	scriptNamePattern = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$`)
)

var (
	ErrNotFound = errors.New("opendrop: not found")
	ErrConflict = errors.New("opendrop: conflict")
	ErrInvalid  = errors.New("opendrop: invalid input")
	ErrExpired  = errors.New("opendrop: expired")
	ErrReplay   = errors.New("opendrop: replay")
)

type Space struct {
	Name      string    `json:"name"`
	CreatedAt time.Time `json:"createdAt"`
	UpdatedAt time.Time `json:"updatedAt"`
}

type Record struct {
	Space      string          `json:"space"`
	Collection string          `json:"collection"`
	RKey       string          `json:"rkey"`
	Rev        string          `json:"rev"`
	CID        string          `json:"cid"`
	Value      json.RawMessage `json:"value"`
	CreatedAt  time.Time       `json:"createdAt"`
	UpdatedAt  time.Time       `json:"updatedAt"`
	Cursor     int64           `json:"cursor,omitempty"`
}

type Event struct {
	Seq        int64           `json:"seq"`
	Space      string          `json:"space"`
	Kind       string          `json:"kind"`
	Collection string          `json:"collection,omitempty"`
	RKey       string          `json:"rkey,omitempty"`
	Rev        string          `json:"rev,omitempty"`
	CID        string          `json:"cid,omitempty"`
	Body       json.RawMessage `json:"body"`
	CreatedAt  time.Time       `json:"createdAt"`
}

type Script struct {
	Space     string    `json:"space"`
	Name      string    `json:"name"`
	Rev       string    `json:"rev"`
	Source    string    `json:"source,omitempty"`
	Enabled   bool      `json:"enabled"`
	CreatedAt time.Time `json:"createdAt"`
	UpdatedAt time.Time `json:"updatedAt"`
	Cursor    int64     `json:"cursor,omitempty"`
}

type Session struct {
	TokenHash  []byte
	Subject    string
	ClientID   string
	Scopes     []string
	JKT        string
	Origin     string
	CreatedAt  time.Time
	ExpiresAt  time.Time
	LastUsedAt time.Time
}

type WebSocketTicket struct {
	TicketHash  []byte
	SessionHash []byte
	Subject     string
	Space       string
	Origin      string
	Cursor      int64
	ExpiresAt   time.Time
}

func validateSpaceName(value string) (string, error) {
	value = strings.TrimSpace(value)
	if len(value) == 0 || len(value) > maxSpaceNameBytes || !spaceNamePattern.MatchString(value) {
		return "", fmt.Errorf("%w: space must match %s", ErrInvalid, spaceNamePattern.String())
	}
	return value, nil
}

func validateCollection(value string) (string, error) {
	value = strings.TrimSpace(value)
	if len(value) == 0 || len(value) > maxCollectionBytes || !collectionPattern.MatchString(value) {
		return "", fmt.Errorf("%w: collection must match %s", ErrInvalid, collectionPattern.String())
	}
	return value, nil
}

func validateRKey(value string) (string, error) {
	value = strings.TrimSpace(value)
	if value == "" || len(value) > maxRecordKeyBytes || strings.ContainsAny(value, "\x00\r\n/?#") {
		return "", fmt.Errorf("%w: invalid record key", ErrInvalid)
	}
	return value, nil
}

func validateScriptName(value string) (string, error) {
	value = strings.TrimSpace(value)
	if len(value) == 0 || len(value) > maxScriptNameBytes || !scriptNamePattern.MatchString(value) {
		return "", fmt.Errorf("%w: script name must match %s", ErrInvalid, scriptNamePattern.String())
	}
	return value, nil
}

func normalizeLimit(value int) int {
	if value <= 0 {
		return 100
	}
	if value > maxQueryLimit {
		return maxQueryLimit
	}
	return value
}

func normalizeScopes(values []string) []string {
	set := make(map[string]struct{}, len(values))
	for _, value := range values {
		for _, scope := range strings.Fields(value) {
			if scope != "" {
				set[scope] = struct{}{}
			}
		}
	}
	out := make([]string, 0, len(set))
	for scope := range set {
		out = append(out, scope)
	}
	// Deterministic order without importing sort in call sites.
	for i := 1; i < len(out); i++ {
		for j := i; j > 0 && out[j] < out[j-1]; j-- {
			out[j], out[j-1] = out[j-1], out[j]
		}
	}
	return out
}

func hasScope(scopes []string, wanted string) bool {
	for _, scope := range scopes {
		if scope == wanted {
			return true
		}
	}
	return false
}
