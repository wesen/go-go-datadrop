package opendrop

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	_ "github.com/mattn/go-sqlite3"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"
)

type Store struct {
	db  *sql.DB
	now func() time.Time
}

func OpenStore(ctx context.Context, path string) (*Store, error) {
	if ctx == nil {
		return nil, errors.New("opendrop store context is required")
	}
	if strings.TrimSpace(path) == "" {
		return nil, errors.New("opendrop store path is required")
	}
	directory := filepath.Dir(path)
	if err := os.MkdirAll(directory, 0o700); err != nil {
		return nil, fmt.Errorf("create opendrop database directory: %w", err)
	}
	if err := os.Chmod(directory, 0o700); err != nil {
		return nil, fmt.Errorf("protect opendrop database directory: %w", err)
	}
	absolutePath, err := filepath.Abs(path)
	if err != nil {
		return nil, fmt.Errorf("resolve opendrop database path: %w", err)
	}
	dsnURL := &url.URL{Scheme: "file", Path: filepath.ToSlash(absolutePath)}
	query := dsnURL.Query()
	query.Set("_busy_timeout", "5000")
	query.Set("_foreign_keys", "on")
	query.Set("_journal_mode", "WAL")
	query.Set("_synchronous", "FULL")
	dsnURL.RawQuery = query.Encode()
	db, err := sql.Open("sqlite3", dsnURL.String())
	if err != nil {
		return nil, fmt.Errorf("open opendrop database: %w", err)
	}
	db.SetMaxOpenConns(1)
	db.SetMaxIdleConns(1)
	store := &Store{db: db, now: time.Now}
	if err := db.PingContext(ctx); err != nil {
		_ = db.Close()
		return nil, fmt.Errorf("ping opendrop database: %w", err)
	}
	if err := store.migrate(ctx); err != nil {
		_ = db.Close()
		return nil, err
	}
	if err := os.Chmod(path, 0o600); err != nil {
		_ = db.Close()
		return nil, fmt.Errorf("protect opendrop database: %w", err)
	}
	return store, nil
}
func (s *Store) Close() error {
	if s == nil || s.db == nil {
		return nil
	}
	return s.db.Close()
}
func (s *Store) Ping(ctx context.Context) error {
	if s == nil || s.db == nil {
		return errors.New("opendrop store is unavailable")
	}
	if ctx == nil {
		return errors.New("opendrop store context is required")
	}
	if err := s.db.PingContext(ctx); err != nil {
		return fmt.Errorf("ping opendrop database: %w", err)
	}
	return nil
}
func (s *Store) migrate(ctx context.Context) error {
	statements := []string{
		`CREATE TABLE IF NOT EXISTS opendrop_spaces (
			owner_sub TEXT NOT NULL,
			name TEXT NOT NULL,
			created_at INTEGER NOT NULL,
			updated_at INTEGER NOT NULL,
			PRIMARY KEY (owner_sub, name)
		)`,
		`CREATE TABLE IF NOT EXISTS opendrop_records (
			owner_sub TEXT NOT NULL,
			space TEXT NOT NULL,
			collection TEXT NOT NULL,
			rkey TEXT NOT NULL,
			rev TEXT NOT NULL,
			cid TEXT NOT NULL,
			value_json BLOB NOT NULL,
			created_at INTEGER NOT NULL,
			updated_at INTEGER NOT NULL,
			PRIMARY KEY (owner_sub, space, collection, rkey),
			FOREIGN KEY (owner_sub, space) REFERENCES opendrop_spaces(owner_sub, name) ON DELETE CASCADE
		)`,
		`CREATE INDEX IF NOT EXISTS opendrop_records_list_idx
			ON opendrop_records(owner_sub, space, collection, rkey)`,
		`CREATE TABLE IF NOT EXISTS opendrop_events (
			seq INTEGER PRIMARY KEY AUTOINCREMENT,
			owner_sub TEXT NOT NULL,
			space TEXT NOT NULL,
			kind TEXT NOT NULL,
			collection TEXT NOT NULL DEFAULT '',
			rkey TEXT NOT NULL DEFAULT '',
			rev TEXT NOT NULL DEFAULT '',
			cid TEXT NOT NULL DEFAULT '',
			body_json BLOB NOT NULL,
			created_at INTEGER NOT NULL,
			FOREIGN KEY (owner_sub, space) REFERENCES opendrop_spaces(owner_sub, name) ON DELETE CASCADE
		)`,
		`CREATE INDEX IF NOT EXISTS opendrop_events_cursor_idx
			ON opendrop_events(owner_sub, space, seq)`,
		`CREATE TABLE IF NOT EXISTS opendrop_scripts (
			owner_sub TEXT NOT NULL,
			space TEXT NOT NULL,
			name TEXT NOT NULL,
			rev TEXT NOT NULL,
			source TEXT NOT NULL,
			enabled INTEGER NOT NULL,
			created_at INTEGER NOT NULL,
			updated_at INTEGER NOT NULL,
			PRIMARY KEY (owner_sub, space, name),
			FOREIGN KEY (owner_sub, space) REFERENCES opendrop_spaces(owner_sub, name) ON DELETE CASCADE
		)`,
		`CREATE TABLE IF NOT EXISTS opendrop_sessions (
			token_hash BLOB PRIMARY KEY,
			subject TEXT NOT NULL,
			client_id TEXT NOT NULL,
			scopes TEXT NOT NULL,
			jkt TEXT NOT NULL,
			origin TEXT NOT NULL,
			created_at INTEGER NOT NULL,
			expires_at INTEGER NOT NULL,
			last_used_at INTEGER NOT NULL,
			revoked_at INTEGER
		)`,
		`CREATE INDEX IF NOT EXISTS opendrop_sessions_subject_idx
			ON opendrop_sessions(subject, expires_at)`,
		`CREATE TABLE IF NOT EXISTS opendrop_bearer_bindings (
			token_hash BLOB PRIMARY KEY,
			jkt TEXT NOT NULL,
			subject TEXT NOT NULL,
			origin TEXT NOT NULL,
			created_at INTEGER NOT NULL,
			expires_at INTEGER NOT NULL
		)`,
		`CREATE INDEX IF NOT EXISTS opendrop_bearer_bindings_expiry_idx
			ON opendrop_bearer_bindings(expires_at)`,
		`CREATE TABLE IF NOT EXISTS opendrop_dpop_replays (
			jkt TEXT NOT NULL,
			jti TEXT NOT NULL,
			expires_at INTEGER NOT NULL,
			PRIMARY KEY (jkt, jti)
		)`,
		`CREATE INDEX IF NOT EXISTS opendrop_dpop_replays_expiry_idx
			ON opendrop_dpop_replays(expires_at)`,
		`CREATE TABLE IF NOT EXISTS opendrop_websocket_tickets (
			ticket_hash BLOB PRIMARY KEY,
			session_hash BLOB NOT NULL,
			subject TEXT NOT NULL,
			space TEXT NOT NULL,
			origin TEXT NOT NULL,
			cursor INTEGER NOT NULL,
			created_at INTEGER NOT NULL,
			expires_at INTEGER NOT NULL,
			used_at INTEGER,
			FOREIGN KEY (session_hash) REFERENCES opendrop_sessions(token_hash) ON DELETE CASCADE
		)`,
		`CREATE INDEX IF NOT EXISTS opendrop_websocket_tickets_expiry_idx
			ON opendrop_websocket_tickets(expires_at)`,
	}
	for _, statement := range statements {
		if _, err := s.db.ExecContext(ctx, statement); err != nil {
			return fmt.Errorf("migrate opendrop database: %w", err)
		}
	}
	return nil
}
