import { OpenDropClient } from "./opendrop-client.js";

const byID = id => document.getElementById(id);
const elements = {
  baseURL: byID("base-url"), status: byID("status"), space: byID("space"), collection: byID("collection"), rkey: byID("rkey"),
  recordValue: byID("record-value"), spacesOutput: byID("spaces-output"), recordsOutput: byID("records-output"),
  stream: byID("stream"), cursor: byID("cursor"), eventValue: byID("event-value"), streamOutput: byID("stream-output"),
  scriptName: byID("script-name"), scriptExport: byID("script-export"), scriptSource: byID("script-source"),
  scriptOutput: byID("script-output"), sitePreview: byID("site-preview"),
};

let client;
let streamAbort;
let socket;

function currentBaseURL() {
  return new URL(elements.baseURL.value || location.origin).origin;
}

async function resetClient() {
  const baseURL = currentBaseURL();
  localStorage.setItem("opendrop.baseURL", baseURL);
  client = new OpenDropClient({ baseURL });
  const metadata = await client.initialize();
  const session = client.session();
  elements.status.textContent = session
    ? `Logged in as ${session.subject}; DPoP session expires ${new Date(session.expiresAt).toLocaleString()}.`
    : `Ready at ${metadata.audience}. Login uses PKCE, then binds storage access to a browser DPoP key.`;
}

function show(target, value) {
  target.textContent = typeof value === "string" ? value : JSON.stringify(value, null, 2);
}

function showError(target, error) {
  show(target, { error: error.code || "client_error", message: error.message, status: error.status });
}

async function action(target, operation) {
  try {
    if (!client || client.baseURL !== currentBaseURL()) await resetClient();
    const value = await operation();
    if (value !== undefined) show(target, value);
    await resetClient();
    return value;
  } catch (error) {
    showError(target, error);
    throw error;
  }
}

function appendStream(value) {
  const line = typeof value === "string" ? value : JSON.stringify(value);
  const lines = `${elements.streamOutput.textContent}${line}\n`.split("\n");
  elements.streamOutput.textContent = lines.slice(Math.max(0, lines.length - 120)).join("\n");
  if (value?.seq) elements.cursor.value = String(value.seq);
  elements.streamOutput.scrollTop = elements.streamOutput.scrollHeight;
}

function stopStream() {
  streamAbort?.abort();
  streamAbort = undefined;
  socket?.close(1000, "stopped by user");
  socket = undefined;
  appendStream("stream stopped");
}

byID("login").addEventListener("click", async () => {
  try {
    await resetClient();
    await client.login();
  } catch (error) {
    elements.status.textContent = `Login failed: ${error.message}`;
  }
});

byID("logout").addEventListener("click", async () => {
  try {
    await client?.logout();
    stopStream();
    await resetClient();
  } catch (error) {
    elements.status.textContent = `Logout failed: ${error.message}`;
  }
});

byID("create-space").addEventListener("click", () => action(elements.spacesOutput, () =>
  client.request("/xrpc/io.opendrop.space.create", { method: "POST", body: { name: elements.space.value } })
).catch(() => {}));

byID("list-spaces").addEventListener("click", () => action(elements.spacesOutput, () =>
  client.request("/xrpc/io.opendrop.space.list")
).catch(() => {}));

byID("put-record").addEventListener("click", () => action(elements.recordsOutput, () =>
  client.request("/xrpc/io.opendrop.record.put", {
    method: "POST",
    body: {
      space: elements.space.value,
      collection: elements.collection.value,
      rkey: elements.rkey.value,
      value: JSON.parse(elements.recordValue.value),
    },
  })
).catch(() => {}));

byID("list-records").addEventListener("click", () => action(elements.recordsOutput, () =>
  client.request("/xrpc/io.opendrop.record.list", {
    query: { space: elements.space.value, collection: elements.collection.value, limit: 100 },
  })
).catch(() => {}));

byID("append-event").addEventListener("click", () => action(elements.streamOutput, () =>
  client.request("/xrpc/io.opendrop.stream.append", {
    method: "POST",
    body: { space: elements.space.value, stream: elements.stream.value, data: JSON.parse(elements.eventValue.value) },
  })
).catch(() => {}));

byID("start-fetch").addEventListener("click", async () => {
  stopStream();
  streamAbort = new AbortController();
  appendStream("starting fetch stream");
  try {
    if (!client || client.baseURL !== currentBaseURL()) await resetClient();
    await client.subscribe(elements.space.value, {
      cursor: Number(elements.cursor.value || 0),
      signal: streamAbort.signal,
      onEvent: appendStream,
    });
  } catch (error) {
    if (error.name !== "AbortError") appendStream({ error: error.message });
  }
});

byID("start-websocket").addEventListener("click", async () => {
  stopStream();
  appendStream("requesting one-use websocket ticket");
  try {
    if (!client || client.baseURL !== currentBaseURL()) await resetClient();
    socket = await client.websocket(elements.space.value, {
      cursor: Number(elements.cursor.value || 0),
      onOpen: () => appendStream("websocket connected"),
      onEvent: appendStream,
      onClose: event => appendStream(`websocket closed (${event.code})`),
      onError: error => appendStream({ error: error.message || "websocket error" }),
    });
  } catch (error) {
    appendStream({ error: error.message });
  }
});

byID("stop-stream").addEventListener("click", stopStream);

byID("save-script").addEventListener("click", () => action(elements.scriptOutput, () =>
  client.request("/xrpc/io.opendrop.script.put", {
    method: "POST",
    body: {
      space: elements.space.value,
      name: elements.scriptName.value,
      source: elements.scriptSource.value,
      enabled: true,
    },
  })
).catch(() => {}));

byID("run-script").addEventListener("click", async () => {
  try {
    const response = await action(elements.scriptOutput, () => client.request("/xrpc/io.opendrop.script.run", {
      method: "POST",
      body: {
        space: elements.space.value,
        name: elements.scriptName.value,
        export: elements.scriptExport.value,
        input: { requestedBy: "browser-demo" },
        records: { collection: elements.collection.value, limit: 32 },
      },
    }));
    const html = response?.result?.html;
    if (typeof html === "string") {
      const csp = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:; connect-src 'none'; font-src 'none'; media-src 'none'; frame-src 'none'">`;
      elements.sitePreview.srcdoc = `${csp}${html}`;
    } else {
      elements.sitePreview.srcdoc = `<pre>${escapeHTML(JSON.stringify(response?.result, null, 2))}</pre>`;
    }
  } catch {
    elements.sitePreview.removeAttribute("srcdoc");
  }
});

elements.baseURL.addEventListener("change", () => resetClient().catch(error => {
  elements.status.textContent = `Connection failed: ${error.message}`;
}));

function escapeHTML(value) {
  return value.replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
}

elements.baseURL.value = localStorage.getItem("opendrop.baseURL") || location.origin;
await resetClient().catch(error => {
  elements.status.textContent = `Connection failed: ${error.message}`;
});
