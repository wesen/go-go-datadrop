# TinyIDP OpenDrop build report

**Report date:** 2026-07-23  
**Implementation:** `cmd/tinyidp-opendrop`  
**TinyIDP target:** `go-go-golems/tiny-idp` commit `9e1b3190aaa825e734422e14b18e0780de52614b`  
**Status:** development vertical slice; apply-ready source, not a production release

## 1. What was built

This patch adds a self-contained TinyIDP command that acts as a personal data
server for static browser applications. The application server is removed from
the normal request path: a static page authenticates with TinyIDP, binds its
storage credential to a browser-held DPoP key, and talks directly to storage,
script, and realtime APIs.

```text
Static HTML / JavaScript / WASM
          |
          | OAuth authorization code + PKCE
          v
Embedded TinyIDP at /idp
          |
          | bearer introspection + DPoP exchange
          v
OpenDrop storage service
  |-- private subject-scoped spaces
  |-- JSON records with revisions and optimistic writes
  |-- append-only events and resumable cursors
  |-- NDJSON fetch streams
  |-- one-use WebSocket tickets
  |-- saved Goja CommonJS render/transform scripts
  `-- SQLite persistence and synchronous audit log
```

The new command is isolated under `cmd/tinyidp-opendrop`; it does not modify the
existing TinyIDP commands or packages. TinyIDP already declares the required
Goja, go-go-goja, SQLite, and Gorilla WebSocket dependencies, so the patch does
not alter `go.mod` or `go.sum`.

## 2. Delivered source

```text
cmd/tinyidp-opendrop/
|-- README.md
|-- main.go
|-- application.go
|-- state.go
|-- state_test.go
`-- internal/
    |-- resourceauth/
    |   `-- resourceauth.go
    `-- opendrop/
        |-- service*.go
        |-- store*.go
        |-- dpop.go
        |-- hub.go
        |-- stream.go
        |-- scripts.go
        |-- *_test.go
        `-- web/
            |-- index.html
            |-- callback.html
            |-- style.css
            |-- opendrop-client.js
            |-- callback.js
            `-- app.js
```

The subtree contains 34 files and approximately 6,000 lines, including tests,
embedded browser assets, and its operational README.

## 3. Authentication and DPoP flow

### 3.1 OAuth bootstrap

1. The browser discovers `/.well-known/opendrop`.
2. It generates PKCE verifier/challenge material and an OAuth state value.
3. It generates or loads a non-extractable P-256 signing key in IndexedDB.
4. It redirects to embedded TinyIDP for authorization code login.
5. The callback redeems the code with PKCE and receives a short-lived TinyIDP
   bearer access token.
6. The callback immediately sends the bearer token plus an ES256 DPoP proof to
   `io.opendrop.auth.exchange`.

The browser client does not retain an OAuth refresh token. It stores the
short-lived opaque OpenDrop session in `sessionStorage`; the DPoP private key is
a non-extractable `CryptoKey` scoped to the storage origin in IndexedDB.

### 3.2 First-use binding

The exchange validates the bearer token through TinyIDP's introspection
endpoint, verifies the DPoP proof, and atomically pins the bearer-token digest
to:

- the TinyIDP subject;
- the public JWK thumbprint (`jkt`);
- the registered browser origin; and
- the bearer token's expiry.

Every storage request thereafter requires:

```text
Authorization: DPoP <opaque-storage-token>
DPoP: <ES256 proof containing htm, query-free htu, iat, jti, and ath>
```

Replay identifiers are durable in SQLite. Proofs are accepted within a
five-minute clock window, and each `(jkt, jti)` pair can be used once.

This design has a known first-use race: TinyIDP itself currently issues an
ordinary bearer token. An attacker who steals that bearer and completes the
first DPoP exchange before the legitimate browser could bind it to a different
key. Native DPoP issuance or an RFC 8693-style exchange inside TinyIDP is the
production completion.

### 3.3 Origin handling

CORS is an exact allowlist. Initialization registers the storage origin and any
additional static-site origins. No wildcard origin or credential-bearing
reflection is used. WebSocket tickets are bound to the original storage
session, subject, origin, space, cursor, and a 30-second expiry; they are
consumed atomically before upgrade.

## 4. Storage and realtime model

### 4.1 Spaces and records

A space is private to the TinyIDP subject that owns it. Records are addressed by
`(space, collection, rkey)` and include:

- an opaque revision;
- a deterministic SHA-256 content label;
- canonical compact JSON;
- creation and update timestamps; and
- the event cursor produced by mutation.

Optional `swapRev` values provide optimistic concurrency. Put/delete mutations,
the corresponding event, and the space update timestamp commit in one SQLite
transaction.

The field named `cid` is currently `sha256:<base64url>`; it is not a multiformat
CID and is not AT Protocol repository data.

### 4.2 Events and feeds

SQLite is authoritative. The process-local hub only wakes subscribers after a
commit. A disconnected client resumes with a cursor and rereads committed
events, so hub notifications do not need durable delivery.

The canonical browser feed is:

```http
GET /xrpc/io.opendrop.sync.subscribe?space=<name>&cursor=<seq>
Accept: application/x-ndjson
Authorization: DPoP ...
DPoP: ...
```

The server sends event objects, periodic heartbeat objects, and a final close
object when a storage session expires. Each write has a bounded write deadline,
so a client that stops reading cannot pin a handler indefinitely.

The WebSocket path uses a DPoP-authenticated ticket endpoint because the browser
`WebSocket` constructor cannot attach arbitrary authorization headers. The
one-use ticket appears in the WebSocket URL, so a reverse proxy must redact that
query parameter from logs.

## 5. Goja scripting profile

Scripts are saved per space and use synchronous CommonJS exports:

```js
module.exports.render = ({ records, events, input, context }) => ({
  html: `<h1>${opendrop.escapeHTML(context.space)}</h1>`,
  recordCount: (records || []).length,
});
```

The host, not the script, selects input records and events. Each optional
snapshot is capped at 32 items, and all inputs and outputs are JSON normalized.
The runtime profile is:

- fresh Goja runtime per invocation;
- go-go-goja safe module middleware;
- automatic data-only module injection disabled;
- timer module excluded and timer globals overwritten with `undefined`;
- no-op console;
- no OAuth token, DPoP key, SQL handle, filesystem, process, environment, or
  network capability;
- four simultaneous invocations per process;
- 250 ms execution deadline;
- 128 KiB source, 256 KiB input, and 256 KiB output limits; and
- synchronous result requirement (Promises are rejected).

Goja remains an in-process engine. Deadlines and module restrictions constrain
capabilities and runaway CPU, but they do not provide an OS-enforced memory or
side-channel boundary. Adversarial multi-tenant scripts require a separate
worker process, container, or WASI runtime.

The embedded console renders returned HTML inside an iframe with a restrictive
CSP and `sandbox="allow-scripts"`, without `allow-same-origin`.

## 6. API surface

### Discovery and operations

```text
GET  /.well-known/opendrop
GET  /.well-known/openid-configuration/idp
GET  /idp/.well-known/openid-configuration
GET  /healthz
GET  /readyz
GET  /opendrop/
```

### Authentication

```text
POST /xrpc/io.opendrop.auth.exchange
POST /xrpc/io.opendrop.auth.revoke
```

### Spaces, records, streams, and sync

```text
POST /xrpc/io.opendrop.space.create
GET  /xrpc/io.opendrop.space.list
POST /xrpc/io.opendrop.record.put
GET  /xrpc/io.opendrop.record.get
GET  /xrpc/io.opendrop.record.list
POST /xrpc/io.opendrop.record.delete
POST /xrpc/io.opendrop.stream.append
GET  /xrpc/io.opendrop.stream.range
GET  /xrpc/io.opendrop.sync.subscribe
POST /xrpc/io.opendrop.sync.websocketTicket
GET  /xrpc/io.opendrop.sync.websocket?ticket=...
```

### Scripts

```text
POST /xrpc/io.opendrop.script.put
GET  /xrpc/io.opendrop.script.get
GET  /xrpc/io.opendrop.script.list
POST /xrpc/io.opendrop.script.run
```

## 7. State and operations

Initialization creates an owner-only state tree:

```text
state.json
identity/tinyidp.sqlite
storage/opendrop.sqlite
secrets/token.key
secrets/resource-client.key
audit/events.jsonl
```

Directories are mode `0700`; the manifest, databases, audit file, and secret
files are validated as regular files with mode `0600`. Secret and manifest
creation uses file and directory synchronization before success is reported.

The host runs TinyIDP maintenance once at startup and then every 15 minutes.
`/readyz` combines TinyIDP readiness with an OpenDrop SQLite ping; `/healthz`
reports process/provider liveness.

## 8. Validation matrix

| Check | Result | Notes |
|---|---:|---|
| `gofmt -l` over all new Go files | Pass | No format drift |
| `node --check` over all browser modules | Pass | `app.js`, `callback.js`, `opendrop-client.js` |
| API-compatible command type-check | Pass | `go test -run '^$' ./cmd/tinyidp-opendrop/...` against stubs matching the pinned APIs |
| `go vet` | Pass | Same API-compatible type-check tree |
| Pure state/origin/file-mode tests | Pass | Normalization, owner-only directories, key lifecycle, manifest atomicity |
| CORS and public-JWK rejection tests | Pass | Exact-origin behavior and private-JWK rejection |
| Real standard-library DPoP test | Pass | Valid proof, replay rejection, bad `ath`, private JWK rejection |
| Realtime hub test | Pass | Commit notification wakes the matching subscriber |
| Node WebCrypto key test | Pass | P-256 private key non-extractable; public JWK export; 64-byte ES256 signature |
| SQLite migration parse/application | Pass | 14 schema statements; 8 expected tables and indexes |
| Marker/security scan | Pass | No TODO/FIXME/HACK, wildcard CORS, or hard-coded client secret |

### Commands executed in the available environment

```text
go version go1.23.2 linux/amd64
node v22.16.0
```

Representative successful checks:

```text
ok github.com/go-go-golems/tiny-idp/cmd/tinyidp-opendrop
ok github.com/go-go-golems/tiny-idp/cmd/tinyidp-opendrop/internal/opendrop
ok opendrop-coretest
```

### Full-build limitation

A dependency-resolved build against the actual repository was not possible in
the execution environment. The pinned TinyIDP repository declares Go 1.26.4
with toolchain 1.26.5, while the available compiler is Go 1.23.2, and external
dependency download is unavailable. Therefore this report does **not** claim
that `go test ./cmd/tinyidp-opendrop/...` was executed against the real module
graph.

To compensate, the complete command was type-checked and vetted against
API-compatible stubs derived from the pinned TinyIDP and go-go-goja interfaces;
security-critical DPoP and hub behavior was also exercised with the real Go
standard library. The first required step after applying the patch is the real
repository test command shown in `APPLY.md`.

## 9. Known limitations and non-goals

1. **Development TinyIDP mode.** The command does not yet configure production
   rate limiting, trusted proxy/client-address handling, operator UI, automated
   signing-key rotation, or an external audit sink.
2. **First-use bearer race.** DPoP binding occurs after TinyIDP bearer issuance.
3. **Independent storage-session revocation.** Revoking the source TinyIDP token
   after exchange does not immediately revoke an already minted OpenDrop
   session. The session is limited by the source token expiry and can be
   explicitly revoked through OpenDrop.
4. **No storage-session refresh.** The browser repeats login after at most one
   hour.
5. **Single-node SQLite.** There is no clustering, external event broker,
   replication protocol, retention/compaction job, backup command, or object
   storage tier.
6. **Not a full AT Protocol PDS.** There is no DID resolution, signed MST repo,
   CAR export, repo commit chain, Lexicon validation, federation, relay, or
   standard ATproto sync API.
7. **No blob API or schema engine.** v0 stores bounded JSON and JavaScript source.
8. **Trusted-owner scripts only.** Goja has no OS memory isolation.
9. **Audit is durable but not transactionally coupled.** Storage commits are
   followed by synchronous audit emission; a later audit failure cannot roll
   back the already committed mutation.
10. **Single initial account workflow.** Initialization creates one account; an
    operator-grade account-management surface is not included.
11. **No server-side script triggers.** Scripts are explicit render/transform
    calls; scheduled functions, event triggers, and write capabilities are not
    included in this slice.

## 10. Recommended next implementation steps

1. Run the real module build and race tests with the repository toolchain.
2. Move DPoP proof-of-possession into TinyIDP token issuance or add a native
   token-exchange grant, eliminating first-use binding.
3. Add a production host profile: HTTPS assumptions, trusted proxies, durable
   distributed rate limiting, key rotation, external audit, backup/restore, and
   migration tooling.
4. Split Goja execution into a supervised worker process with memory limits and
   capability RPC.
5. Add Lexicon/JSON-Schema validation, blob storage, immutable snapshots, and
   signed portable exports.
6. Add a storage-session refresh design bound to the same DPoP key.
7. Add integration tests using a real browser, TinyIDP authorization flow,
   streaming reconnect, and WebSocket origin/ticket replay cases.
