package opendrop

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestCORSRejectsUnregisteredOrigin(t *testing.T) {
	t.Parallel()
	service := &Service{allowedOrigins: map[string]struct{}{"https://app.example": {}}}
	request := httptest.NewRequest(http.MethodGet, "https://drop.example/.well-known/opendrop", nil)
	request.Header.Set("Origin", "https://evil.example")
	response := httptest.NewRecorder()
	if service.applyCORS(response, request) {
		t.Fatal("disallowed origin was accepted")
	}
	if response.Code != http.StatusForbidden {
		t.Fatalf("status = %d", response.Code)
	}
}

func TestCORSAllowsRegisteredOrigin(t *testing.T) {
	t.Parallel()
	service := &Service{allowedOrigins: map[string]struct{}{"https://app.example": {}}}
	request := httptest.NewRequest(http.MethodOptions, "https://drop.example/xrpc/io.opendrop.space.list", nil)
	request.Header.Set("Origin", "https://app.example")
	response := httptest.NewRecorder()
	if !service.applyCORS(response, request) {
		t.Fatal("registered origin was rejected")
	}
	if got := response.Header().Get("Access-Control-Allow-Origin"); got != "https://app.example" {
		t.Fatalf("allow origin = %q", got)
	}
	if got := response.Header().Get("Access-Control-Allow-Headers"); got == "" {
		t.Fatal("allow headers missing")
	}
}
