package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"
)

const version = "0.1.0-dev"

type repeatedStrings []string

func (r *repeatedStrings) String() string { return strings.Join(*r, ",") }
func (r *repeatedStrings) Set(value string) error {
	*r = append(*r, value)
	return nil
}

func main() {
	if err := run(os.Args[1:]); err != nil {
		slog.Error("tinyidp-opendrop failed", "error", err)
		os.Exit(1)
	}
}

func run(args []string) error {
	if len(args) == 0 {
		printUsage()
		return errors.New("a command is required")
	}
	switch args[0] {
	case "init":
		return runInit(args[1:])
	case "serve":
		return runServe(args[1:])
	case "version", "--version", "-version":
		fmt.Println(version)
		return nil
	case "help", "--help", "-h":
		printUsage()
		return nil
	default:
		printUsage()
		return fmt.Errorf("unknown command %q", args[0])
	}
}

func runInit(args []string) error {
	flags := flag.NewFlagSet("init", flag.ContinueOnError)
	flags.SetOutput(os.Stderr)
	stateDir := flags.String("state-dir", "./opendrop-state", "owner-only state directory")
	publicBaseURL := flags.String("public-base-url", "http://127.0.0.1:8080", "external origin used by browsers and DPoP htu validation")
	login := flags.String("login", "alice", "initial account login")
	email := flags.String("email", "alice@example.test", "initial account email")
	name := flags.String("name", "Alice", "initial account display name")
	passwordFile := flags.String("password-file", "", "file containing the initial password; otherwise OPENDROP_PASSWORD is used")
	var origins repeatedStrings
	flags.Var(&origins, "origin", "allowed static-site origin; may be repeated")
	if err := flags.Parse(args); err != nil {
		return err
	}
	if flags.NArg() != 0 {
		return errors.New("init does not accept positional arguments")
	}
	password, err := readPassword(*passwordFile)
	if err != nil {
		return err
	}
	defer zeroBytes(password)
	if len(password) < 15 {
		return errors.New("initial password must contain at least 15 bytes")
	}
	manifest, err := initializeState(context.Background(), initializeConfig{
		StateRoot:      *stateDir,
		PublicBaseURL:  *publicBaseURL,
		AllowedOrigins: origins,
		Login:          *login,
		Password:       password,
		Email:          *email,
		Name:           *name,
	})
	if err != nil {
		return err
	}
	encoded, err := json.MarshalIndent(map[string]any{
		"stateDir":        *stateDir,
		"publicBaseUrl":   manifest.PublicBaseURL,
		"issuer":          manifest.Issuer,
		"browserClientId": manifest.BrowserClientID,
		"audience":        manifest.Audience,
		"allowedOrigins":  manifest.AllowedOrigins,
	}, "", "  ")
	if err != nil {
		return fmt.Errorf("encode initialization result: %w", err)
	}
	fmt.Println(string(encoded))
	return nil
}

func runServe(args []string) error {
	flags := flag.NewFlagSet("serve", flag.ContinueOnError)
	flags.SetOutput(os.Stderr)
	stateDir := flags.String("state-dir", "./opendrop-state", "initialized state directory")
	address := flags.String("addr", "127.0.0.1:8080", "HTTP listen address")
	if err := flags.Parse(args); err != nil {
		return err
	}
	if flags.NArg() != 0 {
		return errors.New("serve does not accept positional arguments")
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	manifest, _, err := validateState(*stateDir)
	if err != nil {
		return err
	}
	app, err := newApplication(ctx, *stateDir)
	if err != nil {
		return err
	}
	defer func() {
		closeCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		if closeErr := app.Close(closeCtx); closeErr != nil {
			slog.Error("close OpenDrop application", "error", closeErr)
		}
	}()

	server := &http.Server{
		Addr:              *address,
		Handler:           app.Handler(),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       20 * time.Second,
		WriteTimeout:      0, // Streaming feeds and WebSockets are intentionally long-lived.
		IdleTimeout:       2 * time.Minute,
		MaxHeaderBytes:    32 << 10,
	}
	errorsCh := make(chan error, 1)
	go func() {
		slog.Info("TinyIDP OpenDrop listening", "addr", *address, "public_base_url", manifest.PublicBaseURL, "console", manifest.PublicBaseURL+"/opendrop/")
		errorsCh <- server.ListenAndServe()
	}()

	select {
	case err := <-errorsCh:
		if errors.Is(err, http.ErrServerClosed) {
			return nil
		}
		return err
	case <-ctx.Done():
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := server.Shutdown(shutdownCtx); err != nil {
			return fmt.Errorf("shut down HTTP server: %w", err)
		}
		return nil
	}
}

func readPassword(file string) ([]byte, error) {
	if strings.TrimSpace(file) != "" {
		contents, err := os.ReadFile(file)
		if err != nil {
			return nil, fmt.Errorf("read password file: %w", err)
		}
		return trimSingleLineEnding(contents), nil
	}
	value := os.Getenv("OPENDROP_PASSWORD")
	if value == "" {
		return nil, errors.New("set OPENDROP_PASSWORD or pass --password-file")
	}
	return []byte(value), nil
}

func trimSingleLineEnding(value []byte) []byte {
	value = append([]byte(nil), value...)
	if len(value) > 0 && value[len(value)-1] == '\n' {
		value = value[:len(value)-1]
		if len(value) > 0 && value[len(value)-1] == '\r' {
			value = value[:len(value)-1]
		}
	}
	return value
}

func printUsage() {
	fmt.Fprintln(os.Stderr, `tinyidp-opendrop - browser-native storage with TinyIDP and DPoP

Usage:
  tinyidp-opendrop init [flags]
  tinyidp-opendrop serve [flags]
  tinyidp-opendrop version

Initialize once, then serve the same owner-only state directory. The current
release is a development vertical slice; terminate TLS in front of it when the
public base URL is HTTPS.`)
}
