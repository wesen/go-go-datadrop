package opendrop

import (
	"encoding/json"
	"net/http"
)

func (s *Service) handleCreateSpace(w http.ResponseWriter, r *http.Request, principal requestPrincipal) {
	var input struct {
		Name string `json:"name"`
	}
	if !decodeJSONBody(w, r, &input, maxRequestBodyBytes) {
		return
	}
	space, err := s.store.CreateSpace(r.Context(), principal.Session.Subject, input.Name)
	if err != nil {
		s.writeStoreError(w, err)
		return
	}
	s.record(r.Context(), "opendrop.space.created", principal.Session.Subject, principal.Session.ClientID, "accepted", space.Name)
	writeJSON(w, http.StatusOK, map[string]any{"space": space})
}
func (s *Service) handleListSpaces(w http.ResponseWriter, r *http.Request, principal requestPrincipal) {
	spaces, err := s.store.ListSpaces(r.Context(), principal.Session.Subject)
	if err != nil {
		s.writeStoreError(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"spaces": spaces})
}
func (s *Service) handlePutRecord(w http.ResponseWriter, r *http.Request, principal requestPrincipal) {
	var input struct {
		Space      string          `json:"space"`
		Collection string          `json:"collection"`
		RKey       string          `json:"rkey"`
		Value      json.RawMessage `json:"value"`
		SwapRev    string          `json:"swapRev,omitempty"`
	}
	if !decodeJSONBody(w, r, &input, maxRequestBodyBytes) {
		return
	}
	record, event, err := s.store.PutRecord(r.Context(), principal.Session.Subject, input.Space, input.Collection, input.RKey, input.Value, input.SwapRev)
	if err != nil {
		s.writeStoreError(w, err)
		return
	}
	s.hub.Publish(principal.Session.Subject, record.Space)
	s.record(r.Context(), "opendrop.record.put", principal.Session.Subject, principal.Session.ClientID, "accepted", record.Space)
	writeJSON(w, http.StatusOK, map[string]any{"record": record, "cursor": event.Seq})
}
func (s *Service) handleGetRecord(w http.ResponseWriter, r *http.Request, principal requestPrincipal) {
	record, err := s.store.GetRecord(r.Context(), principal.Session.Subject, r.URL.Query().Get("space"), r.URL.Query().Get("collection"), r.URL.Query().Get("rkey"))
	if err != nil {
		s.writeStoreError(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"record": record})
}
func (s *Service) handleListRecords(w http.ResponseWriter, r *http.Request, principal requestPrincipal) {
	limit, err := parseIntQuery(r, "limit", 100)
	if err != nil {
		writeAPIError(w, http.StatusBadRequest, "invalid_request", err.Error())
		return
	}
	records, err := s.store.ListRecords(r.Context(), principal.Session.Subject, r.URL.Query().Get("space"), r.URL.Query().Get("collection"), r.URL.Query().Get("prefix"), limit)
	if err != nil {
		s.writeStoreError(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"records": records})
}
func (s *Service) handleDeleteRecord(w http.ResponseWriter, r *http.Request, principal requestPrincipal) {
	var input struct {
		Space      string `json:"space"`
		Collection string `json:"collection"`
		RKey       string `json:"rkey"`
		SwapRev    string `json:"swapRev,omitempty"`
	}
	if !decodeJSONBody(w, r, &input, maxRequestBodyBytes) {
		return
	}
	event, err := s.store.DeleteRecord(r.Context(), principal.Session.Subject, input.Space, input.Collection, input.RKey, input.SwapRev)
	if err != nil {
		s.writeStoreError(w, err)
		return
	}
	s.hub.Publish(principal.Session.Subject, event.Space)
	s.record(r.Context(), "opendrop.record.deleted", principal.Session.Subject, principal.Session.ClientID, "accepted", event.Space)
	writeJSON(w, http.StatusOK, map[string]any{"cursor": event.Seq})
}
func (s *Service) handleAppendStream(w http.ResponseWriter, r *http.Request, principal requestPrincipal) {
	var input struct {
		Space  string          `json:"space"`
		Stream string          `json:"stream"`
		RKey   string          `json:"rkey,omitempty"`
		Data   json.RawMessage `json:"data"`
	}
	if !decodeJSONBody(w, r, &input, maxRequestBodyBytes) {
		return
	}
	event, err := s.store.AppendStream(r.Context(), principal.Session.Subject, input.Space, input.Stream, input.RKey, input.Data)
	if err != nil {
		s.writeStoreError(w, err)
		return
	}
	s.hub.Publish(principal.Session.Subject, event.Space)
	s.record(r.Context(), "opendrop.stream.appended", principal.Session.Subject, principal.Session.ClientID, "accepted", event.Space)
	writeJSON(w, http.StatusOK, map[string]any{"event": event, "cursor": event.Seq})
}
func (s *Service) handleEventRange(w http.ResponseWriter, r *http.Request, principal requestPrincipal) {
	cursor, err := parseInt64Query(r, "cursor", 0)
	if err != nil {
		writeAPIError(w, http.StatusBadRequest, "invalid_request", err.Error())
		return
	}
	limit, err := parseIntQuery(r, "limit", 100)
	if err != nil {
		writeAPIError(w, http.StatusBadRequest, "invalid_request", err.Error())
		return
	}
	events, err := s.store.EventsAfter(r.Context(), principal.Session.Subject, r.URL.Query().Get("space"), cursor, limit)
	if err != nil {
		s.writeStoreError(w, err)
		return
	}
	next := cursor
	if len(events) > 0 {
		next = events[len(events)-1].Seq
	}
	writeJSON(w, http.StatusOK, map[string]any{"events": events, "cursor": next})
}
