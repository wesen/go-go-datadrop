package main

import (
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"

	"github.com/go-go-golems/tiny-idp/cmd/tinyidp-opendrop/internal/opendrop"
)

func TestNormalizeBaseURLAndOrigin(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name      string
		input     string
		normalize func(string) (string, error)
		want      string
		wantErr   bool
	}{
		{name: "base trims trailing slash", input: " https://drop.example/ ", normalize: normalizeBaseURL, want: "https://drop.example"},
		{name: "origin trims trailing slash", input: "https://app.example/", normalize: normalizeOrigin, want: "https://app.example"},
		{name: "base rejects path", input: "https://drop.example/path", normalize: normalizeBaseURL, wantErr: true},
		{name: "origin rejects query", input: "https://app.example/?debug=1", normalize: normalizeOrigin, wantErr: true},
		{name: "origin rejects userinfo", input: "https://user@app.example", normalize: normalizeOrigin, wantErr: true},
		{name: "base rejects non-http", input: "file:///tmp/drop", normalize: normalizeBaseURL, wantErr: true},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			got, err := test.normalize(test.input)
			if test.wantErr {
				if err == nil {
					t.Fatalf("normalize(%q) = %q, want error", test.input, got)
				}
				return
			}
			if err != nil {
				t.Fatal(err)
			}
			if got != test.want {
				t.Fatalf("normalize(%q) = %q, want %q", test.input, got, test.want)
			}
		})
	}
}

func TestNormalizeOriginsDeduplicatesAndSorts(t *testing.T) {
	t.Parallel()
	got, err := normalizeOrigins("https://drop.example", []string{
		"https://z.example/",
		"https://a.example",
		"https://z.example",
	})
	if err != nil {
		t.Fatal(err)
	}
	want := []string{"https://a.example", "https://drop.example", "https://z.example"}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("origins = %#v, want %#v", got, want)
	}
}

func TestOwnerOnlyDirectoryAndKeyLifecycle(t *testing.T) {
	t.Parallel()
	root := t.TempDir()
	if err := os.Chmod(root, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := requireOwnerOnlyDirectory(root); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(root, 0o750); err != nil {
		t.Fatal(err)
	}
	if err := requireOwnerOnlyDirectory(root); err == nil {
		t.Fatal("group-readable state directory was accepted")
	}
	if err := os.Chmod(root, 0o700); err != nil {
		t.Fatal(err)
	}

	secretPath := filepath.Join(root, "secrets", "token.key")
	first, err := loadOrCreateKey(secretPath, 32)
	if err != nil {
		t.Fatal(err)
	}
	if len(first) != 32 {
		t.Fatalf("key length = %d", len(first))
	}
	info, err := os.Stat(secretPath)
	if err != nil {
		t.Fatal(err)
	}
	if got := info.Mode().Perm(); got != 0o600 {
		t.Fatalf("key mode = %#o, want 0600", got)
	}
	second, err := loadOrCreateKey(secretPath, 32)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(first, second) {
		t.Fatal("existing key was not reused")
	}
	if err := os.Chmod(secretPath, 0o640); err != nil {
		t.Fatal(err)
	}
	if _, err := loadOrCreateKey(secretPath, 32); err == nil {
		t.Fatal("key with unsafe mode was accepted")
	}
}

func TestManifestRoundTripAndLineEnding(t *testing.T) {
	t.Parallel()
	root := t.TempDir()
	file := filepath.Join(root, "state.json")
	manifest := stateManifest{
		Version:          stateManifestVersion,
		PublicBaseURL:    "https://drop.example",
		Issuer:           "https://drop.example/idp",
		BrowserClientID:  opendrop.BrowserClientID,
		ResourceClientID: resourceClientID,
		Audience:         "https://drop.example/api",
		AllowedOrigins:   []string{"https://app.example", "https://drop.example"},
		CreatedAt:        time.Date(2026, 7, 23, 12, 0, 0, 0, time.UTC),
	}
	if err := writeManifestAtomic(file, manifest); err != nil {
		t.Fatal(err)
	}
	loaded, err := readStateManifest(file)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(loaded, manifest) {
		t.Fatalf("manifest = %#v, want %#v", loaded, manifest)
	}
	contents, err := os.ReadFile(file)
	if err != nil {
		t.Fatal(err)
	}
	if !strings.HasSuffix(string(contents), "\n") {
		t.Fatal("manifest does not end with newline")
	}
	info, err := os.Stat(file)
	if err != nil {
		t.Fatal(err)
	}
	if got := info.Mode().Perm(); got != 0o600 {
		t.Fatalf("manifest mode = %#o, want 0600", got)
	}

	if got := string(trimSingleLineEnding([]byte("secret\r\n"))); got != "secret" {
		t.Fatalf("trimmed CRLF = %q", got)
	}
	if got := string(trimSingleLineEnding([]byte("secret\n\n"))); got != "secret\n" {
		t.Fatalf("trimmed two line endings = %q", got)
	}
}
