package opendrop

import (
	"context"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestStoreRecordEventScriptAndSessionLifecycle(t *testing.T) {
	t.Parallel()
	ctx := context.Background()
	store, err := OpenStore(ctx, filepath.Join(t.TempDir(), "opendrop.sqlite"))
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close()

	const owner = "did:example:alice"
	space, err := store.CreateSpace(ctx, owner, "greenhouse")
	if err != nil {
		t.Fatal(err)
	}
	if space.Name != "greenhouse" {
		t.Fatalf("space name = %q", space.Name)
	}

	first, firstEvent, err := store.PutRecord(ctx, owner, space.Name, "dev.opendrop.reading", "sensor-1", json.RawMessage(`{"temperature":21.7}`), "")
	if err != nil {
		t.Fatal(err)
	}
	if first.Cursor != firstEvent.Seq || first.Cursor == 0 || first.Rev == "" || first.CID == "" {
		t.Fatalf("incomplete first record: %#v / %#v", first, firstEvent)
	}
	if _, _, err := store.PutRecord(ctx, owner, space.Name, first.Collection, first.RKey, json.RawMessage(`{"temperature":22}`), "r_stale"); !errors.Is(err, ErrConflict) {
		t.Fatalf("stale swap error = %v, want conflict", err)
	}
	updated, updateEvent, err := store.PutRecord(ctx, owner, space.Name, first.Collection, first.RKey, json.RawMessage(`{"temperature":22}`), first.Rev)
	if err != nil {
		t.Fatal(err)
	}
	if updated.Rev == first.Rev || updateEvent.Seq <= firstEvent.Seq {
		t.Fatalf("record revision/cursor did not advance")
	}
	loaded, err := store.GetRecord(ctx, owner, space.Name, first.Collection, first.RKey)
	if err != nil {
		t.Fatal(err)
	}
	if loaded.Rev != updated.Rev || string(loaded.Value) != `{"temperature":22}` {
		t.Fatalf("loaded record = %#v", loaded)
	}
	records, err := store.ListRecords(ctx, owner, space.Name, first.Collection, "sensor", 10)
	if err != nil {
		t.Fatal(err)
	}
	if len(records) != 1 || records[0].RKey != "sensor-1" {
		t.Fatalf("records = %#v", records)
	}

	streamEvent, err := store.AppendStream(ctx, owner, space.Name, "readings", "", json.RawMessage(`{"temperature":22.1}`))
	if err != nil {
		t.Fatal(err)
	}
	if streamEvent.Kind != "stream.append" || streamEvent.Seq <= updateEvent.Seq {
		t.Fatalf("stream event = %#v", streamEvent)
	}
	events, err := store.EventsAfter(ctx, owner, space.Name, firstEvent.Seq, 100)
	if err != nil {
		t.Fatal(err)
	}
	if len(events) != 2 || events[0].Seq != updateEvent.Seq || events[1].Seq != streamEvent.Seq {
		t.Fatalf("events = %#v", events)
	}

	source := `module.exports.render = input => ({count: (input.records || []).length});`
	script, scriptEvent, err := store.PutScript(ctx, owner, space.Name, "summary", source, true, "")
	if err != nil {
		t.Fatal(err)
	}
	if script.Cursor != scriptEvent.Seq || !script.Enabled {
		t.Fatalf("script = %#v", script)
	}
	scripts, err := store.ListScripts(ctx, owner, space.Name)
	if err != nil {
		t.Fatal(err)
	}
	if len(scripts) != 1 || scripts[0].Name != "summary" || scripts[0].Source != "" {
		t.Fatalf("script summaries = %#v", scripts)
	}

	now := time.Now().UTC().Truncate(time.Millisecond)
	sessionHash := tokenDigest("storage-session")
	session := Session{
		TokenHash: sessionHash, Subject: owner, ClientID: BrowserClientID,
		Scopes: []string{ScopeWrite, ScopeRead, ScopeRead}, JKT: "test-jkt", Origin: "https://app.example",
		CreatedAt: now, LastUsedAt: now, ExpiresAt: now.Add(time.Hour),
	}
	boundToken := tokenDigest("tinyidp-bearer")
	if err := store.BindBearerToken(ctx, boundToken, session.JKT, owner, session.Origin, now.Add(time.Hour)); err != nil {
		t.Fatal(err)
	}
	if err := store.BindBearerToken(ctx, boundToken, session.JKT, owner, session.Origin, now.Add(time.Hour)); err != nil {
		t.Fatalf("idempotent bearer binding failed: %v", err)
	}
	if err := store.BindBearerToken(ctx, boundToken, "other-jkt", owner, session.Origin, now.Add(time.Hour)); !errors.Is(err, ErrConflict) {
		t.Fatalf("bearer rebinding error = %v, want conflict", err)
	}

	if err := store.CreateSession(ctx, session); err != nil {
		t.Fatal(err)
	}
	loadedSession, err := store.GetSession(ctx, sessionHash)
	if err != nil {
		t.Fatal(err)
	}
	if len(loadedSession.Scopes) != 2 || loadedSession.Scopes[0] != ScopeRead || loadedSession.Scopes[1] != ScopeWrite {
		t.Fatalf("normalized scopes = %#v", loadedSession.Scopes)
	}

	if err := store.RememberDPoPProof(ctx, "test-jkt", "proof-1", now.Add(time.Minute)); err != nil {
		t.Fatal(err)
	}
	if err := store.RememberDPoPProof(ctx, "test-jkt", "proof-1", now.Add(time.Minute)); !errors.Is(err, ErrReplay) {
		t.Fatalf("DPoP replay error = %v", err)
	}

	ticketToken := "one-use-ticket"
	if err := store.CreateWebSocketTicket(ctx, WebSocketTicket{
		TicketHash: tokenDigest(ticketToken), SessionHash: sessionHash, Subject: owner,
		Space: space.Name, Origin: session.Origin, Cursor: streamEvent.Seq, ExpiresAt: now.Add(time.Minute),
	}); err != nil {
		t.Fatal(err)
	}
	ticket, err := store.ConsumeWebSocketTicket(ctx, tokenDigest(ticketToken), session.Origin)
	if err != nil {
		t.Fatal(err)
	}
	if ticket.Cursor != streamEvent.Seq || ticket.Subject != owner {
		t.Fatalf("ticket = %#v", ticket)
	}
	if _, err := store.ConsumeWebSocketTicket(ctx, tokenDigest(ticketToken), session.Origin); !errors.Is(err, ErrNotFound) && !errors.Is(err, ErrReplay) {
		t.Fatalf("second ticket consumption error = %v", err)
	}

	if err := store.RevokeSession(ctx, sessionHash); err != nil {
		t.Fatal(err)
	}
	if _, err := store.GetSession(ctx, sessionHash); !errors.Is(err, ErrNotFound) {
		t.Fatalf("revoked session error = %v", err)
	}
}

func TestStoreRejectsMissingSpace(t *testing.T) {
	t.Parallel()
	ctx := context.Background()
	store, err := OpenStore(ctx, filepath.Join(t.TempDir(), "opendrop.sqlite"))
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close()

	if _, err := store.ListRecords(ctx, "alice", "missing", "example.record", "", 10); !errors.Is(err, ErrNotFound) {
		t.Fatalf("ListRecords error = %v", err)
	}
	if _, err := store.EventsAfter(ctx, "alice", "missing", 0, 10); !errors.Is(err, ErrNotFound) {
		t.Fatalf("EventsAfter error = %v", err)
	}
	if _, err := store.ListScripts(ctx, "alice", "missing"); !errors.Is(err, ErrNotFound) {
		t.Fatalf("ListScripts error = %v", err)
	}
}

func TestStoreRejectsInvalidAndExpiredWebSocketTickets(t *testing.T) {
	t.Parallel()
	ctx := context.Background()
	store, err := OpenStore(ctx, filepath.Join(t.TempDir(), "opendrop.sqlite"))
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close()

	now := time.Date(2026, 7, 23, 12, 0, 0, 0, time.UTC)
	store.now = func() time.Time { return now }
	const owner = "did:example:alice"
	space, err := store.CreateSpace(ctx, owner, "greenhouse")
	if err != nil {
		t.Fatal(err)
	}
	sessionHash := tokenDigest("session")
	if err := store.CreateSession(ctx, Session{
		TokenHash: sessionHash, Subject: owner, ClientID: BrowserClientID,
		Scopes: []string{ScopeRead}, JKT: "jkt", Origin: "https://app.example",
		CreatedAt: now, LastUsedAt: now, ExpiresAt: now.Add(time.Hour),
	}); err != nil {
		t.Fatal(err)
	}

	base := WebSocketTicket{
		TicketHash: tokenDigest("ticket"), SessionHash: sessionHash, Subject: owner,
		Space: space.Name, Origin: "https://app.example", Cursor: 0, ExpiresAt: now.Add(time.Minute),
	}
	negative := base
	negative.TicketHash = tokenDigest("negative")
	negative.Cursor = -1
	if err := store.CreateWebSocketTicket(ctx, negative); !errors.Is(err, ErrInvalid) {
		t.Fatalf("negative cursor error = %v", err)
	}
	expired := base
	expired.TicketHash = tokenDigest("already-expired")
	expired.ExpiresAt = now
	if err := store.CreateWebSocketTicket(ctx, expired); !errors.Is(err, ErrExpired) {
		t.Fatalf("expired ticket creation error = %v", err)
	}
	if err := store.CreateWebSocketTicket(ctx, base); err != nil {
		t.Fatal(err)
	}
	store.now = func() time.Time { return now.Add(2 * time.Minute) }
	if _, err := store.ConsumeWebSocketTicket(ctx, base.TicketHash, base.Origin); !errors.Is(err, ErrExpired) {
		t.Fatalf("expired ticket consumption error = %v", err)
	}
}

func TestOpenStoreHardensDirectoryAndDatabaseModes(t *testing.T) {
	t.Parallel()
	ctx := context.Background()
	root := filepath.Join(t.TempDir(), "private")
	if err := os.MkdirAll(root, 0o755); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(root, "opendrop.sqlite")
	store, err := OpenStore(ctx, path)
	if err != nil {
		t.Fatal(err)
	}
	if err := store.Close(); err != nil {
		t.Fatal(err)
	}
	dirInfo, err := os.Stat(root)
	if err != nil {
		t.Fatal(err)
	}
	if got := dirInfo.Mode().Perm(); got != 0o700 {
		t.Fatalf("database directory mode = %#o, want 0700", got)
	}
	fileInfo, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	if got := fileInfo.Mode().Perm(); got != 0o600 {
		t.Fatalf("database mode = %#o, want 0600", got)
	}
}
