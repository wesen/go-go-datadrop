package opendrop

import (
	"encoding/json"
	"errors"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/gorilla/websocket"
)

const (
	streamBatchSize  = 200
	streamHeartbeat  = 20 * time.Second
	streamWriteLimit = 10 * time.Second
)

func (s *Service) handleSubscribe(w http.ResponseWriter, r *http.Request, principal requestPrincipal) {
	space, err := validateSpaceName(r.URL.Query().Get("space"))
	if err != nil {
		s.writeStoreError(w, err)
		return
	}
	if _, err := s.store.getSpace(r.Context(), principal.Session.Subject, space); err != nil {
		s.writeStoreError(w, err)
		return
	}
	cursor, err := streamCursor(r)
	if err != nil {
		writeAPIError(w, http.StatusBadRequest, "invalid_request", err.Error())
		return
	}
	flusher, ok := w.(http.Flusher)
	if !ok {
		writeAPIError(w, http.StatusInternalServerError, "streaming_unavailable", "HTTP streaming is unavailable")
		return
	}
	responseController := http.NewResponseController(w)
	setWriteDeadline := func() error {
		err := responseController.SetWriteDeadline(time.Now().Add(streamWriteLimit))
		if errors.Is(err, http.ErrNotSupported) {
			return nil
		}
		return err
	}
	w.Header().Set("Content-Type", "application/x-ndjson")
	w.Header().Set("Cache-Control", "no-store, no-transform")
	w.Header().Set("X-Accel-Buffering", "no")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("X-OpenDrop-Cursor", strconv.FormatInt(cursor, 10))
	if err := setWriteDeadline(); err != nil {
		writeAPIError(w, http.StatusInternalServerError, "streaming_unavailable", "HTTP write deadlines are unavailable")
		return
	}
	w.WriteHeader(http.StatusOK)
	flusher.Flush()

	notify, cancel := s.hub.Subscribe(principal.Session.Subject, space)
	defer cancel()
	encoder := json.NewEncoder(w)
	heartbeat := time.NewTicker(streamHeartbeat)
	defer heartbeat.Stop()
	for {
		if _, err := s.store.GetSession(r.Context(), principal.Session.TokenHash); err != nil {
			if setWriteDeadline() == nil {
				_ = encoder.Encode(map[string]any{"type": "close", "cursor": cursor, "reason": "session_expired"})
				flusher.Flush()
			}
			return
		}
		events, err := s.store.EventsAfter(r.Context(), principal.Session.Subject, space, cursor, streamBatchSize)
		if err != nil {
			return
		}
		for _, event := range events {
			if err := setWriteDeadline(); err != nil {
				return
			}
			if err := encoder.Encode(event); err != nil {
				return
			}
			cursor = event.Seq
			flusher.Flush()
		}
		if len(events) == streamBatchSize {
			continue
		}
		select {
		case <-r.Context().Done():
			return
		case <-notify:
			continue
		case now := <-heartbeat.C:
			if _, err := s.store.GetSession(r.Context(), principal.Session.TokenHash); err != nil {
				if setWriteDeadline() == nil {
					_ = encoder.Encode(map[string]any{"type": "close", "cursor": cursor, "reason": "session_expired"})
					flusher.Flush()
				}
				return
			}
			if err := setWriteDeadline(); err != nil {
				return
			}
			if err := encoder.Encode(map[string]any{"type": "heartbeat", "cursor": cursor, "time": now.UTC().Format(time.RFC3339Nano)}); err != nil {
				return
			}
			flusher.Flush()
		}
	}
}

func (s *Service) handleWebSocketTicket(w http.ResponseWriter, r *http.Request, principal requestPrincipal) {
	var input struct {
		Space  string `json:"space"`
		Cursor int64  `json:"cursor,omitempty"`
	}
	if !decodeJSONBody(w, r, &input, maxRequestBodyBytes) {
		return
	}
	space, err := validateSpaceName(input.Space)
	if err != nil || input.Cursor < 0 {
		writeAPIError(w, http.StatusBadRequest, "invalid_request", "space and a non-negative cursor are required")
		return
	}
	if _, err := s.store.getSpace(r.Context(), principal.Session.Subject, space); err != nil {
		s.writeStoreError(w, err)
		return
	}
	ticketToken, err := randomToken()
	if err != nil {
		writeAPIError(w, http.StatusInternalServerError, "server_error", "could not create websocket ticket")
		return
	}
	origin := principal.Session.Origin
	expiresAt := time.Now().UTC().Add(webSocketTicketTTL)
	ticket := WebSocketTicket{
		TicketHash:  tokenDigest(ticketToken),
		SessionHash: principal.Session.TokenHash,
		Subject:     principal.Session.Subject,
		Space:       space,
		Origin:      origin,
		Cursor:      input.Cursor,
		ExpiresAt:   expiresAt,
	}
	if err := s.store.CreateWebSocketTicket(r.Context(), ticket); err != nil {
		s.writeStoreError(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"ticket":        ticketToken,
		"expiresIn":     int(webSocketTicketTTL.Seconds()),
		"websocketUrl":  s.websocketURL(ticketToken),
		"subprotocol":   "opendrop.v1",
		"initialCursor": input.Cursor,
	})
}

func (s *Service) handleWebSocket(w http.ResponseWriter, r *http.Request) {
	if !containsString(websocket.Subprotocols(r), "opendrop.v1") {
		writeAPIError(w, http.StatusBadRequest, "unsupported_subprotocol", "websocket subprotocol opendrop.v1 is required")
		return
	}
	ticketToken := strings.TrimSpace(r.URL.Query().Get("ticket"))
	if ticketToken == "" || len(ticketToken) > 256 {
		writeAPIError(w, http.StatusUnauthorized, "invalid_ticket", "a websocket ticket is required")
		return
	}
	origin, err := requestOrigin(r)
	if err != nil {
		writeAPIError(w, http.StatusUnauthorized, "invalid_ticket", "websocket origin is invalid")
		return
	}
	ticket, err := s.store.ConsumeWebSocketTicket(r.Context(), tokenDigest(ticketToken), origin)
	if err != nil {
		writeAPIError(w, http.StatusUnauthorized, "invalid_ticket", "websocket ticket is invalid, expired, or already used")
		return
	}
	upgrader := websocket.Upgrader{
		HandshakeTimeout: 10 * time.Second,
		ReadBufferSize:   4096,
		WriteBufferSize:  4096,
		Subprotocols:     []string{"opendrop.v1"},
		CheckOrigin: func(_ *http.Request) bool {
			// Origin was already compared with the one-use ticket before upgrade.
			return true
		},
	}
	connection, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		return
	}
	defer connection.Close()
	connection.SetReadLimit(1024)
	_ = connection.SetReadDeadline(time.Now().Add(2 * streamHeartbeat))
	connection.SetPongHandler(func(string) error {
		return connection.SetReadDeadline(time.Now().Add(2 * streamHeartbeat))
	})

	closed := make(chan struct{})
	go func() {
		defer close(closed)
		for {
			if _, _, err := connection.ReadMessage(); err != nil {
				return
			}
		}
	}()

	notify, cancel := s.hub.Subscribe(ticket.Subject, ticket.Space)
	defer cancel()
	cursor := ticket.Cursor
	ping := time.NewTicker(streamHeartbeat)
	defer ping.Stop()
	for {
		if _, err := s.store.GetSession(r.Context(), ticket.SessionHash); err != nil {
			_ = connection.WriteControl(websocket.CloseMessage, websocket.FormatCloseMessage(websocket.ClosePolicyViolation, "session expired"), time.Now().Add(streamWriteLimit))
			return
		}
		events, err := s.store.EventsAfter(r.Context(), ticket.Subject, ticket.Space, cursor, streamBatchSize)
		if err != nil {
			return
		}
		for _, event := range events {
			if err := connection.SetWriteDeadline(time.Now().Add(streamWriteLimit)); err != nil {
				return
			}
			if err := connection.WriteJSON(event); err != nil {
				return
			}
			cursor = event.Seq
		}
		if len(events) == streamBatchSize {
			continue
		}
		select {
		case <-r.Context().Done():
			return
		case <-closed:
			return
		case <-notify:
			continue
		case <-ping.C:
			if _, err := s.store.GetSession(r.Context(), ticket.SessionHash); err != nil {
				_ = connection.WriteControl(websocket.CloseMessage, websocket.FormatCloseMessage(websocket.ClosePolicyViolation, "session expired"), time.Now().Add(streamWriteLimit))
				return
			}
			if err := connection.SetWriteDeadline(time.Now().Add(streamWriteLimit)); err != nil {
				return
			}
			if err := connection.WriteControl(websocket.PingMessage, []byte(strconv.FormatInt(cursor, 10)), time.Now().Add(streamWriteLimit)); err != nil {
				return
			}
		}
	}
}

func streamCursor(r *http.Request) (int64, error) {
	if raw := strings.TrimSpace(r.URL.Query().Get("cursor")); raw != "" {
		cursor, err := strconv.ParseInt(raw, 10, 64)
		if err != nil || cursor < 0 {
			return 0, errors.New("cursor must be a non-negative integer")
		}
		return cursor, nil
	}
	if raw := strings.TrimSpace(r.Header.Get("Last-Event-ID")); raw != "" {
		cursor, err := strconv.ParseInt(raw, 10, 64)
		if err != nil || cursor < 0 {
			return 0, errors.New("Last-Event-ID must be a non-negative integer")
		}
		return cursor, nil
	}
	return 0, nil
}

func (s *Service) websocketURL(ticket string) string {
	parsed, err := url.Parse(s.publicBaseURL)
	if err != nil {
		return ""
	}
	switch parsed.Scheme {
	case "https":
		parsed.Scheme = "wss"
	default:
		parsed.Scheme = "ws"
	}
	parsed.Path = "/xrpc/io.opendrop.sync.websocket"
	parsed.RawQuery = "ticket=" + url.QueryEscape(ticket)
	return parsed.String()
}

func containsString(values []string, wanted string) bool {
	for _, value := range values {
		if value == wanted {
			return true
		}
	}
	return false
}
