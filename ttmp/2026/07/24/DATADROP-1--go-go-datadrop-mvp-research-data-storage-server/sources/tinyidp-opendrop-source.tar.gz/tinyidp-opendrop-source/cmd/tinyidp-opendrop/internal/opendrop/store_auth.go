package opendrop

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"
)

func (s *Store) BindBearerToken(ctx context.Context, tokenHash []byte, jkt, subject, origin string, expiresAt time.Time) error {
	if len(tokenHash) == 0 || strings.TrimSpace(jkt) == "" || strings.TrimSpace(subject) == "" || expiresAt.IsZero() {
		return fmt.Errorf("%w: incomplete bearer binding", ErrInvalid)
	}
	now := s.now().UTC()
	if !expiresAt.After(now) {
		return ErrExpired
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("begin bearer binding: %w", err)
	}
	defer func() { _ = tx.Rollback() }()
	if _, err := tx.ExecContext(ctx, `DELETE FROM opendrop_bearer_bindings WHERE expires_at <= ?`, now.UnixMilli()); err != nil {
		return fmt.Errorf("clean bearer bindings: %w", err)
	}
	if _, err := tx.ExecContext(ctx, `INSERT OR IGNORE INTO opendrop_bearer_bindings(
		token_hash, jkt, subject, origin, created_at, expires_at
	) VALUES(?, ?, ?, ?, ?, ?)`, tokenHash, jkt, subject, origin, now.UnixMilli(), expiresAt.UTC().UnixMilli()); err != nil {
		return fmt.Errorf("create bearer binding: %w", err)
	}
	var storedJKT, storedSubject, storedOrigin string
	var storedExpiry int64
	if err := tx.QueryRowContext(ctx, `SELECT jkt, subject, origin, expires_at FROM opendrop_bearer_bindings WHERE token_hash = ?`, tokenHash).
		Scan(&storedJKT, &storedSubject, &storedOrigin, &storedExpiry); err != nil {
		return fmt.Errorf("read bearer binding: %w", err)
	}
	if storedJKT != jkt || storedSubject != subject || storedOrigin != origin || storedExpiry != expiresAt.UTC().UnixMilli() {
		return fmt.Errorf("%w: bearer token is already bound to another browser key or origin", ErrConflict)
	}
	if err := tx.Commit(); err != nil {
		return fmt.Errorf("commit bearer binding: %w", err)
	}
	return nil
}
func (s *Store) CreateSession(ctx context.Context, session Session) error {
	if len(session.TokenHash) == 0 || session.Subject == "" || session.ClientID == "" || session.JKT == "" || session.CreatedAt.IsZero() || !session.ExpiresAt.After(session.CreatedAt) {
		return fmt.Errorf("%w: incomplete session", ErrInvalid)
	}
	session.Scopes = normalizeScopes(session.Scopes)
	if session.LastUsedAt.IsZero() {
		session.LastUsedAt = session.CreatedAt
	}
	_, err := s.db.ExecContext(ctx, `INSERT INTO opendrop_sessions(
		token_hash, subject, client_id, scopes, jkt, origin, created_at, expires_at, last_used_at
	) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)`, session.TokenHash, session.Subject, session.ClientID,
		strings.Join(session.Scopes, " "), session.JKT, session.Origin, session.CreatedAt.UnixMilli(), session.ExpiresAt.UnixMilli(), session.LastUsedAt.UnixMilli())
	if err != nil {
		return fmt.Errorf("create opendrop session: %w", err)
	}
	return nil
}
func (s *Store) GetSession(ctx context.Context, tokenHash []byte) (Session, error) {
	var session Session
	var scopes string
	var created, expires, lastUsed int64
	err := s.db.QueryRowContext(ctx, `SELECT subject, client_id, scopes, jkt, origin, created_at, expires_at, last_used_at
		FROM opendrop_sessions WHERE token_hash = ? AND revoked_at IS NULL`, tokenHash).
		Scan(&session.Subject, &session.ClientID, &scopes, &session.JKT, &session.Origin, &created, &expires, &lastUsed)
	if errors.Is(err, sql.ErrNoRows) {
		return Session{}, ErrNotFound
	}
	if err != nil {
		return Session{}, fmt.Errorf("get opendrop session: %w", err)
	}
	now := s.now().UTC()
	session.TokenHash = append([]byte(nil), tokenHash...)
	session.Scopes = strings.Fields(scopes)
	session.CreatedAt, session.ExpiresAt, session.LastUsedAt = millisTime(created), millisTime(expires), millisTime(lastUsed)
	if !now.Before(session.ExpiresAt) {
		return Session{}, ErrExpired
	}
	_, _ = s.db.ExecContext(ctx, `UPDATE opendrop_sessions SET last_used_at = ? WHERE token_hash = ?`, now.UnixMilli(), tokenHash)
	return session, nil
}
func (s *Store) RevokeSession(ctx context.Context, tokenHash []byte) error {
	result, err := s.db.ExecContext(ctx, `UPDATE opendrop_sessions SET revoked_at = ? WHERE token_hash = ? AND revoked_at IS NULL`, s.now().UTC().UnixMilli(), tokenHash)
	if err != nil {
		return fmt.Errorf("revoke opendrop session: %w", err)
	}
	rows, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("read revoke result: %w", err)
	}
	if rows == 0 {
		return ErrNotFound
	}
	return nil
}
func (s *Store) RememberDPoPProof(ctx context.Context, jkt, jti string, expiresAt time.Time) error {
	if jkt == "" || jti == "" || expiresAt.IsZero() {
		return fmt.Errorf("%w: incomplete DPoP replay key", ErrInvalid)
	}
	now := s.now().UTC().UnixMilli()
	_, _ = s.db.ExecContext(ctx, `DELETE FROM opendrop_dpop_replays WHERE expires_at <= ?`, now)
	result, err := s.db.ExecContext(ctx, `INSERT OR IGNORE INTO opendrop_dpop_replays(jkt, jti, expires_at) VALUES(?, ?, ?)`, jkt, jti, expiresAt.UTC().UnixMilli())
	if err != nil {
		return fmt.Errorf("remember DPoP proof: %w", err)
	}
	rows, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("read DPoP replay result: %w", err)
	}
	if rows != 1 {
		return ErrReplay
	}
	return nil
}
func (s *Store) CreateWebSocketTicket(ctx context.Context, ticket WebSocketTicket) error {
	if len(ticket.TicketHash) == 0 || len(ticket.SessionHash) == 0 || ticket.Subject == "" || ticket.Space == "" || ticket.ExpiresAt.IsZero() || ticket.Cursor < 0 {
		return fmt.Errorf("%w: incomplete websocket ticket", ErrInvalid)
	}
	now := s.now().UTC()
	if !ticket.ExpiresAt.After(now) {
		return ErrExpired
	}
	_, _ = s.db.ExecContext(ctx, `DELETE FROM opendrop_websocket_tickets WHERE expires_at <= ? OR used_at IS NOT NULL`, now.UnixMilli())
	_, err := s.db.ExecContext(ctx, `INSERT INTO opendrop_websocket_tickets(
		ticket_hash, session_hash, subject, space, origin, cursor, created_at, expires_at
	) VALUES(?, ?, ?, ?, ?, ?, ?, ?)`, ticket.TicketHash, ticket.SessionHash, ticket.Subject, ticket.Space,
		ticket.Origin, ticket.Cursor, now.UnixMilli(), ticket.ExpiresAt.UTC().UnixMilli())
	if err != nil {
		return fmt.Errorf("create websocket ticket: %w", err)
	}
	return nil
}
func (s *Store) ConsumeWebSocketTicket(ctx context.Context, ticketHash []byte, origin string) (WebSocketTicket, error) {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return WebSocketTicket{}, fmt.Errorf("begin consume websocket ticket: %w", err)
	}
	defer func() { _ = tx.Rollback() }()
	var ticket WebSocketTicket
	var expires int64
	err = tx.QueryRowContext(ctx, `SELECT t.session_hash, t.subject, t.space, t.origin, t.cursor, t.expires_at
		FROM opendrop_websocket_tickets t JOIN opendrop_sessions s ON s.token_hash = t.session_hash
		WHERE t.ticket_hash = ? AND t.used_at IS NULL AND s.revoked_at IS NULL AND s.expires_at > ?`, ticketHash, s.now().UTC().UnixMilli()).
		Scan(&ticket.SessionHash, &ticket.Subject, &ticket.Space, &ticket.Origin, &ticket.Cursor, &expires)
	if errors.Is(err, sql.ErrNoRows) {
		return WebSocketTicket{}, ErrNotFound
	}
	if err != nil {
		return WebSocketTicket{}, fmt.Errorf("get websocket ticket: %w", err)
	}
	ticket.TicketHash = append([]byte(nil), ticketHash...)
	ticket.ExpiresAt = millisTime(expires)
	now := s.now().UTC()
	if !now.Before(ticket.ExpiresAt) {
		return WebSocketTicket{}, ErrExpired
	}
	if ticket.Origin != origin {
		return WebSocketTicket{}, fmt.Errorf("%w: websocket origin mismatch", ErrInvalid)
	}
	result, err := tx.ExecContext(ctx, `UPDATE opendrop_websocket_tickets SET used_at = ? WHERE ticket_hash = ? AND used_at IS NULL`, now.UnixMilli(), ticketHash)
	if err != nil {
		return WebSocketTicket{}, fmt.Errorf("consume websocket ticket: %w", err)
	}
	rows, err := result.RowsAffected()
	if err != nil || rows != 1 {
		return WebSocketTicket{}, ErrReplay
	}
	if err := tx.Commit(); err != nil {
		return WebSocketTicket{}, fmt.Errorf("commit websocket ticket: %w", err)
	}
	return ticket, nil
}
