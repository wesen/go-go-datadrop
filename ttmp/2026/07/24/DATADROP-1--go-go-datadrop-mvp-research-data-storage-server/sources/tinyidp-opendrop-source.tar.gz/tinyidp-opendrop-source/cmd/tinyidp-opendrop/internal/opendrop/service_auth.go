package opendrop

import (
	"context"
	"errors"
	"github.com/go-go-golems/tiny-idp/cmd/tinyidp-opendrop/internal/resourceauth"
	"github.com/go-go-golems/tiny-idp/pkg/idp"
	"log/slog"
	"net/http"
	"strings"
	"time"
)

func (s *Service) handleExchange(w http.ResponseWriter, r *http.Request) {
	origin, err := requestOrigin(r)
	if err != nil || (origin != "" && !s.originAllowed(origin)) {
		writeAPIError(w, http.StatusForbidden, "origin_not_allowed", "browser origin is not registered")
		return
	}
	bearer, ok := parseAuthorization(r.Header.Values("Authorization"), "Bearer")
	if !ok {
		w.Header().Set("WWW-Authenticate", `Bearer realm="opendrop"`)
		writeAPIError(w, http.StatusUnauthorized, "unauthorized", "a TinyIDP bearer token is required")
		return
	}
	result := s.auth.Authenticate(r.Context(), r.Header.Values("Authorization"), []string{ScopeRead})
	if result.Outcome != resourceauth.OutcomeAuthenticated {
		s.writeResourceAuthFailure(w, result.Outcome)
		return
	}
	rawProof, ok := singleHeader(r.Header.Values("DPoP"))
	if !ok {
		writeAPIError(w, http.StatusBadRequest, "invalid_dpop_proof", "one DPoP proof is required")
		return
	}
	proof, err := s.verifier.Validate(r.Context(), r, rawProof, bearer, "")
	if err != nil {
		s.record(r.Context(), "opendrop.auth.exchange_rejected", result.Principal.Subject, result.Principal.ClientID, "invalid_dpop_proof", "")
		writeAPIError(w, http.StatusBadRequest, "invalid_dpop_proof", "DPoP proof validation failed")
		return
	}
	if err := s.store.BindBearerToken(r.Context(), tokenDigest(bearer), proof.JKT, result.Principal.Subject, origin, result.Principal.ExpiresAt); err != nil {
		s.record(r.Context(), "opendrop.auth.exchange_rejected", result.Principal.Subject, result.Principal.ClientID, "bearer_binding_conflict", "")
		if errors.Is(err, ErrConflict) {
			writeAPIError(w, http.StatusUnauthorized, "bearer_already_bound", "TinyIDP token is already bound to another browser key or origin")
			return
		}
		s.writeStoreError(w, err)
		return
	}
	token, err := randomToken()
	if err != nil {
		writeAPIError(w, http.StatusInternalServerError, "server_error", "could not create a session")
		return
	}
	now := time.Now().UTC()
	expiresAt := now.Add(s.sessionTTL)
	if result.Principal.ExpiresAt.Before(expiresAt) {
		expiresAt = result.Principal.ExpiresAt
	}
	if !expiresAt.After(now) {
		writeAPIError(w, http.StatusUnauthorized, "unauthorized", "TinyIDP token has expired")
		return
	}
	session := Session{
		TokenHash:  tokenDigest(token),
		Subject:    result.Principal.Subject,
		ClientID:   result.Principal.ClientID,
		Scopes:     result.Principal.Scopes,
		JKT:        proof.JKT,
		Origin:     origin,
		CreatedAt:  now,
		ExpiresAt:  expiresAt,
		LastUsedAt: now,
	}
	if err := s.store.CreateSession(r.Context(), session); err != nil {
		writeAPIError(w, http.StatusInternalServerError, "server_error", "could not persist the session")
		return
	}
	s.record(r.Context(), "opendrop.auth.exchanged", session.Subject, session.ClientID, "accepted", "")
	writeJSON(w, http.StatusOK, map[string]any{
		"access_token": token,
		"token_type":   "DPoP",
		"expires_in":   int(time.Until(expiresAt).Seconds()),
		"scope":        strings.Join(session.Scopes, " "),
		"subject":      session.Subject,
		"jkt":          session.JKT,
	})
}
func (s *Service) handleRevoke(w http.ResponseWriter, r *http.Request, principal requestPrincipal) {
	if err := s.store.RevokeSession(r.Context(), principal.Session.TokenHash); err != nil && !errors.Is(err, ErrNotFound) {
		s.writeStoreError(w, err)
		return
	}
	s.record(r.Context(), "opendrop.auth.revoked", principal.Session.Subject, principal.Session.ClientID, "accepted", "")
	w.WriteHeader(http.StatusNoContent)
}
func (s *Service) authenticateDPoP(w http.ResponseWriter, r *http.Request, requiredScope string) (requestPrincipal, bool) {
	token, ok := parseAuthorization(r.Header.Values("Authorization"), "DPoP")
	if !ok {
		s.writeDPoPAuthFailure(w, "invalid_token")
		return requestPrincipal{}, false
	}
	session, err := s.store.GetSession(r.Context(), tokenDigest(token))
	if err != nil {
		s.writeDPoPAuthFailure(w, "invalid_token")
		return requestPrincipal{}, false
	}
	origin, err := requestOrigin(r)
	if err != nil {
		s.writeDPoPAuthFailure(w, "origin_mismatch")
		return requestPrincipal{}, false
	}
	if session.Origin == "" {
		if origin != "" {
			s.writeDPoPAuthFailure(w, "origin_mismatch")
			return requestPrincipal{}, false
		}
	} else if origin != "" && origin != session.Origin {
		s.writeDPoPAuthFailure(w, "origin_mismatch")
		return requestPrincipal{}, false
	}
	rawProof, ok := singleHeader(r.Header.Values("DPoP"))
	if !ok {
		s.writeDPoPAuthFailure(w, "invalid_dpop_proof")
		return requestPrincipal{}, false
	}
	if _, err := s.verifier.Validate(r.Context(), r, rawProof, token, session.JKT); err != nil {
		s.record(r.Context(), "opendrop.auth.rejected", session.Subject, session.ClientID, "invalid_dpop_proof", "")
		s.writeDPoPAuthFailure(w, "invalid_dpop_proof")
		return requestPrincipal{}, false
	}
	if requiredScope != "" && !hasScope(session.Scopes, requiredScope) {
		writeAPIError(w, http.StatusForbidden, "insufficient_scope", "session does not grant the required scope")
		return requestPrincipal{}, false
	}
	return requestPrincipal{Session: session, Token: token}, true
}
func scopeForRoute(path string) string {
	switch path {
	case "/xrpc/io.opendrop.space.list", "/xrpc/io.opendrop.record.get", "/xrpc/io.opendrop.record.list",
		"/xrpc/io.opendrop.stream.range", "/xrpc/io.opendrop.sync.subscribe", "/xrpc/io.opendrop.sync.websocketTicket":
		return ScopeRead
	case "/xrpc/io.opendrop.script.get", "/xrpc/io.opendrop.script.list", "/xrpc/io.opendrop.script.run", "/xrpc/io.opendrop.script.put":
		return ScopeScript
	case "/xrpc/io.opendrop.auth.revoke":
		return ""
	default:
		return ScopeWrite
	}
}
func (s *Service) applyCORS(w http.ResponseWriter, r *http.Request) bool {
	origin, err := requestOrigin(r)
	if err != nil {
		writeAPIError(w, http.StatusForbidden, "origin_not_allowed", "browser origin is invalid")
		return false
	}
	if origin == "" {
		return true
	}
	if !s.originAllowed(origin) {
		writeAPIError(w, http.StatusForbidden, "origin_not_allowed", "browser origin is not registered")
		return false
	}
	w.Header().Set("Access-Control-Allow-Origin", origin)
	w.Header().Add("Vary", "Origin")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Authorization, DPoP, Content-Type, Last-Event-ID")
	w.Header().Set("Access-Control-Expose-Headers", "Content-Type, WWW-Authenticate, X-OpenDrop-Cursor")
	w.Header().Set("Access-Control-Max-Age", "600")
	return true
}
func requestOrigin(r *http.Request) (string, error) {
	values := r.Header.Values("Origin")
	if len(values) == 0 {
		return "", nil
	}
	if len(values) != 1 {
		return "", errors.New("multiple Origin headers")
	}
	raw := strings.TrimSpace(values[0])
	if raw == "" || strings.Contains(raw, ",") {
		return "", errors.New("invalid Origin header")
	}
	return normalizeOrigin(raw)
}
func (s *Service) originAllowed(raw string) bool {
	origin, err := normalizeOrigin(raw)
	if err != nil {
		return false
	}
	_, ok := s.allowedOrigins[origin]
	return ok
}
func (s *Service) writeResourceAuthFailure(w http.ResponseWriter, outcome resourceauth.Outcome) {
	switch outcome {
	case resourceauth.OutcomeForbidden:
		writeAPIError(w, http.StatusForbidden, "insufficient_scope", "TinyIDP token lacks the OpenDrop scope")
	case resourceauth.OutcomeUnavailable:
		writeAPIError(w, http.StatusServiceUnavailable, "identity_provider_unavailable", "TinyIDP token validation is unavailable")
	default:
		w.Header().Set("WWW-Authenticate", `Bearer realm="opendrop"`)
		writeAPIError(w, http.StatusUnauthorized, "unauthorized", "TinyIDP token is inactive")
	}
}
func (s *Service) writeDPoPAuthFailure(w http.ResponseWriter, reason string) {
	w.Header().Set("WWW-Authenticate", `DPoP realm="opendrop", error="invalid_token"`)
	writeAPIError(w, http.StatusUnauthorized, reason, "DPoP session validation failed")
}
func (s *Service) writeStoreError(w http.ResponseWriter, err error) {
	switch {
	case errors.Is(err, ErrInvalid):
		writeAPIError(w, http.StatusBadRequest, "invalid_request", err.Error())
	case errors.Is(err, ErrNotFound):
		writeAPIError(w, http.StatusNotFound, "not_found", "resource not found")
	case errors.Is(err, ErrConflict):
		writeAPIError(w, http.StatusConflict, "conflict", err.Error())
	case errors.Is(err, ErrExpired):
		writeAPIError(w, http.StatusUnauthorized, "expired", "credential has expired")
	default:
		slog.Error("OpenDrop storage operation failed", "error", err)
		writeAPIError(w, http.StatusInternalServerError, "server_error", "storage operation failed")
	}
}
func (s *Service) record(ctx context.Context, name, subject, clientID, reason, space string) {
	if s == nil || s.audit == nil {
		return
	}
	result := "accepted"
	if reason != "accepted" {
		result = "rejected"
	}
	fields := map[string]string{"credential_kind": "dpop"}
	if space != "" {
		fields["space"] = space
	}
	if err := s.audit.Emit(ctx, idp.Event{Time: time.Now().UTC(), Name: name, Subject: subject, ClientID: clientID, Result: result, Reason: reason, Fields: fields}); err != nil {
		slog.Error("record OpenDrop audit event", "event", name, "error", err)
	}
}
