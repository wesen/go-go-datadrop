package opendrop

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
)

func (s *Store) CreateSpace(ctx context.Context, owner, name string) (Space, error) {
	if strings.TrimSpace(owner) == "" {
		return Space{}, fmt.Errorf("%w: owner is required", ErrInvalid)
	}
	name, err := validateSpaceName(name)
	if err != nil {
		return Space{}, err
	}
	now := s.now().UTC()
	stamp := now.UnixMilli()
	if _, err := s.db.ExecContext(ctx, `INSERT INTO opendrop_spaces(owner_sub, name, created_at, updated_at)
		VALUES(?, ?, ?, ?) ON CONFLICT(owner_sub, name) DO NOTHING`, owner, name, stamp, stamp); err != nil {
		return Space{}, fmt.Errorf("create space: %w", err)
	}
	return s.getSpace(ctx, owner, name)
}
func (s *Store) getSpace(ctx context.Context, owner, name string) (Space, error) {
	var created, updated int64
	err := s.db.QueryRowContext(ctx, `SELECT created_at, updated_at FROM opendrop_spaces WHERE owner_sub = ? AND name = ?`, owner, name).Scan(&created, &updated)
	if errors.Is(err, sql.ErrNoRows) {
		return Space{}, ErrNotFound
	}
	if err != nil {
		return Space{}, fmt.Errorf("get space: %w", err)
	}
	return Space{Name: name, CreatedAt: millisTime(created), UpdatedAt: millisTime(updated)}, nil
}
func (s *Store) ListSpaces(ctx context.Context, owner string) ([]Space, error) {
	rows, err := s.db.QueryContext(ctx, `SELECT name, created_at, updated_at FROM opendrop_spaces WHERE owner_sub = ? ORDER BY name`, owner)
	if err != nil {
		return nil, fmt.Errorf("list spaces: %w", err)
	}
	defer rows.Close()
	spaces := make([]Space, 0)
	for rows.Next() {
		var space Space
		var created, updated int64
		if err := rows.Scan(&space.Name, &created, &updated); err != nil {
			return nil, fmt.Errorf("scan space: %w", err)
		}
		space.CreatedAt, space.UpdatedAt = millisTime(created), millisTime(updated)
		spaces = append(spaces, space)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate spaces: %w", err)
	}
	return spaces, nil
}
