const SESSION_KEY = "opendrop.session.v1";
const OAUTH_KEY = "opendrop.oauth.v1";
const KEY_DATABASE = "opendrop-browser-v1";
const KEY_STORE = "dpop-keys";

export class OpenDropClient {
  constructor({ baseURL = globalThis.location?.origin } = {}) {
    this.baseURL = normalizeBaseURL(baseURL);
    this.metadata = null;
  }

  async initialize() {
    const response = await fetch(new URL("/.well-known/opendrop", this.baseURL), {
      headers: { Accept: "application/json" },
      mode: "cors",
      cache: "no-store",
    });
    if (!response.ok) throw await responseError(response);
    this.metadata = await response.json();
    return this.metadata;
  }

  session() {
    const raw = sessionStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    try {
      const value = JSON.parse(raw);
      if (value.baseURL !== this.baseURL || !value.accessToken || value.expiresAt <= Date.now()) {
        sessionStorage.removeItem(SESSION_KEY);
        return null;
      }
      return value;
    } catch {
      sessionStorage.removeItem(SESSION_KEY);
      return null;
    }
  }

  async login() {
    const metadata = this.metadata || await this.initialize();
    const discovery = await fetchJSON(`${metadata.issuer}/.well-known/openid-configuration`);
    const verifier = randomBase64URL(48);
    const challenge = base64URL(await sha256(verifier));
    const state = randomBase64URL(24);
    const redirectURI = `${location.origin}/opendrop/callback.html`;
    await getOrCreateDPoPKey(this.baseURL);

    sessionStorage.setItem(OAUTH_KEY, JSON.stringify({
      baseURL: this.baseURL,
      verifier,
      state,
      redirectURI,
      startedAt: Date.now(),
    }));

    const authorizationURL = new URL(discovery.authorization_endpoint);
    authorizationURL.searchParams.set("response_type", "code");
    authorizationURL.searchParams.set("client_id", metadata.clientId);
    authorizationURL.searchParams.set("redirect_uri", redirectURI);
    authorizationURL.searchParams.set("scope", `openid profile email ${metadata.scopes.join(" ")}`);
    authorizationURL.searchParams.set("audience", metadata.audience);
    authorizationURL.searchParams.set("state", state);
    authorizationURL.searchParams.set("code_challenge", challenge);
    authorizationURL.searchParams.set("code_challenge_method", "S256");
    location.assign(authorizationURL.toString());
  }

  static async completeLogin() {
    const raw = sessionStorage.getItem(OAUTH_KEY);
    if (!raw) throw new Error("The login transaction is missing or expired.");
    const transaction = JSON.parse(raw);
    if (Date.now() - transaction.startedAt > 10 * 60 * 1000) {
      sessionStorage.removeItem(OAUTH_KEY);
      throw new Error("The login transaction expired.");
    }
    const callbackURL = new URL(location.href);
    const oauthError = callbackURL.searchParams.get("error");
    if (oauthError) {
      throw new Error(`${oauthError}: ${callbackURL.searchParams.get("error_description") || "authorization failed"}`);
    }
    const code = callbackURL.searchParams.get("code");
    const state = callbackURL.searchParams.get("state");
    if (!code || state !== transaction.state) throw new Error("OAuth state validation failed.");

    const client = new OpenDropClient({ baseURL: transaction.baseURL });
    const metadata = await client.initialize();
    const discovery = await fetchJSON(`${metadata.issuer}/.well-known/openid-configuration`);
    const tokenForm = new URLSearchParams({
      grant_type: "authorization_code",
      client_id: metadata.clientId,
      code,
      redirect_uri: transaction.redirectURI,
      code_verifier: transaction.verifier,
    });
    const tokenResponse = await fetch(discovery.token_endpoint, {
      method: "POST",
      mode: "cors",
      headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" },
      body: tokenForm,
    });
    if (!tokenResponse.ok) throw await responseError(tokenResponse);
    const oauthTokens = await tokenResponse.json();
    if (!oauthTokens.access_token) throw new Error("TinyIDP did not return an access token.");

    const exchangeURL = new URL("/xrpc/io.opendrop.auth.exchange", client.baseURL);
    const proof = await createDPoPProof("POST", exchangeURL, oauthTokens.access_token);
    const exchangeResponse = await fetch(exchangeURL, {
      method: "POST",
      mode: "cors",
      headers: {
        Authorization: `Bearer ${oauthTokens.access_token}`,
        DPoP: proof,
        Accept: "application/json",
      },
    });
    if (!exchangeResponse.ok) throw await responseError(exchangeResponse);
    const storageSession = await exchangeResponse.json();
    sessionStorage.setItem(SESSION_KEY, JSON.stringify({
      baseURL: client.baseURL,
      accessToken: storageSession.access_token,
      tokenType: storageSession.token_type,
      subject: storageSession.subject,
      scope: storageSession.scope,
      jkt: storageSession.jkt,
      expiresAt: Date.now() + Math.max(1, storageSession.expires_in - 10) * 1000,
    }));
    sessionStorage.removeItem(OAUTH_KEY);
    return client;
  }

  async logout() {
    if (this.session()) {
      try {
        await this.request("/xrpc/io.opendrop.auth.revoke", { method: "POST", body: {} });
      } catch {
        // Local logout still completes if the server is unavailable.
      }
    }
    sessionStorage.removeItem(SESSION_KEY);
  }

  async request(path, { method = "GET", body, query, signal } = {}) {
    const session = this.session();
    if (!session) throw new Error("OpenDrop login is required.");
    const url = new URL(path, this.baseURL);
    if (query) {
      for (const [key, value] of Object.entries(query)) {
        if (value !== undefined && value !== null && value !== "") url.searchParams.set(key, String(value));
      }
    }
    const proof = await createDPoPProof(method, url, session.accessToken);
    const headers = {
      Authorization: `DPoP ${session.accessToken}`,
      DPoP: proof,
      Accept: "application/json",
    };
    let payload;
    if (body !== undefined) {
      headers["Content-Type"] = "application/json";
      payload = JSON.stringify(body);
    }
    const response = await fetch(url, { method, mode: "cors", headers, body: payload, signal, cache: "no-store" });
    if (!response.ok) throw await responseError(response);
    if (response.status === 204) return null;
    return response.json();
  }

  async subscribe(space, { cursor = 0, signal, onEvent } = {}) {
    const session = this.session();
    if (!session) throw new Error("OpenDrop login is required.");
    const url = new URL("/xrpc/io.opendrop.sync.subscribe", this.baseURL);
    url.searchParams.set("space", space);
    url.searchParams.set("cursor", String(cursor));
    const proof = await createDPoPProof("GET", url, session.accessToken);
    const response = await fetch(url, {
      method: "GET",
      mode: "cors",
      cache: "no-store",
      signal,
      headers: {
        Authorization: `DPoP ${session.accessToken}`,
        DPoP: proof,
        Accept: "application/x-ndjson",
      },
    });
    if (!response.ok) throw await responseError(response);
    if (!response.body) throw new Error("This browser does not expose fetch streaming.");

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffered = "";
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffered += decoder.decode(value, { stream: true });
      let newline;
      while ((newline = buffered.indexOf("\n")) >= 0) {
        const line = buffered.slice(0, newline).trim();
        buffered = buffered.slice(newline + 1);
        if (line) onEvent?.(JSON.parse(line));
      }
    }
    buffered += decoder.decode();
    if (buffered.trim()) onEvent?.(JSON.parse(buffered));
  }

  async websocket(space, { cursor = 0, onEvent, onOpen, onClose, onError } = {}) {
    const issued = await this.request("/xrpc/io.opendrop.sync.websocketTicket", {
      method: "POST",
      body: { space, cursor },
    });
    const socket = new WebSocket(issued.websocketUrl, issued.subprotocol);
    socket.addEventListener("open", event => onOpen?.(event));
    socket.addEventListener("message", event => {
      try { onEvent?.(JSON.parse(event.data)); } catch (error) { onError?.(error); }
    });
    socket.addEventListener("close", event => onClose?.(event));
    socket.addEventListener("error", event => onError?.(event));
    return socket;
  }
}

async function createDPoPProof(method, requestURL, accessToken) {
  const url = new URL(requestURL);
  const key = await getOrCreateDPoPKey(url.origin);
  const header = {
    typ: "dpop+jwt",
    alg: "ES256",
    jwk: {
      kty: key.publicJWK.kty,
      crv: key.publicJWK.crv,
      x: key.publicJWK.x,
      y: key.publicJWK.y,
    },
  };
  const claims = {
    jti: randomBase64URL(18),
    htm: method.toUpperCase(),
    htu: `${url.origin}${url.pathname}`,
    iat: Math.floor(Date.now() / 1000),
  };
  if (accessToken) claims.ath = base64URL(await sha256(accessToken));
  const encodedHeader = base64URL(new TextEncoder().encode(JSON.stringify(header)));
  const encodedClaims = base64URL(new TextEncoder().encode(JSON.stringify(claims)));
  const signingInput = `${encodedHeader}.${encodedClaims}`;
  const signatureBuffer = await crypto.subtle.sign(
    { name: "ECDSA", hash: "SHA-256" },
    key.privateKey,
    new TextEncoder().encode(signingInput),
  );
  let signature = new Uint8Array(signatureBuffer);
  if (signature.length !== 64) signature = derECDSAToJOSE(signature, 32);
  return `${signingInput}.${base64URL(signature)}`;
}

async function getOrCreateDPoPKey(audienceOrigin) {
  const keyID = `dpop:${normalizeBaseURL(audienceOrigin)}`;
  const existing = await idbGet(keyID);
  if (existing?.privateKey && existing?.publicJWK) return existing;
  const pair = await crypto.subtle.generateKey(
    { name: "ECDSA", namedCurve: "P-256" },
    false,
    ["sign", "verify"],
  );
  const publicJWK = await crypto.subtle.exportKey("jwk", pair.publicKey);
  const stored = { id: keyID, privateKey: pair.privateKey, publicKey: pair.publicKey, publicJWK };
  await idbPut(stored);
  return stored;
}

function openKeyDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(KEY_DATABASE, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(KEY_STORE, { keyPath: "id" });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function idbGet(id) {
  const database = await openKeyDatabase();
  try {
    return await new Promise((resolve, reject) => {
      const request = database.transaction(KEY_STORE, "readonly").objectStore(KEY_STORE).get(id);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  } finally {
    database.close();
  }
}

async function idbPut(value) {
  const database = await openKeyDatabase();
  try {
    await new Promise((resolve, reject) => {
      const transaction = database.transaction(KEY_STORE, "readwrite");
      transaction.objectStore(KEY_STORE).put(value);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error);
    });
  } finally {
    database.close();
  }
}

async function fetchJSON(url) {
  const response = await fetch(url, { headers: { Accept: "application/json" }, mode: "cors", cache: "no-store" });
  if (!response.ok) throw await responseError(response);
  return response.json();
}

async function responseError(response) {
  let detail;
  try { detail = await response.json(); } catch { detail = null; }
  const message = detail?.message || detail?.error_description || detail?.error || `${response.status} ${response.statusText}`;
  const error = new Error(message);
  error.status = response.status;
  error.code = detail?.error;
  return error;
}

async function sha256(value) {
  const bytes = typeof value === "string" ? new TextEncoder().encode(value) : value;
  return new Uint8Array(await crypto.subtle.digest("SHA-256", bytes));
}

function randomBase64URL(length) {
  return base64URL(crypto.getRandomValues(new Uint8Array(length)));
}

function base64URL(value) {
  const bytes = value instanceof Uint8Array ? value : new Uint8Array(value);
  let binary = "";
  for (let offset = 0; offset < bytes.length; offset += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
  }
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function derECDSAToJOSE(signature, width) {
  let offset = 0;
  if (signature[offset++] !== 0x30) throw new Error("Unsupported ECDSA signature encoding.");
  const sequenceLength = readDERLength(signature, offset);
  offset = sequenceLength.offset;
  if (offset + sequenceLength.length !== signature.length) throw new Error("Invalid ECDSA signature length.");
  if (signature[offset++] !== 0x02) throw new Error("Invalid ECDSA r value.");
  const rLength = readDERLength(signature, offset);
  offset = rLength.offset;
  const r = signature.slice(offset, offset + rLength.length);
  offset += rLength.length;
  if (signature[offset++] !== 0x02) throw new Error("Invalid ECDSA s value.");
  const sLength = readDERLength(signature, offset);
  offset = sLength.offset;
  const s = signature.slice(offset, offset + sLength.length);
  return concatPaddedInteger(r, s, width);
}

function readDERLength(bytes, offset) {
  const first = bytes[offset++];
  if ((first & 0x80) === 0) return { length: first, offset };
  const count = first & 0x7f;
  if (count === 0 || count > 2) throw new Error("Unsupported DER length.");
  let length = 0;
  for (let i = 0; i < count; i++) length = (length << 8) | bytes[offset++];
  return { length, offset };
}

function concatPaddedInteger(r, s, width) {
  const output = new Uint8Array(width * 2);
  const normalizedR = stripIntegerPadding(r);
  const normalizedS = stripIntegerPadding(s);
  if (normalizedR.length > width || normalizedS.length > width) throw new Error("ECDSA integer exceeds curve width.");
  output.set(normalizedR, width - normalizedR.length);
  output.set(normalizedS, width * 2 - normalizedS.length);
  return output;
}

function stripIntegerPadding(value) {
  let offset = 0;
  while (offset < value.length - 1 && value[offset] === 0) offset++;
  return value.slice(offset);
}

function normalizeBaseURL(raw) {
  const parsed = new URL(raw);
  if (!/^https?:$/.test(parsed.protocol) || parsed.username || parsed.password || parsed.search || parsed.hash) {
    throw new Error("OpenDrop base URL must be an HTTP(S) origin.");
  }
  return parsed.origin;
}
