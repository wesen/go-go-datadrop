package opendrop

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
)

func (s *Store) PutScript(ctx context.Context, owner, space, name, source string, enabled bool, swapRev string) (Script, Event, error) {
	space, err := validateSpaceName(space)
	if err != nil {
		return Script{}, Event{}, err
	}
	name, err = validateScriptName(name)
	if err != nil {
		return Script{}, Event{}, err
	}
	if strings.TrimSpace(source) == "" || len(source) > maxScriptSourceBytes {
		return Script{}, Event{}, fmt.Errorf("%w: script source must contain 1..%d bytes", ErrInvalid, maxScriptSourceBytes)
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return Script{}, Event{}, fmt.Errorf("begin put script: %w", err)
	}
	defer func() { _ = tx.Rollback() }()
	if err := ensureSpaceTx(ctx, tx, owner, space); err != nil {
		return Script{}, Event{}, err
	}
	now := s.now().UTC()
	createdAt := now
	var existingRev string
	var existingCreated int64
	err = tx.QueryRowContext(ctx, `SELECT rev, created_at FROM opendrop_scripts WHERE owner_sub = ? AND space = ? AND name = ?`, owner, space, name).Scan(&existingRev, &existingCreated)
	switch {
	case errors.Is(err, sql.ErrNoRows):
		if swapRev != "" {
			return Script{}, Event{}, fmt.Errorf("%w: script does not exist", ErrConflict)
		}
	case err != nil:
		return Script{}, Event{}, fmt.Errorf("load script revision: %w", err)
	default:
		createdAt = millisTime(existingCreated)
		if swapRev != "" && swapRev != existingRev {
			return Script{}, Event{}, fmt.Errorf("%w: script revision changed", ErrConflict)
		}
	}
	rev, err := randomID("s")
	if err != nil {
		return Script{}, Event{}, err
	}
	enabledInt := 0
	if enabled {
		enabledInt = 1
	}
	_, err = tx.ExecContext(ctx, `INSERT INTO opendrop_scripts(owner_sub, space, name, rev, source, enabled, created_at, updated_at)
		VALUES(?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(owner_sub, space, name) DO UPDATE SET
		rev = excluded.rev, source = excluded.source, enabled = excluded.enabled, updated_at = excluded.updated_at`,
		owner, space, name, rev, source, enabledInt, createdAt.UnixMilli(), now.UnixMilli())
	if err != nil {
		return Script{}, Event{}, fmt.Errorf("put script: %w", err)
	}
	script := Script{Space: space, Name: name, Rev: rev, Source: source, Enabled: enabled, CreatedAt: createdAt, UpdatedAt: now}
	body, err := json.Marshal(map[string]any{"script": map[string]any{"space": space, "name": name, "rev": rev, "enabled": enabled}})
	if err != nil {
		return Script{}, Event{}, fmt.Errorf("encode script event: %w", err)
	}
	event, err := insertEventTx(ctx, tx, owner, Event{Space: space, Kind: "script.put", Collection: "io.opendrop.script", RKey: name, Rev: rev, CID: contentID([]byte(source)), Body: body, CreatedAt: now})
	if err != nil {
		return Script{}, Event{}, err
	}
	if _, err := tx.ExecContext(ctx, `UPDATE opendrop_spaces SET updated_at = ? WHERE owner_sub = ? AND name = ?`, now.UnixMilli(), owner, space); err != nil {
		return Script{}, Event{}, fmt.Errorf("touch space: %w", err)
	}
	if err := tx.Commit(); err != nil {
		return Script{}, Event{}, fmt.Errorf("commit put script: %w", err)
	}
	script.Cursor = event.Seq
	return script, event, nil
}
func (s *Store) GetScript(ctx context.Context, owner, space, name string) (Script, error) {
	space, err := validateSpaceName(space)
	if err != nil {
		return Script{}, err
	}
	name, err = validateScriptName(name)
	if err != nil {
		return Script{}, err
	}
	var script Script
	var enabled int
	var created, updated int64
	err = s.db.QueryRowContext(ctx, `SELECT rev, source, enabled, created_at, updated_at FROM opendrop_scripts
		WHERE owner_sub = ? AND space = ? AND name = ?`, owner, space, name).
		Scan(&script.Rev, &script.Source, &enabled, &created, &updated)
	if errors.Is(err, sql.ErrNoRows) {
		return Script{}, ErrNotFound
	}
	if err != nil {
		return Script{}, fmt.Errorf("get script: %w", err)
	}
	script.Space, script.Name, script.Enabled = space, name, enabled != 0
	script.CreatedAt, script.UpdatedAt = millisTime(created), millisTime(updated)
	return script, nil
}
func (s *Store) ListScripts(ctx context.Context, owner, space string) ([]Script, error) {
	space, err := validateSpaceName(space)
	if err != nil {
		return nil, err
	}
	if _, err := s.getSpace(ctx, owner, space); err != nil {
		return nil, err
	}
	rows, err := s.db.QueryContext(ctx, `SELECT name, rev, enabled, created_at, updated_at FROM opendrop_scripts
		WHERE owner_sub = ? AND space = ? ORDER BY name`, owner, space)
	if err != nil {
		return nil, fmt.Errorf("list scripts: %w", err)
	}
	defer rows.Close()
	scripts := make([]Script, 0)
	for rows.Next() {
		var script Script
		var enabled int
		var created, updated int64
		if err := rows.Scan(&script.Name, &script.Rev, &enabled, &created, &updated); err != nil {
			return nil, fmt.Errorf("scan script: %w", err)
		}
		script.Space, script.Enabled = space, enabled != 0
		script.CreatedAt, script.UpdatedAt = millisTime(created), millisTime(updated)
		scripts = append(scripts, script)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate scripts: %w", err)
	}
	return scripts, nil
}
