package opendrop

import (
	"context"
	"errors"
	"github.com/go-go-golems/tiny-idp/cmd/tinyidp-opendrop/internal/resourceauth"
	"github.com/go-go-golems/tiny-idp/pkg/idp"
	"net/http"
	"net/url"
	"strings"
	"time"
)

const (
	BrowserClientID = "tinyidp-opendrop-browser"

	ScopeRead   = "opendrop.read"
	ScopeWrite  = "opendrop.write"
	ScopeScript = "opendrop.script"

	maxRequestBodyBytes    = 320 << 10
	maxScriptSnapshotItems = 32
	defaultSessionTTL      = time.Hour
	webSocketTicketTTL     = 30 * time.Second
)

type Options struct {
	DatabasePath   string
	PublicBaseURL  string
	Authenticator  *resourceauth.Authenticator
	AllowedOrigins []string
	Audit          idp.Sink
	SessionTTL     time.Duration
}

type Service struct {
	store          *Store
	auth           *resourceauth.Authenticator
	verifier       *DPoPVerifier
	hub            *Hub
	scripts        *ScriptRunner
	audit          idp.Sink
	publicBaseURL  string
	allowedOrigins map[string]struct{}
	sessionTTL     time.Duration
	web            http.Handler
}

type requestPrincipal struct {
	Session Session
	Token   string
}

func NewService(ctx context.Context, opts Options) (*Service, error) {
	if ctx == nil {
		return nil, errors.New("OpenDrop service context is required")
	}
	if opts.Authenticator == nil {
		return nil, errors.New("OpenDrop resource authenticator is required")
	}
	base, err := normalizePublicBaseURL(opts.PublicBaseURL)
	if err != nil {
		return nil, err
	}
	store, err := OpenStore(ctx, opts.DatabasePath)
	if err != nil {
		return nil, err
	}
	verifier, err := NewDPoPVerifier(base, store)
	if err != nil {
		_ = store.Close()
		return nil, err
	}
	runner, err := NewScriptRunner()
	if err != nil {
		_ = store.Close()
		return nil, err
	}
	if opts.Audit == nil {
		_ = store.Close()
		return nil, errors.New("OpenDrop audit sink is required")
	}
	audit := opts.Audit
	ttl := opts.SessionTTL
	if ttl == 0 {
		ttl = defaultSessionTTL
	}
	if ttl < time.Minute || ttl > 24*time.Hour {
		_ = store.Close()
		return nil, errors.New("OpenDrop session TTL must be between one minute and 24 hours")
	}
	origins := make(map[string]struct{})
	baseURL, _ := url.Parse(base)
	origins[baseURL.Scheme+"://"+baseURL.Host] = struct{}{}
	for _, raw := range opts.AllowedOrigins {
		origin, err := normalizeOrigin(raw)
		if err != nil {
			_ = store.Close()
			return nil, err
		}
		origins[origin] = struct{}{}
	}
	service := &Service{
		store:          store,
		auth:           opts.Authenticator,
		verifier:       verifier,
		hub:            NewHub(),
		scripts:        runner,
		audit:          audit,
		publicBaseURL:  base,
		allowedOrigins: origins,
		sessionTTL:     ttl,
	}
	service.web = newWebHandler()
	return service, nil
}
func (s *Service) Close() error {
	if s == nil {
		return nil
	}
	return s.store.Close()
}
func (s *Service) Ready(ctx context.Context) error {
	if s == nil || s.store == nil {
		return errors.New("OpenDrop service is unavailable")
	}
	return s.store.Ping(ctx)
}
func (s *Service) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if s == nil || s.store == nil || s.auth == nil || s.verifier == nil {
		writeAPIError(w, http.StatusServiceUnavailable, "service_unavailable", "OpenDrop is unavailable")
		return
	}
	if !s.applyCORS(w, r) {
		return
	}
	if r.Method == http.MethodOptions {
		w.WriteHeader(http.StatusNoContent)
		return
	}

	switch {
	case r.Method == http.MethodGet && r.URL.Path == "/.well-known/opendrop":
		s.handleMetadata(w, r)
	case r.Method == http.MethodGet && r.URL.Path == "/opendrop":
		http.Redirect(w, r, "/opendrop/", http.StatusPermanentRedirect)
	case strings.HasPrefix(r.URL.Path, "/opendrop/"):
		s.web.ServeHTTP(w, r)
	case r.Method == http.MethodPost && r.URL.Path == "/xrpc/io.opendrop.auth.exchange":
		s.handleExchange(w, r)
	case r.Method == http.MethodGet && r.URL.Path == "/xrpc/io.opendrop.sync.websocket":
		s.handleWebSocket(w, r)
	case strings.HasPrefix(r.URL.Path, "/xrpc/"):
		s.handleXRPC(w, r)
	default:
		writeAPIError(w, http.StatusNotFound, "not_found", "route not found")
	}
}
func (s *Service) handleXRPC(w http.ResponseWriter, r *http.Request) {
	requiredScope := scopeForRoute(r.URL.Path)
	principal, ok := s.authenticateDPoP(w, r, requiredScope)
	if !ok {
		return
	}

	switch {
	case r.Method == http.MethodPost && r.URL.Path == "/xrpc/io.opendrop.auth.revoke":
		s.handleRevoke(w, r, principal)
	case r.Method == http.MethodPost && r.URL.Path == "/xrpc/io.opendrop.space.create":
		s.handleCreateSpace(w, r, principal)
	case r.Method == http.MethodGet && r.URL.Path == "/xrpc/io.opendrop.space.list":
		s.handleListSpaces(w, r, principal)
	case r.Method == http.MethodPost && r.URL.Path == "/xrpc/io.opendrop.record.put":
		s.handlePutRecord(w, r, principal)
	case r.Method == http.MethodGet && r.URL.Path == "/xrpc/io.opendrop.record.get":
		s.handleGetRecord(w, r, principal)
	case r.Method == http.MethodGet && r.URL.Path == "/xrpc/io.opendrop.record.list":
		s.handleListRecords(w, r, principal)
	case r.Method == http.MethodPost && r.URL.Path == "/xrpc/io.opendrop.record.delete":
		s.handleDeleteRecord(w, r, principal)
	case r.Method == http.MethodPost && r.URL.Path == "/xrpc/io.opendrop.stream.append":
		s.handleAppendStream(w, r, principal)
	case r.Method == http.MethodGet && r.URL.Path == "/xrpc/io.opendrop.stream.range":
		s.handleEventRange(w, r, principal)
	case r.Method == http.MethodGet && r.URL.Path == "/xrpc/io.opendrop.sync.subscribe":
		s.handleSubscribe(w, r, principal)
	case r.Method == http.MethodPost && r.URL.Path == "/xrpc/io.opendrop.sync.websocketTicket":
		s.handleWebSocketTicket(w, r, principal)
	case r.Method == http.MethodPost && r.URL.Path == "/xrpc/io.opendrop.script.put":
		s.handlePutScript(w, r, principal)
	case r.Method == http.MethodGet && r.URL.Path == "/xrpc/io.opendrop.script.get":
		s.handleGetScript(w, r, principal)
	case r.Method == http.MethodGet && r.URL.Path == "/xrpc/io.opendrop.script.list":
		s.handleListScripts(w, r, principal)
	case r.Method == http.MethodPost && r.URL.Path == "/xrpc/io.opendrop.script.run":
		s.handleRunScript(w, r, principal)
	default:
		writeAPIError(w, http.StatusNotFound, "not_found", "XRPC method not found")
	}
}
func (s *Service) handleMetadata(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{
		"version":       "0.1",
		"issuer":        s.publicBaseURL + "/idp",
		"clientId":      BrowserClientID,
		"audience":      s.publicBaseURL + "/api",
		"authorization": "oauth2-pkce-then-dpop-exchange",
		"bearerBinding": "first-use-jkt-origin",
		"scopes":        []string{ScopeRead, ScopeWrite, ScopeScript},
		"endpoints": map[string]string{
			"exchange":           s.publicBaseURL + "/xrpc/io.opendrop.auth.exchange",
			"subscribe":          s.publicBaseURL + "/xrpc/io.opendrop.sync.subscribe",
			"websocketTicket":    s.publicBaseURL + "/xrpc/io.opendrop.sync.websocketTicket",
			"websocket":          s.publicBaseURL + "/xrpc/io.opendrop.sync.websocket",
			"browserApplication": s.publicBaseURL + "/opendrop/",
		},
		"limits": map[string]any{
			"recordBytes":         maxRecordValueBytes,
			"scriptBytes":         maxScriptSourceBytes,
			"scriptSnapshotItems": maxScriptSnapshotItems,
			"queryLimit":          maxQueryLimit,
		},
	})
}
