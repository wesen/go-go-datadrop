package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/go-go-golems/tiny-idp/cmd/tinyidp-opendrop/internal/opendrop"
	"github.com/go-go-golems/tiny-idp/cmd/tinyidp-opendrop/internal/resourceauth"
	"github.com/go-go-golems/tiny-idp/pkg/embeddedidp"
	"github.com/go-go-golems/tiny-idp/pkg/idp"
	"github.com/go-go-golems/tiny-idp/pkg/idpaccounts"
	"github.com/go-go-golems/tiny-idp/pkg/sqlitestore"
)

const tinyIDPMaintenanceInterval = 15 * time.Minute

type application struct {
	handler           http.Handler
	provider          *embeddedidp.Provider
	storage           *opendrop.Service
	identity          *sqlitestore.Store
	audit             *idp.FileAuditSink
	tokenSecret       []byte
	maintenanceCancel context.CancelFunc
	maintenanceDone   chan struct{}
}

func newApplication(ctx context.Context, stateRoot string) (*application, error) {
	if ctx == nil {
		return nil, errors.New("application context is required")
	}
	manifest, paths, err := validateState(stateRoot)
	if err != nil {
		return nil, err
	}
	runCtx, maintenanceCancel := context.WithCancel(ctx)
	initialized := false
	defer func() {
		if !initialized {
			maintenanceCancel()
		}
	}()
	tokenSecret, err := os.ReadFile(paths.TokenSecret)
	if err != nil {
		return nil, fmt.Errorf("read TinyIDP token secret: %w", err)
	}
	defer zeroBytes(tokenSecret)
	providerTokenSecret := append([]byte(nil), tokenSecret...)
	defer func() {
		if !initialized {
			zeroBytes(providerTokenSecret)
		}
	}()
	resourceKey, err := os.ReadFile(paths.ResourceClientSecret)
	if err != nil {
		return nil, fmt.Errorf("read resource client secret: %w", err)
	}
	defer zeroBytes(resourceKey)

	audit, err := idp.NewFileAuditSink(paths.AuditLog)
	if err != nil {
		return nil, fmt.Errorf("open audit sink: %w", err)
	}
	var identityStore *sqlitestore.Store
	var provider *embeddedidp.Provider
	var storage *opendrop.Service
	defer func() {
		if initialized {
			return
		}
		maintenanceCancel()
		if storage != nil {
			_ = storage.Close()
		}
		if provider != nil {
			_ = provider.Close(context.Background())
		}
		if identityStore != nil {
			_ = identityStore.Close()
		}
		_ = audit.Close()
	}()

	identityStore, err = sqlitestore.Open(runCtx, sqlitestore.DefaultConfig(paths.IdentityDatabase))
	if err != nil {
		return nil, fmt.Errorf("open TinyIDP store: %w", err)
	}
	accounts, err := idpaccounts.NewService(identityStore, idpaccounts.Options{Audit: audit})
	if err != nil {
		return nil, fmt.Errorf("create TinyIDP account service: %w", err)
	}
	provider, err = embeddedidp.New(runCtx, embeddedidp.Options{
		Issuer:        manifest.Issuer,
		Mode:          embeddedidp.DevMode,
		Store:         identityStore,
		Cookie:        embeddedidp.CookieConfig{Secure: strings.HasPrefix(manifest.PublicBaseURL, "https://"), Path: "/idp"},
		Token:         embeddedidp.TokenConfig{SecretKey: providerTokenSecret},
		Audit:         audit,
		Authenticator: accounts,
		Maintenance: embeddedidp.MaintenanceConfig{
			Interval: tinyIDPMaintenanceInterval,
		},
	})
	if err != nil {
		return nil, fmt.Errorf("create embedded TinyIDP: %w", err)
	}
	issuerTransport, err := embeddedidp.NewInProcessIssuerTransport(
		manifest.Issuer,
		provider.Handler(),
		embeddedidp.InProcessTransportOptions{},
	)
	if err != nil {
		return nil, fmt.Errorf("create in-process TinyIDP transport: %w", err)
	}
	resourceSecret := []byte(resourceClientSecret(resourceKey))
	authenticator, err := resourceauth.New(runCtx, resourceauth.Config{
		IssuerURL:    manifest.Issuer,
		ClientID:     manifest.ResourceClientID,
		ClientSecret: resourceSecret,
		Audience:     manifest.Audience,
		HTTPClient:   &http.Client{Transport: issuerTransport, Timeout: 5 * time.Second},
	})
	zeroBytes(resourceSecret)
	if err != nil {
		return nil, fmt.Errorf("create resource authenticator: %w", err)
	}
	storage, err = opendrop.NewService(runCtx, opendrop.Options{
		DatabasePath:   paths.OpenDropDatabase,
		PublicBaseURL:  manifest.PublicBaseURL,
		Authenticator:  authenticator,
		AllowedOrigins: manifest.AllowedOrigins,
		Audit:          audit,
	})
	if err != nil {
		return nil, fmt.Errorf("create OpenDrop service: %w", err)
	}

	if _, err := provider.RunMaintenance(runCtx); err != nil {
		slog.Error("initial TinyIDP maintenance failed", "error", err)
	}
	maintenanceDone := make(chan struct{})
	go runTinyIDPMaintenance(runCtx, provider, tinyIDPMaintenanceInterval, maintenanceDone)

	mux := http.NewServeMux()
	idpHandler := withOriginCORS(provider.Handler(), manifest.AllowedOrigins)
	mux.Handle("/idp/", idpHandler)
	// OIDC Discovery 1.0 places path-issuer metadata before the issuer path.
	// TinyIDP also supports the nested compatibility route used by resourceauth.
	mux.Handle("/.well-known/openid-configuration/idp", idpHandler)
	mux.Handle("/", storage)
	app := &application{
		identity:          identityStore,
		provider:          provider,
		storage:           storage,
		audit:             audit,
		tokenSecret:       providerTokenSecret,
		handler:           withOperationalEndpoints(mux, provider, storage),
		maintenanceCancel: maintenanceCancel,
		maintenanceDone:   maintenanceDone,
	}
	initialized = true
	return app, nil
}

func (a *application) Handler() http.Handler {
	if a == nil || a.handler == nil {
		return http.NotFoundHandler()
	}
	return a.handler
}

func (a *application) Close(ctx context.Context) error {
	if a == nil {
		return nil
	}
	if ctx == nil {
		ctx = context.Background()
	}
	var result error
	if a.maintenanceCancel != nil {
		a.maintenanceCancel()
	}
	if a.maintenanceDone != nil {
		select {
		case <-a.maintenanceDone:
		case <-ctx.Done():
			result = errors.Join(result, ctx.Err())
		}
	}
	if a.storage != nil {
		result = errors.Join(result, a.storage.Close())
	}
	if a.provider != nil {
		result = errors.Join(result, a.provider.Close(ctx))
	}
	zeroBytes(a.tokenSecret)
	a.tokenSecret = nil
	if a.identity != nil {
		result = errors.Join(result, a.identity.Close())
	}
	if a.audit != nil {
		result = errors.Join(result, a.audit.Close())
	}
	return result
}

func runTinyIDPMaintenance(ctx context.Context, provider *embeddedidp.Provider, interval time.Duration, done chan<- struct{}) {
	defer close(done)
	if provider == nil || interval <= 0 {
		return
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			if _, err := provider.RunMaintenance(ctx); err != nil && ctx.Err() == nil {
				slog.Error("periodic TinyIDP maintenance failed", "error", err)
			}
		}
	}
}

func withOperationalEndpoints(next http.Handler, provider *embeddedidp.Provider, storage *opendrop.Service) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodGet && r.URL.Path == "/healthz":
			status := http.StatusOK
			identity := map[string]any{"ready": provider != nil}
			if provider != nil {
				report := provider.Liveness(r.Context())
				identity = map[string]any{"ready": report.Ready, "checks": report.Checks}
				if !report.Ready {
					status = http.StatusServiceUnavailable
				}
			}
			writeOperationalJSON(w, status, map[string]any{"status": operationalStatus(status), "identity": identity})
			return
		case r.Method == http.MethodGet && r.URL.Path == "/readyz":
			if provider == nil || storage == nil {
				writeOperationalJSON(w, http.StatusServiceUnavailable, map[string]any{"status": "unavailable"})
				return
			}
			ctx, cancel := context.WithTimeout(r.Context(), 2*time.Second)
			defer cancel()
			identity := provider.Readiness(ctx)
			storageErr := storage.Ready(ctx)
			status := http.StatusOK
			if !identity.Ready || storageErr != nil {
				status = http.StatusServiceUnavailable
			}
			storageState := map[string]any{"ready": storageErr == nil}
			if storageErr != nil {
				storageState["reason"] = "storage_unavailable"
			}
			writeOperationalJSON(w, status, map[string]any{
				"status":   operationalStatus(status),
				"identity": identity,
				"storage":  storageState,
			})
			return
		default:
			next.ServeHTTP(w, r)
		}
	})
}

func writeOperationalJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}

func operationalStatus(status int) string {
	if status >= http.StatusInternalServerError {
		return "unavailable"
	}
	return "ready"
}

func withOriginCORS(next http.Handler, allowed []string) http.Handler {
	set := make(map[string]struct{}, len(allowed))
	for _, origin := range allowed {
		set[origin] = struct{}{}
	}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		origin := ""
		if values := r.Header.Values("Origin"); len(values) != 0 {
			if len(values) != 1 || strings.Contains(values[0], ",") {
				w.Header().Set("Content-Type", "application/json")
				w.Header().Set("Cache-Control", "no-store")
				w.WriteHeader(http.StatusForbidden)
				_, _ = w.Write([]byte(`{"error":"origin_not_allowed"}` + "\n"))
				return
			}
			normalized, err := normalizeOrigin(strings.TrimSpace(values[0]))
			if err != nil {
				w.Header().Set("Content-Type", "application/json")
				w.Header().Set("Cache-Control", "no-store")
				w.WriteHeader(http.StatusForbidden)
				_, _ = w.Write([]byte(`{"error":"origin_not_allowed"}` + "\n"))
				return
			}
			origin = normalized
		}
		if origin != "" {
			if _, ok := set[origin]; !ok {
				w.Header().Set("Content-Type", "application/json")
				w.Header().Set("Cache-Control", "no-store")
				w.WriteHeader(http.StatusForbidden)
				_, _ = w.Write([]byte(`{"error":"origin_not_allowed"}` + "\n"))
				return
			}
			w.Header().Set("Access-Control-Allow-Origin", origin)
			w.Header().Add("Vary", "Origin")
			w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
			w.Header().Set("Access-Control-Allow-Headers", "Authorization, Content-Type")
			w.Header().Set("Access-Control-Expose-Headers", "WWW-Authenticate")
			w.Header().Set("Access-Control-Max-Age", "600")
		}
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		next.ServeHTTP(w, r)
	})
}
