package opendrop

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
)

func (s *Store) AppendStream(ctx context.Context, owner, space, stream, rkey string, body json.RawMessage) (Event, error) {
	space, err := validateSpaceName(space)
	if err != nil {
		return Event{}, err
	}
	stream, err = validateCollection(stream)
	if err != nil {
		return Event{}, err
	}
	body, err = normalizeJSON(body, maxRecordValueBytes)
	if err != nil {
		return Event{}, err
	}
	if strings.TrimSpace(rkey) == "" {
		rkey, err = randomID("e")
	} else {
		rkey, err = validateRKey(rkey)
	}
	if err != nil {
		return Event{}, err
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return Event{}, fmt.Errorf("begin append stream: %w", err)
	}
	defer func() { _ = tx.Rollback() }()
	if err := ensureSpaceTx(ctx, tx, owner, space); err != nil {
		return Event{}, err
	}
	now := s.now().UTC()
	rev, err := randomID("r")
	if err != nil {
		return Event{}, err
	}
	event, err := insertEventTx(ctx, tx, owner, Event{Space: space, Kind: "stream.append", Collection: stream, RKey: rkey, Rev: rev, CID: contentID(body), Body: body, CreatedAt: now})
	if err != nil {
		return Event{}, err
	}
	if _, err := tx.ExecContext(ctx, `UPDATE opendrop_spaces SET updated_at = ? WHERE owner_sub = ? AND name = ?`, now.UnixMilli(), owner, space); err != nil {
		return Event{}, fmt.Errorf("touch space: %w", err)
	}
	if err := tx.Commit(); err != nil {
		return Event{}, fmt.Errorf("commit append stream: %w", err)
	}
	return event, nil
}
func (s *Store) EventsAfter(ctx context.Context, owner, space string, cursor int64, limit int) ([]Event, error) {
	space, err := validateSpaceName(space)
	if err != nil {
		return nil, err
	}
	if cursor < 0 {
		return nil, fmt.Errorf("%w: cursor must be non-negative", ErrInvalid)
	}
	limit = normalizeLimit(limit)
	if _, err := s.getSpace(ctx, owner, space); err != nil {
		return nil, err
	}
	rows, err := s.db.QueryContext(ctx, `SELECT seq, kind, collection, rkey, rev, cid, body_json, created_at
		FROM opendrop_events WHERE owner_sub = ? AND space = ? AND seq > ? ORDER BY seq LIMIT ?`, owner, space, cursor, limit)
	if err != nil {
		return nil, fmt.Errorf("read events: %w", err)
	}
	defer rows.Close()
	events := make([]Event, 0)
	for rows.Next() {
		var event Event
		var body []byte
		var created int64
		if err := rows.Scan(&event.Seq, &event.Kind, &event.Collection, &event.RKey, &event.Rev, &event.CID, &body, &created); err != nil {
			return nil, fmt.Errorf("scan event: %w", err)
		}
		event.Space, event.Body, event.CreatedAt = space, cloneJSON(body), millisTime(created)
		events = append(events, event)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate events: %w", err)
	}
	return events, nil
}
