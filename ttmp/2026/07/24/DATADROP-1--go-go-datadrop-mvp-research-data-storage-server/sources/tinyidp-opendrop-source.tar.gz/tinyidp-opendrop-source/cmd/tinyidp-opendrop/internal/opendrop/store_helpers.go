package opendrop

import (
	"bytes"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"database/sql"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"time"
)

func validateRecordInput(space, collection, rkey string, value json.RawMessage) (string, string, string, json.RawMessage, error) {
	var err error
	space, err = validateSpaceName(space)
	if err != nil {
		return "", "", "", nil, err
	}
	collection, err = validateCollection(collection)
	if err != nil {
		return "", "", "", nil, err
	}
	rkey, err = validateRKey(rkey)
	if err != nil {
		return "", "", "", nil, err
	}
	value, err = normalizeJSON(value, maxRecordValueBytes)
	if err != nil {
		return "", "", "", nil, err
	}
	return space, collection, rkey, value, nil
}
func normalizeJSON(value json.RawMessage, limit int) (json.RawMessage, error) {
	if len(value) == 0 || len(value) > limit || !json.Valid(value) {
		return nil, fmt.Errorf("%w: JSON body must contain 1..%d valid bytes", ErrInvalid, limit)
	}
	var compact bytes.Buffer
	if err := json.Compact(&compact, value); err != nil {
		return nil, fmt.Errorf("%w: invalid JSON: %v", ErrInvalid, err)
	}
	return cloneJSON(compact.Bytes()), nil
}
func ensureSpaceTx(ctx context.Context, tx *sql.Tx, owner, space string) error {
	var exists int
	err := tx.QueryRowContext(ctx, `SELECT 1 FROM opendrop_spaces WHERE owner_sub = ? AND name = ?`, owner, space).Scan(&exists)
	if errors.Is(err, sql.ErrNoRows) {
		return ErrNotFound
	}
	if err != nil {
		return fmt.Errorf("check space: %w", err)
	}
	return nil
}
func insertEventTx(ctx context.Context, tx *sql.Tx, owner string, event Event) (Event, error) {
	result, err := tx.ExecContext(ctx, `INSERT INTO opendrop_events(
		owner_sub, space, kind, collection, rkey, rev, cid, body_json, created_at
	) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)`, owner, event.Space, event.Kind, event.Collection, event.RKey, event.Rev, event.CID, []byte(event.Body), event.CreatedAt.UTC().UnixMilli())
	if err != nil {
		return Event{}, fmt.Errorf("append event: %w", err)
	}
	event.Seq, err = result.LastInsertId()
	if err != nil {
		return Event{}, fmt.Errorf("read event cursor: %w", err)
	}
	return event, nil
}
func contentID(value []byte) string {
	sum := sha256.Sum256(value)
	return "sha256:" + base64.RawURLEncoding.EncodeToString(sum[:])
}
func randomID(prefix string) (string, error) {
	value := make([]byte, 18)
	if _, err := rand.Read(value); err != nil {
		return "", fmt.Errorf("generate identifier: %w", err)
	}
	return prefix + "_" + base64.RawURLEncoding.EncodeToString(value), nil
}
func cloneJSON(value []byte) json.RawMessage {
	return append(json.RawMessage(nil), value...)
}
func millisTime(value int64) time.Time {
	return time.UnixMilli(value).UTC()
}
