package opendrop

import "sync"

type Hub struct {
	mu          sync.Mutex
	nextID      uint64
	subscribers map[string]map[uint64]chan struct{}
}

func NewHub() *Hub {
	return &Hub{subscribers: make(map[string]map[uint64]chan struct{})}
}

func (h *Hub) Subscribe(subject, space string) (<-chan struct{}, func()) {
	if h == nil {
		closed := make(chan struct{})
		close(closed)
		return closed, func() {}
	}
	key := hubKey(subject, space)
	ch := make(chan struct{}, 1)
	h.mu.Lock()
	h.nextID++
	id := h.nextID
	if h.subscribers[key] == nil {
		h.subscribers[key] = make(map[uint64]chan struct{})
	}
	h.subscribers[key][id] = ch
	h.mu.Unlock()

	var once sync.Once
	return ch, func() {
		once.Do(func() {
			h.mu.Lock()
			if listeners := h.subscribers[key]; listeners != nil {
				delete(listeners, id)
				if len(listeners) == 0 {
					delete(h.subscribers, key)
				}
			}
			h.mu.Unlock()
		})
	}
}

func (h *Hub) Publish(subject, space string) {
	if h == nil {
		return
	}
	key := hubKey(subject, space)
	h.mu.Lock()
	defer h.mu.Unlock()
	for _, listener := range h.subscribers[key] {
		select {
		case listener <- struct{}{}:
		default:
		}
	}
}

func hubKey(subject, space string) string {
	return subject + "\x00" + space
}
