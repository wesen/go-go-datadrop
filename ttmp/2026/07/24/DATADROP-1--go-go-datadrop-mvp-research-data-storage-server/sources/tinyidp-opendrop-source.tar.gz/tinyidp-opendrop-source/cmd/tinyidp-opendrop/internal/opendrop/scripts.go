package opendrop

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"html"
	"strings"
	"time"

	"github.com/dop251/goja"
	"github.com/go-go-golems/go-go-goja/pkg/engine"
)

const (
	defaultScriptTimeout     = 250 * time.Millisecond
	defaultScriptConcurrency = 4
	maxScriptInputBytes      = 256 << 10
	maxScriptOutputBytes     = 256 << 10
)

type ScriptRunner struct {
	factory   *engine.RuntimeFactory
	timeout   time.Duration
	maxInput  int
	maxOutput int
	slots     chan struct{}
}

type ScriptInvocation struct {
	Export string         `json:"export"`
	Input  map[string]any `json:"input"`
}

func NewScriptRunner() (*ScriptRunner, error) {
	factory, err := engine.NewRuntimeFactoryBuilder(
		engine.WithDataOnlyDefaultRegistryModules(false),
	).UseModuleMiddleware(engine.Pipeline(
		engine.MiddlewareExclude("timer"),
		engine.MiddlewareSafe(),
	)).
		Build()
	if err != nil {
		return nil, fmt.Errorf("build OpenDrop script runtime: %w", err)
	}
	return &ScriptRunner{
		factory:   factory,
		timeout:   defaultScriptTimeout,
		maxInput:  maxScriptInputBytes,
		maxOutput: maxScriptOutputBytes,
		slots:     make(chan struct{}, defaultScriptConcurrency),
	}, nil
}

func (r *ScriptRunner) Validate(ctx context.Context, source string) error {
	_, err := r.execute(ctx, source, "", map[string]any{}, true)
	return err
}

func (r *ScriptRunner) Run(ctx context.Context, source string, invocation ScriptInvocation) (json.RawMessage, error) {
	exportName := strings.TrimSpace(invocation.Export)
	if exportName == "" {
		exportName = "render"
	}
	if exportName != "render" && exportName != "transform" {
		return nil, fmt.Errorf("%w: script export must be render or transform", ErrInvalid)
	}
	return r.execute(ctx, source, exportName, invocation.Input, false)
}

func (r *ScriptRunner) execute(ctx context.Context, source, exportName string, input map[string]any, validateOnly bool) (json.RawMessage, error) {
	if r == nil || r.factory == nil {
		return nil, errors.New("OpenDrop script runner is unavailable")
	}
	if ctx == nil {
		return nil, errors.New("OpenDrop script context is required")
	}
	if strings.TrimSpace(source) == "" || len(source) > maxScriptSourceBytes {
		return nil, fmt.Errorf("%w: script source must contain 1..%d bytes", ErrInvalid, maxScriptSourceBytes)
	}
	select {
	case r.slots <- struct{}{}:
		defer func() { <-r.slots }()
	case <-ctx.Done():
		return nil, fmt.Errorf("execute OpenDrop script: %w", ctx.Err())
	}
	encodedInput, err := json.Marshal(input)
	if err != nil {
		return nil, fmt.Errorf("encode script input: %w", err)
	}
	if len(encodedInput) > r.maxInput {
		return nil, fmt.Errorf("%w: script input exceeds %d bytes", ErrInvalid, r.maxInput)
	}
	var canonicalInput any
	if err := json.Unmarshal(encodedInput, &canonicalInput); err != nil {
		return nil, fmt.Errorf("normalize script input: %w", err)
	}

	runCtx, cancel := context.WithTimeout(ctx, r.timeout)
	defer cancel()
	runtime, err := r.factory.NewRuntime(engine.WithStartupContext(runCtx), engine.WithLifetimeContext(runCtx))
	if err != nil {
		return nil, fmt.Errorf("create OpenDrop script runtime: %w", err)
	}
	defer func() {
		closeCtx, closeCancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
		defer closeCancel()
		_ = runtime.Close(closeCtx)
	}()

	interruptStop := make(chan struct{})
	interruptJoined := make(chan struct{})
	go func() {
		defer close(interruptJoined)
		select {
		case <-runCtx.Done():
			runtime.VM.Interrupt(runCtx.Err())
		case <-interruptStop:
		}
	}()

	value, callErr := runtime.Owner.Call(runCtx, "opendrop.script.run", func(_ context.Context, vm *goja.Runtime) (any, error) {
		if err := hardenScriptGlobals(vm); err != nil {
			return nil, err
		}
		module := vm.NewObject()
		exports := vm.NewObject()
		if err := module.Set("exports", exports); err != nil {
			return nil, err
		}
		if err := vm.Set("module", module); err != nil {
			return nil, err
		}
		if err := vm.Set("exports", exports); err != nil {
			return nil, err
		}
		if err := vm.Set("opendrop", map[string]any{
			"version":    "0.1",
			"escapeHTML": html.EscapeString,
			"limits": map[string]any{
				"maxOutputBytes": r.maxOutput,
			},
		}); err != nil {
			return nil, err
		}
		if _, err := vm.RunScript("opendrop-user-script.js", source); err != nil {
			return nil, err
		}
		loaded := module.Get("exports")
		if goja.IsUndefined(loaded) || goja.IsNull(loaded) {
			return nil, errors.New("script must assign module.exports")
		}
		loadedObject := loaded.ToObject(vm)
		if validateOnly {
			exported := 0
			for _, name := range []string{"render", "transform"} {
				candidate := loadedObject.Get(name)
				if goja.IsUndefined(candidate) {
					continue
				}
				if _, ok := goja.AssertFunction(candidate); !ok {
					return nil, fmt.Errorf("module.exports.%s must be a function", name)
				}
				exported++
			}
			if exported == 0 {
				return nil, errors.New("script must export render or transform")
			}
			return map[string]any{"valid": true}, nil
		}
		callable, ok := goja.AssertFunction(loadedObject.Get(exportName))
		if !ok {
			return nil, fmt.Errorf("module.exports.%s is not a function", exportName)
		}
		result, err := callable(loadedObject, vm.ToValue(canonicalInput))
		if err != nil {
			return nil, err
		}
		if _, ok := result.Export().(*goja.Promise); ok {
			return nil, errors.New("OpenDrop scripts must return synchronously")
		}
		return result.Export(), nil
	})
	close(interruptStop)
	<-interruptJoined
	if callErr != nil {
		if errors.Is(runCtx.Err(), context.DeadlineExceeded) {
			return nil, errors.New("OpenDrop script exceeded its execution deadline")
		}
		if err := ctx.Err(); err != nil {
			return nil, fmt.Errorf("execute OpenDrop script: %w", err)
		}
		return nil, fmt.Errorf("execute OpenDrop script: %w", callErr)
	}
	encoded, err := json.Marshal(value)
	if err != nil {
		return nil, fmt.Errorf("script result is not JSON-serializable: %w", err)
	}
	if len(encoded) > r.maxOutput {
		return nil, fmt.Errorf("script result exceeds %d bytes", r.maxOutput)
	}
	return append(json.RawMessage(nil), encoded...), nil
}

func hardenScriptGlobals(vm *goja.Runtime) error {
	if vm == nil {
		return errors.New("OpenDrop script runtime is unavailable")
	}
	console := vm.NewObject()
	noop := func(goja.FunctionCall) goja.Value { return goja.Undefined() }
	for _, name := range []string{"log", "info", "warn", "error", "debug", "trace", "dir"} {
		if err := console.Set(name, noop); err != nil {
			return fmt.Errorf("install bounded console.%s: %w", name, err)
		}
	}
	if err := vm.Set("console", console); err != nil {
		return fmt.Errorf("install bounded console: %w", err)
	}
	for _, name := range []string{
		"setTimeout", "clearTimeout", "setInterval", "clearInterval", "setImmediate", "clearImmediate",
	} {
		if err := vm.Set(name, goja.Undefined()); err != nil {
			return fmt.Errorf("disable script timer %s: %w", name, err)
		}
	}
	return nil
}
