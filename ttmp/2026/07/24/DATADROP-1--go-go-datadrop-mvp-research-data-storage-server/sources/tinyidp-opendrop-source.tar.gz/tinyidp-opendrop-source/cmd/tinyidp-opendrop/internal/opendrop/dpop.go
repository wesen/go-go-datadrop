package opendrop

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"math/big"
	"net/http"
	"net/url"
	"strings"
	"time"
)

const dpopProofMaxAge = 5 * time.Minute

type DPoPProof struct {
	JKT string
	JTI string
	ATH string
}

type dpopHeader struct {
	Typ string         `json:"typ"`
	Alg string         `json:"alg"`
	JWK map[string]any `json:"jwk"`
}

type dpopClaims struct {
	JTI string `json:"jti"`
	HTM string `json:"htm"`
	HTU string `json:"htu"`
	IAT int64  `json:"iat"`
	ATH string `json:"ath,omitempty"`
}

type replayStore interface {
	RememberDPoPProof(ctx context.Context, jkt, jti string, expiresAt time.Time) error
}

type DPoPVerifier struct {
	publicBaseURL string
	replays       replayStore
	now           func() time.Time
}

func NewDPoPVerifier(publicBaseURL string, replays replayStore) (*DPoPVerifier, error) {
	parsed, err := url.Parse(strings.TrimSpace(publicBaseURL))
	if err != nil || parsed.Scheme == "" || parsed.Host == "" || parsed.User != nil || parsed.RawQuery != "" || parsed.Fragment != "" {
		return nil, errors.New("opendrop public base URL must be an absolute URL without userinfo, query, or fragment")
	}
	if parsed.EscapedPath() != "" && parsed.EscapedPath() != "/" {
		return nil, errors.New("opendrop public base URL must not contain a path")
	}
	if replays == nil {
		return nil, errors.New("opendrop DPoP replay store is required")
	}
	return &DPoPVerifier{publicBaseURL: strings.TrimRight(parsed.String(), "/"), replays: replays, now: time.Now}, nil
}

func (v *DPoPVerifier) Validate(ctx context.Context, r *http.Request, raw, accessToken, expectedJKT string) (DPoPProof, error) {
	if v == nil || r == nil || ctx == nil {
		return DPoPProof{}, errors.New("DPoP verifier and request are required")
	}
	parts := strings.Split(strings.TrimSpace(raw), ".")
	if len(parts) != 3 || parts[0] == "" || parts[1] == "" || parts[2] == "" {
		return DPoPProof{}, errors.New("DPoP proof must be a compact JWT")
	}
	headerBytes, err := base64.RawURLEncoding.DecodeString(parts[0])
	if err != nil {
		return DPoPProof{}, errors.New("invalid DPoP proof header encoding")
	}
	claimsBytes, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return DPoPProof{}, errors.New("invalid DPoP proof payload encoding")
	}
	signature, err := base64.RawURLEncoding.DecodeString(parts[2])
	if err != nil {
		return DPoPProof{}, errors.New("invalid DPoP proof signature encoding")
	}

	var rawHeader map[string]json.RawMessage
	if err := json.Unmarshal(headerBytes, &rawHeader); err != nil {
		return DPoPProof{}, errors.New("invalid DPoP proof header JSON")
	}
	for key := range rawHeader {
		switch key {
		case "typ", "alg", "jwk":
		default:
			return DPoPProof{}, fmt.Errorf("unsupported DPoP proof header parameter %q", key)
		}
	}
	var header dpopHeader
	if err := json.Unmarshal(headerBytes, &header); err != nil {
		return DPoPProof{}, errors.New("invalid DPoP proof header JSON")
	}
	if !strings.EqualFold(header.Typ, "dpop+jwt") {
		return DPoPProof{}, errors.New("DPoP proof typ must be dpop+jwt")
	}
	if header.Alg != "ES256" {
		return DPoPProof{}, errors.New("DPoP proof alg must be ES256")
	}
	if header.JWK == nil || hasPrivateJWKMembers(header.JWK) {
		return DPoPProof{}, errors.New("DPoP proof must contain a public JWK")
	}

	var claims dpopClaims
	if err := json.Unmarshal(claimsBytes, &claims); err != nil {
		return DPoPProof{}, errors.New("invalid DPoP proof payload JSON")
	}
	if claims.JTI == "" || len(claims.JTI) > 256 {
		return DPoPProof{}, errors.New("DPoP proof has an invalid jti")
	}
	if strings.ToUpper(claims.HTM) != r.Method {
		return DPoPProof{}, errors.New("DPoP proof htm mismatch")
	}
	if claims.HTU != v.requestURL(r) {
		return DPoPProof{}, errors.New("DPoP proof htu mismatch")
	}
	if claims.IAT == 0 {
		return DPoPProof{}, errors.New("DPoP proof missing iat")
	}
	iat := time.Unix(claims.IAT, 0).UTC()
	now := v.now().UTC()
	if iat.Before(now.Add(-dpopProofMaxAge)) || iat.After(now.Add(dpopProofMaxAge)) {
		return DPoPProof{}, errors.New("DPoP proof iat is outside the allowed freshness window")
	}
	if accessToken != "" {
		if claims.ATH == "" || claims.ATH != accessTokenHash(accessToken) {
			return DPoPProof{}, errors.New("DPoP proof ath mismatch")
		}
	}

	jkt, err := verifyES256JWK(header.JWK, []byte(parts[0]+"."+parts[1]), signature)
	if err != nil {
		return DPoPProof{}, err
	}
	if expectedJKT != "" && jkt != expectedJKT {
		return DPoPProof{}, errors.New("DPoP proof key does not match the session")
	}
	if err := v.replays.RememberDPoPProof(ctx, jkt, claims.JTI, iat.Add(dpopProofMaxAge)); err != nil {
		if errors.Is(err, ErrReplay) {
			return DPoPProof{}, errors.New("DPoP proof replay detected")
		}
		return DPoPProof{}, fmt.Errorf("record DPoP proof: %w", err)
	}
	return DPoPProof{JKT: jkt, JTI: claims.JTI, ATH: claims.ATH}, nil
}

func (v *DPoPVerifier) requestURL(r *http.Request) string {
	path := r.URL.EscapedPath()
	if path == "" {
		path = "/"
	}
	return v.publicBaseURL + path
}

func verifyES256JWK(jwk map[string]any, signingInput, signature []byte) (string, error) {
	if jwkString(jwk, "kty") != "EC" || jwkString(jwk, "crv") != "P-256" {
		return "", errors.New("DPoP ES256 proof requires a P-256 EC JWK")
	}
	xText, yText := jwkString(jwk, "x"), jwkString(jwk, "y")
	if xText == "" || yText == "" {
		return "", errors.New("DPoP EC JWK is missing x or y")
	}
	xBytes, err := base64.RawURLEncoding.DecodeString(xText)
	if err != nil || len(xBytes) != 32 {
		return "", errors.New("invalid DPoP EC JWK x coordinate")
	}
	yBytes, err := base64.RawURLEncoding.DecodeString(yText)
	if err != nil || len(yBytes) != 32 {
		return "", errors.New("invalid DPoP EC JWK y coordinate")
	}
	x, y := new(big.Int).SetBytes(xBytes), new(big.Int).SetBytes(yBytes)
	curve := elliptic.P256()
	//nolint:staticcheck // JWK coordinates are defined in terms of the legacy elliptic API.
	if !curve.IsOnCurve(x, y) {
		return "", errors.New("DPoP EC JWK point is not on P-256")
	}
	if len(signature) != 64 {
		return "", errors.New("invalid ES256 DPoP proof signature length")
	}
	sum := sha256.Sum256(signingInput)
	if !ecdsa.Verify(&ecdsa.PublicKey{Curve: curve, X: x, Y: y}, sum[:], new(big.Int).SetBytes(signature[:32]), new(big.Int).SetBytes(signature[32:])) {
		return "", errors.New("invalid DPoP proof signature")
	}
	thumbprintJSON, err := json.Marshal(struct {
		Crv string `json:"crv"`
		Kty string `json:"kty"`
		X   string `json:"x"`
		Y   string `json:"y"`
	}{Crv: "P-256", Kty: "EC", X: xText, Y: yText})
	if err != nil {
		return "", fmt.Errorf("encode JWK thumbprint input: %w", err)
	}
	thumbprint := sha256.Sum256(thumbprintJSON)
	return base64.RawURLEncoding.EncodeToString(thumbprint[:]), nil
}

func jwkString(jwk map[string]any, key string) string {
	value, _ := jwk[key].(string)
	return value
}

func hasPrivateJWKMembers(jwk map[string]any) bool {
	for _, key := range []string{"d", "p", "q", "dp", "dq", "qi", "oth"} {
		if _, exists := jwk[key]; exists {
			return true
		}
	}
	return false
}

func accessTokenHash(token string) string {
	sum := sha256.Sum256([]byte(token))
	return base64.RawURLEncoding.EncodeToString(sum[:])
}

func tokenDigest(token string) []byte {
	sum := sha256.Sum256([]byte(token))
	return append([]byte(nil), sum[:]...)
}

func parseAuthorization(values []string, scheme string) (string, bool) {
	if len(values) != 1 {
		return "", false
	}
	parts := strings.Fields(values[0])
	if len(parts) != 2 || !strings.EqualFold(parts[0], scheme) || parts[1] == "" || strings.ContainsAny(parts[1], "\r\n") {
		return "", false
	}
	return parts[1], true
}
