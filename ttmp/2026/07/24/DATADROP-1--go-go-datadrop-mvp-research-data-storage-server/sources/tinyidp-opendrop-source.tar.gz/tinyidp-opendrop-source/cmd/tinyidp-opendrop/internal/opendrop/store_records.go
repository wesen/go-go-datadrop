package opendrop

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
)

func (s *Store) PutRecord(ctx context.Context, owner, space, collection, rkey string, value json.RawMessage, swapRev string) (Record, Event, error) {
	space, collection, rkey, value, err := validateRecordInput(space, collection, rkey, value)
	if err != nil {
		return Record{}, Event{}, err
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return Record{}, Event{}, fmt.Errorf("begin put record: %w", err)
	}
	defer func() { _ = tx.Rollback() }()
	if err := ensureSpaceTx(ctx, tx, owner, space); err != nil {
		return Record{}, Event{}, err
	}

	now := s.now().UTC()
	createdAt := now
	var existingRev string
	var existingCreated int64
	err = tx.QueryRowContext(ctx, `SELECT rev, created_at FROM opendrop_records
		WHERE owner_sub = ? AND space = ? AND collection = ? AND rkey = ?`, owner, space, collection, rkey).Scan(&existingRev, &existingCreated)
	switch {
	case errors.Is(err, sql.ErrNoRows):
		if swapRev != "" {
			return Record{}, Event{}, fmt.Errorf("%w: record does not exist", ErrConflict)
		}
	case err != nil:
		return Record{}, Event{}, fmt.Errorf("load record revision: %w", err)
	default:
		createdAt = millisTime(existingCreated)
		if swapRev != "" && swapRev != existingRev {
			return Record{}, Event{}, fmt.Errorf("%w: record revision changed", ErrConflict)
		}
	}

	rev, err := randomID("r")
	if err != nil {
		return Record{}, Event{}, err
	}
	cid := contentID(value)
	stamp := now.UnixMilli()
	_, err = tx.ExecContext(ctx, `INSERT INTO opendrop_records(
		owner_sub, space, collection, rkey, rev, cid, value_json, created_at, updated_at
	) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)
	ON CONFLICT(owner_sub, space, collection, rkey) DO UPDATE SET
		rev = excluded.rev, cid = excluded.cid, value_json = excluded.value_json, updated_at = excluded.updated_at`,
		owner, space, collection, rkey, rev, cid, []byte(value), createdAt.UnixMilli(), stamp)
	if err != nil {
		return Record{}, Event{}, fmt.Errorf("put record: %w", err)
	}
	record := Record{Space: space, Collection: collection, RKey: rkey, Rev: rev, CID: cid, Value: cloneJSON(value), CreatedAt: createdAt, UpdatedAt: now}
	body, err := json.Marshal(map[string]any{"record": record})
	if err != nil {
		return Record{}, Event{}, fmt.Errorf("encode record event: %w", err)
	}
	event, err := insertEventTx(ctx, tx, owner, Event{Space: space, Kind: "record.put", Collection: collection, RKey: rkey, Rev: rev, CID: cid, Body: body, CreatedAt: now})
	if err != nil {
		return Record{}, Event{}, err
	}
	if _, err := tx.ExecContext(ctx, `UPDATE opendrop_spaces SET updated_at = ? WHERE owner_sub = ? AND name = ?`, stamp, owner, space); err != nil {
		return Record{}, Event{}, fmt.Errorf("touch space: %w", err)
	}
	if err := tx.Commit(); err != nil {
		return Record{}, Event{}, fmt.Errorf("commit put record: %w", err)
	}
	record.Cursor = event.Seq
	return record, event, nil
}
func (s *Store) GetRecord(ctx context.Context, owner, space, collection, rkey string) (Record, error) {
	space, err := validateSpaceName(space)
	if err != nil {
		return Record{}, err
	}
	collection, err = validateCollection(collection)
	if err != nil {
		return Record{}, err
	}
	rkey, err = validateRKey(rkey)
	if err != nil {
		return Record{}, err
	}
	var record Record
	var value []byte
	var created, updated int64
	err = s.db.QueryRowContext(ctx, `SELECT rev, cid, value_json, created_at, updated_at FROM opendrop_records
		WHERE owner_sub = ? AND space = ? AND collection = ? AND rkey = ?`, owner, space, collection, rkey).
		Scan(&record.Rev, &record.CID, &value, &created, &updated)
	if errors.Is(err, sql.ErrNoRows) {
		return Record{}, ErrNotFound
	}
	if err != nil {
		return Record{}, fmt.Errorf("get record: %w", err)
	}
	record.Space, record.Collection, record.RKey = space, collection, rkey
	record.Value = cloneJSON(value)
	record.CreatedAt, record.UpdatedAt = millisTime(created), millisTime(updated)
	return record, nil
}
func (s *Store) ListRecords(ctx context.Context, owner, space, collection, prefix string, limit int) ([]Record, error) {
	space, err := validateSpaceName(space)
	if err != nil {
		return nil, err
	}
	collection, err = validateCollection(collection)
	if err != nil {
		return nil, err
	}
	if len(prefix) > maxRecordKeyBytes || strings.ContainsAny(prefix, "\x00\r\n") {
		return nil, fmt.Errorf("%w: invalid record-key prefix", ErrInvalid)
	}
	limit = normalizeLimit(limit)
	if _, err := s.getSpace(ctx, owner, space); err != nil {
		return nil, err
	}
	rows, err := s.db.QueryContext(ctx, `SELECT rkey, rev, cid, value_json, created_at, updated_at
		FROM opendrop_records WHERE owner_sub = ? AND space = ? AND collection = ? AND rkey >= ?
		ORDER BY rkey LIMIT ?`, owner, space, collection, prefix, limit)
	if err != nil {
		return nil, fmt.Errorf("list records: %w", err)
	}
	defer rows.Close()
	records := make([]Record, 0)
	for rows.Next() {
		var record Record
		var value []byte
		var created, updated int64
		if err := rows.Scan(&record.RKey, &record.Rev, &record.CID, &value, &created, &updated); err != nil {
			return nil, fmt.Errorf("scan record: %w", err)
		}
		if prefix != "" && !strings.HasPrefix(record.RKey, prefix) {
			break
		}
		record.Space, record.Collection = space, collection
		record.Value = cloneJSON(value)
		record.CreatedAt, record.UpdatedAt = millisTime(created), millisTime(updated)
		records = append(records, record)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate records: %w", err)
	}
	return records, nil
}
func (s *Store) DeleteRecord(ctx context.Context, owner, space, collection, rkey, swapRev string) (Event, error) {
	space, err := validateSpaceName(space)
	if err != nil {
		return Event{}, err
	}
	collection, err = validateCollection(collection)
	if err != nil {
		return Event{}, err
	}
	rkey, err = validateRKey(rkey)
	if err != nil {
		return Event{}, err
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return Event{}, fmt.Errorf("begin delete record: %w", err)
	}
	defer func() { _ = tx.Rollback() }()
	var rev, cid string
	err = tx.QueryRowContext(ctx, `SELECT rev, cid FROM opendrop_records
		WHERE owner_sub = ? AND space = ? AND collection = ? AND rkey = ?`, owner, space, collection, rkey).Scan(&rev, &cid)
	if errors.Is(err, sql.ErrNoRows) {
		return Event{}, ErrNotFound
	}
	if err != nil {
		return Event{}, fmt.Errorf("load record for deletion: %w", err)
	}
	if swapRev != "" && swapRev != rev {
		return Event{}, fmt.Errorf("%w: record revision changed", ErrConflict)
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM opendrop_records WHERE owner_sub = ? AND space = ? AND collection = ? AND rkey = ?`, owner, space, collection, rkey); err != nil {
		return Event{}, fmt.Errorf("delete record: %w", err)
	}
	now := s.now().UTC()
	body, err := json.Marshal(map[string]any{"deleted": true, "collection": collection, "rkey": rkey, "rev": rev, "cid": cid})
	if err != nil {
		return Event{}, fmt.Errorf("encode delete event: %w", err)
	}
	event, err := insertEventTx(ctx, tx, owner, Event{Space: space, Kind: "record.delete", Collection: collection, RKey: rkey, Rev: rev, CID: cid, Body: body, CreatedAt: now})
	if err != nil {
		return Event{}, err
	}
	if _, err := tx.ExecContext(ctx, `UPDATE opendrop_spaces SET updated_at = ? WHERE owner_sub = ? AND name = ?`, now.UnixMilli(), owner, space); err != nil {
		return Event{}, fmt.Errorf("touch space: %w", err)
	}
	if err := tx.Commit(); err != nil {
		return Event{}, fmt.Errorf("commit delete record: %w", err)
	}
	return event, nil
}
