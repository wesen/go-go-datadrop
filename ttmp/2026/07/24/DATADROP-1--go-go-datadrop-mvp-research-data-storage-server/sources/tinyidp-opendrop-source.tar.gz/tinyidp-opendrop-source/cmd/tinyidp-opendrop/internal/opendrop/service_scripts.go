package opendrop

import (
	"net/http"
	"time"
)

func (s *Service) handlePutScript(w http.ResponseWriter, r *http.Request, principal requestPrincipal) {
	var input struct {
		Space   string `json:"space"`
		Name    string `json:"name"`
		Source  string `json:"source"`
		Enabled *bool  `json:"enabled,omitempty"`
		SwapRev string `json:"swapRev,omitempty"`
	}
	if !decodeJSONBody(w, r, &input, maxRequestBodyBytes) {
		return
	}
	if err := s.scripts.Validate(r.Context(), input.Source); err != nil {
		writeAPIError(w, http.StatusBadRequest, "invalid_script", err.Error())
		return
	}
	enabled := true
	if input.Enabled != nil {
		enabled = *input.Enabled
	}
	script, event, err := s.store.PutScript(r.Context(), principal.Session.Subject, input.Space, input.Name, input.Source, enabled, input.SwapRev)
	if err != nil {
		s.writeStoreError(w, err)
		return
	}
	s.hub.Publish(principal.Session.Subject, script.Space)
	s.record(r.Context(), "opendrop.script.put", principal.Session.Subject, principal.Session.ClientID, "accepted", script.Space)
	writeJSON(w, http.StatusOK, map[string]any{"script": script, "cursor": event.Seq})
}
func (s *Service) handleGetScript(w http.ResponseWriter, r *http.Request, principal requestPrincipal) {
	script, err := s.store.GetScript(r.Context(), principal.Session.Subject, r.URL.Query().Get("space"), r.URL.Query().Get("name"))
	if err != nil {
		s.writeStoreError(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"script": script})
}
func (s *Service) handleListScripts(w http.ResponseWriter, r *http.Request, principal requestPrincipal) {
	scripts, err := s.store.ListScripts(r.Context(), principal.Session.Subject, r.URL.Query().Get("space"))
	if err != nil {
		s.writeStoreError(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"scripts": scripts})
}
func (s *Service) handleRunScript(w http.ResponseWriter, r *http.Request, principal requestPrincipal) {
	var input struct {
		Space   string         `json:"space"`
		Name    string         `json:"name"`
		Export  string         `json:"export,omitempty"`
		Input   map[string]any `json:"input,omitempty"`
		Records *struct {
			Collection string `json:"collection"`
			Prefix     string `json:"prefix,omitempty"`
			Limit      int    `json:"limit,omitempty"`
		} `json:"records,omitempty"`
		Events *struct {
			Cursor int64 `json:"cursor,omitempty"`
			Limit  int   `json:"limit,omitempty"`
		} `json:"events,omitempty"`
	}
	if !decodeJSONBody(w, r, &input, maxRequestBodyBytes) {
		return
	}
	script, err := s.store.GetScript(r.Context(), principal.Session.Subject, input.Space, input.Name)
	if err != nil {
		s.writeStoreError(w, err)
		return
	}
	if !script.Enabled {
		writeAPIError(w, http.StatusConflict, "script_disabled", "script is disabled")
		return
	}
	payload := map[string]any{
		"input": input.Input,
		"context": map[string]any{
			"subject": principal.Session.Subject,
			"space":   script.Space,
			"script":  script.Name,
			"rev":     script.Rev,
			"now":     time.Now().UTC().Format(time.RFC3339Nano),
		},
	}
	if input.Records != nil {
		limit := input.Records.Limit
		if limit <= 0 || limit > maxScriptSnapshotItems {
			limit = maxScriptSnapshotItems
		}
		records, err := s.store.ListRecords(r.Context(), principal.Session.Subject, script.Space, input.Records.Collection, input.Records.Prefix, limit)
		if err != nil {
			s.writeStoreError(w, err)
			return
		}
		payload["records"] = records
	}
	if input.Events != nil {
		limit := input.Events.Limit
		if limit <= 0 || limit > maxScriptSnapshotItems {
			limit = maxScriptSnapshotItems
		}
		events, err := s.store.EventsAfter(r.Context(), principal.Session.Subject, script.Space, input.Events.Cursor, limit)
		if err != nil {
			s.writeStoreError(w, err)
			return
		}
		payload["events"] = events
	}
	result, err := s.scripts.Run(r.Context(), script.Source, ScriptInvocation{Export: input.Export, Input: payload})
	if err != nil {
		s.record(r.Context(), "opendrop.script.run_failed", principal.Session.Subject, principal.Session.ClientID, "script_error", script.Space)
		writeAPIError(w, http.StatusUnprocessableEntity, "script_error", err.Error())
		return
	}
	s.record(r.Context(), "opendrop.script.ran", principal.Session.Subject, principal.Session.ClientID, "accepted", script.Space)
	writeJSON(w, http.StatusOK, map[string]any{"script": map[string]any{"space": script.Space, "name": script.Name, "rev": script.Rev}, "result": result})
}
