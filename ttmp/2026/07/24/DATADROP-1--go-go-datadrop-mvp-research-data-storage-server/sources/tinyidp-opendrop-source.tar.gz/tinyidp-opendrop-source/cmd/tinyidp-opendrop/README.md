# TinyIDP OpenDrop

Implementation target: `go-go-golems/tiny-idp` main commit `9e1b3190aaa825e734422e14b18e0780de52614b`.

`tinyidp-opendrop` is a browser-native storage appliance for static sites. It
combines:

- TinyIDP authorization-code OAuth with PKCE and opaque bearer tokens;
- an OAuth bearer-to-DPoP storage-session exchange;
- per-subject spaces, JSON records, append-only streams, and cursors;
- resumable authenticated `fetch()` streams;
- one-use, origin-bound WebSocket tickets;
- saved CommonJS scripts executed with go-go-goja's safe module set; and
- a static browser console and dependency-free JavaScript client.

The application server is deliberately absent. Static pages talk directly to
this process, which owns identity, storage, replay, and realtime delivery.

## Status and compatibility boundary

This command is a development vertical slice. It uses TinyIDP's strict embedded
provider in development mode, but it is not yet a production TinyIDP host. It
does not configure a production client-address resolver, distributed rate
limits, key rotation, backups, or an operator-grade audit pipeline.

It is also not a complete AT Protocol PDS. The v0 API is ATproto-inspired:
XRPC-shaped methods, collections, record keys, revisions, content hashes, and a
cursor feed. It does not implement an MST repository, signed commits, CAR
exports, DID documents, federation, or standard ATproto sync endpoints.

TinyIDP's strict token endpoint currently issues ordinary bearer tokens. The
browser therefore performs a narrow transition:

1. obtain a short-lived TinyIDP bearer token through authorization code + PKCE;
2. generate a non-extractable browser P-256 key;
3. send the bearer token and a DPoP proof to the storage exchange endpoint; and
4. receive an opaque storage token bound to the DPoP JWK thumbprint and browser
   origin.

Every subsequent storage request uses `Authorization: DPoP ...`, a fresh proof,
an `ath` claim, and a durable `jti` replay check. The confidential resource client is retained server-side solely to authenticate
introspection calls; its secret never reaches the browser. The exchange does not
turn the TinyIDP bearer token into a generally reusable credential.

Because DPoP binding happens at this exchange rather than at TinyIDP's token
endpoint, this is a **first-use binding**. The first accepted exchange pins the
bearer-token hash to one JWK thumbprint, subject, origin, and expiry. A stolen
bearer token that wins a race before that first exchange could bind itself. The
production completion is native DPoP issuance or token exchange inside TinyIDP.

## Run it

The repository currently requires its declared Go toolchain. From the repository
root:

```bash
umask 077
export OPENDROP_PASSWORD='Silted-Fern-93!Copper-Moon'

go run ./cmd/tinyidp-opendrop init \
  --state-dir ./var/opendrop \
  --public-base-url http://127.0.0.1:8080 \
  --login alice \
  --email alice@example.test \
  --name Alice

go run ./cmd/tinyidp-opendrop serve \
  --state-dir ./var/opendrop \
  --addr 127.0.0.1:8080
```

Open `http://127.0.0.1:8080/opendrop/`, log in as `alice`, and create a space.

The initial password can instead be read from a file:

```bash
tinyidp-opendrop init --password-file /run/secrets/opendrop-password ...
```

The password is never written to the state manifest.

## Separate static sites

Register every static-site origin during initialization:

```bash
export OPENDROP_PASSWORD='Silted-Fern-93!Copper-Moon'

tinyidp-opendrop init \
  --state-dir /srv/opendrop \
  --public-base-url https://drop.example \
  --origin https://app.example
```

Each registered origin receives this OAuth redirect URI:

```text
https://app.example/opendrop/callback.html
```

The static site must host the callback page and browser client at that path. The
embedded versions are in `internal/opendrop/web/` and can be copied into a
separate static build.

`--public-base-url` is security-sensitive. It must equal the external origin
seen by browsers because DPoP `htu` validation is performed against it. When
running behind a reverse proxy, terminate TLS there and preserve the XRPC paths.

## Browser client

```js
import { OpenDropClient } from "./opendrop-client.js";

const drop = new OpenDropClient({ baseURL: "https://drop.example" });
await drop.initialize();

if (!drop.session()) {
  await drop.login(); // redirects through TinyIDP
}

await drop.request("/xrpc/io.opendrop.space.create", {
  method: "POST",
  body: { name: "greenhouse" },
});

await drop.request("/xrpc/io.opendrop.record.put", {
  method: "POST",
  body: {
    space: "greenhouse",
    collection: "dev.example.reading",
    rkey: "sensor-1",
    value: { temperature: 21.7 },
  },
});
```

The client keeps the DPoP private key as a `CryptoKey` in IndexedDB and keeps the
short-lived storage session in `sessionStorage`. A distinct DPoP key is kept for
each storage origin. Uploaded or third-party page code should not be given the
client object directly; use a capability broker or sandboxed frame. DPoP limits
token replay outside the browser key; it does not protect a page that already
has same-origin script execution through XSS.

## Realtime

The canonical browser transport is an authenticated streaming fetch:

```js
const controller = new AbortController();

await drop.subscribe("greenhouse", {
  cursor: 0,
  signal: controller.signal,
  onEvent(event) {
    console.log(event.seq, event.kind, event.body);
  },
});
```

The response is `application/x-ndjson`. Events are read from SQLite by cursor,
so the in-memory hub is only a wake-up mechanism; reconnecting does not lose
committed data.

Browser WebSockets use a two-step bridge because the browser WebSocket API
cannot attach an `Authorization` or `DPoP` header:

```js
const socket = await drop.websocket("greenhouse", {
  cursor: 0,
  onEvent: console.log,
});
```

The DPoP-authenticated ticket is bound to subject, storage session, origin,
space, cursor, and a short expiration. It is consumed atomically before the
upgrade. Reverse proxies must redact the `ticket` query parameter from access
logs.

## Scripts

A saved script is a CommonJS module with a synchronous `render` or `transform`
export:

```js
module.exports.render = ({ records, context }) => ({
  html: `<h1>${opendrop.escapeHTML(context.space)}</h1><p>${records.length} records</p>`,
  count: records.length,
});
```

The Go host selects and bounds the input snapshot. Scripts receive JSON only:

- caller-owned input;
- optional record and event snapshots capped at 32 items; and
- non-secret execution context.

They do not receive OAuth tokens, DPoP keys, SQL handles, filesystem handles,
process execution, environment variables, or network clients. The runtime disables the engine's automatic data-only module injection, then uses
`engine.MiddlewareSafe()` with the timer module excluded. Each invocation gets a
fresh runtime, a no-op console, disabled timer globals, a four-invocation process
limit, a deadline, and input and output byte caps.

Goja is an in-process JavaScript engine, not a hostile-code memory isolation
boundary. The current deadline/module restrictions are suitable for trusted
owner scripts and accidental runaway code. Multi-tenant adversarial scripts
must run in a separate process, container, or WASI worker with an OS-enforced
memory limit.

## API surface

Authentication:

```text
POST /xrpc/io.opendrop.auth.exchange
POST /xrpc/io.opendrop.auth.revoke
```

Spaces and records:

```text
POST /xrpc/io.opendrop.space.create
GET  /xrpc/io.opendrop.space.list
POST /xrpc/io.opendrop.record.put
GET  /xrpc/io.opendrop.record.get
GET  /xrpc/io.opendrop.record.list
POST /xrpc/io.opendrop.record.delete
```

Streams:

```text
POST /xrpc/io.opendrop.stream.append
GET  /xrpc/io.opendrop.stream.range
GET  /xrpc/io.opendrop.sync.subscribe
POST /xrpc/io.opendrop.sync.websocketTicket
GET  /xrpc/io.opendrop.sync.websocket?ticket=...
```

Scripts:

```text
POST /xrpc/io.opendrop.script.put
GET  /xrpc/io.opendrop.script.get
GET  /xrpc/io.opendrop.script.list
POST /xrpc/io.opendrop.script.run
```

Discovery and UI:

```text
GET /.well-known/opendrop
GET /.well-known/openid-configuration/idp
GET /idp/.well-known/openid-configuration
GET /opendrop/
GET /healthz
GET /readyz
```

## State layout

```text
state.json                         non-secret deployment manifest
identity/tinyidp.sqlite            TinyIDP users, clients, grants, tokens, keys
storage/opendrop.sqlite            spaces, records, events, scripts, sessions
secrets/token.key                  TinyIDP opaque-token secret, mode 0600
secrets/resource-client.key        introspection client secret, mode 0600
audit/events.jsonl                 synchronous append-and-fsync audit log
```

The state directory must not grant group or other access.

## Important v0 decisions

- A space is private to the TinyIDP subject that created it.
- SQLite is authoritative; the realtime hub is not a broker or durable queue.
- Record changes use optional optimistic `swapRev` checks.
- Stream cursors are monotonically increasing SQLite event sequence numbers.
- Content identifiers are currently `sha256:<base64url>`, not ATproto CIDs.
- DPoP proofs use ES256, an `ath` claim, a five-minute freshness window, and a
  durable `(jkt, jti)` replay table.
- Native fetch streaming is primary; WebSockets are a compatibility transport.
- Static pages are clients, not privileged server extensions.

## Durability and audit boundary

Record mutations and their corresponding feed events commit in the same SQLite
transaction. OpenDrop audit events are emitted synchronously after that commit,
using TinyIDP's file audit sink. A storage mutation therefore remains committed
if the subsequent audit write fails. A production profile should add a
transactional audit outbox or place storage and audit records in one database
transaction.
