package main

import (
	"context"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"github.com/go-go-golems/tiny-idp/cmd/tinyidp-opendrop/internal/opendrop"
	"github.com/go-go-golems/tiny-idp/pkg/embeddedidp"
	"github.com/go-go-golems/tiny-idp/pkg/idp"
	"github.com/go-go-golems/tiny-idp/pkg/idpaccounts"
	"github.com/go-go-golems/tiny-idp/pkg/idpstore"
	"github.com/go-go-golems/tiny-idp/pkg/sqlitestore"
	"golang.org/x/crypto/bcrypt"
)

const (
	stateManifestVersion = 1
	resourceClientID     = "tinyidp-opendrop-api"
)

type statePaths struct {
	Root                 string
	Manifest             string
	IdentityDatabase     string
	OpenDropDatabase     string
	AuditLog             string
	TokenSecret          string
	ResourceClientSecret string
}

func resolveStatePaths(root string) statePaths {
	root = filepath.Clean(root)
	return statePaths{
		Root:                 root,
		Manifest:             filepath.Join(root, "state.json"),
		IdentityDatabase:     filepath.Join(root, "identity", "tinyidp.sqlite"),
		OpenDropDatabase:     filepath.Join(root, "storage", "opendrop.sqlite"),
		AuditLog:             filepath.Join(root, "audit", "events.jsonl"),
		TokenSecret:          filepath.Join(root, "secrets", "token.key"),
		ResourceClientSecret: filepath.Join(root, "secrets", "resource-client.key"),
	}
}

type stateManifest struct {
	Version          int       `json:"version"`
	PublicBaseURL    string    `json:"publicBaseUrl"`
	Issuer           string    `json:"issuer"`
	BrowserClientID  string    `json:"browserClientId"`
	ResourceClientID string    `json:"resourceClientId"`
	Audience         string    `json:"audience"`
	AllowedOrigins   []string  `json:"allowedOrigins"`
	CreatedAt        time.Time `json:"createdAt"`
}

type initializeConfig struct {
	StateRoot      string
	PublicBaseURL  string
	AllowedOrigins []string
	Login          string
	Password       []byte
	Email          string
	Name           string
}

func initializeState(ctx context.Context, cfg initializeConfig) (stateManifest, error) {
	if ctx == nil {
		return stateManifest{}, errors.New("initialization context is required")
	}
	if strings.TrimSpace(cfg.StateRoot) == "" || strings.TrimSpace(cfg.PublicBaseURL) == "" || strings.TrimSpace(cfg.Login) == "" || len(cfg.Password) == 0 {
		return stateManifest{}, errors.New("state directory, public base URL, login, and password are required")
	}
	base, err := normalizeBaseURL(cfg.PublicBaseURL)
	if err != nil {
		return stateManifest{}, err
	}
	origins, err := normalizeOrigins(base, cfg.AllowedOrigins)
	if err != nil {
		return stateManifest{}, err
	}
	paths := resolveStatePaths(cfg.StateRoot)
	if err := os.MkdirAll(paths.Root, 0o700); err != nil {
		return stateManifest{}, fmt.Errorf("create state directory: %w", err)
	}
	if err := os.Chmod(paths.Root, 0o700); err != nil {
		return stateManifest{}, fmt.Errorf("protect state directory: %w", err)
	}
	if err := requireOwnerOnlyDirectory(paths.Root); err != nil {
		return stateManifest{}, err
	}

	desired := stateManifest{
		Version:          stateManifestVersion,
		PublicBaseURL:    base,
		Issuer:           base + "/idp",
		BrowserClientID:  opendrop.BrowserClientID,
		ResourceClientID: resourceClientID,
		Audience:         base + "/api",
		AllowedOrigins:   origins,
	}
	if existing, err := readStateManifest(paths.Manifest); err == nil {
		if !sameManifestConfiguration(existing, desired) {
			return stateManifest{}, errors.New("initialized state conflicts with the requested URL or browser origins")
		}
		desired.CreatedAt = existing.CreatedAt
	} else if !os.IsNotExist(err) {
		return stateManifest{}, err
	}

	for _, directory := range stateDirectories(paths) {
		if err := os.MkdirAll(directory, 0o700); err != nil {
			return stateManifest{}, fmt.Errorf("create state subdirectory: %w", err)
		}
		if err := os.Chmod(directory, 0o700); err != nil {
			return stateManifest{}, fmt.Errorf("protect state subdirectory: %w", err)
		}
	}

	tokenSecret, err := loadOrCreateKey(paths.TokenSecret, 32)
	if err != nil {
		return stateManifest{}, err
	}
	defer zeroBytes(tokenSecret)
	resourceKey, err := loadOrCreateKey(paths.ResourceClientSecret, 32)
	if err != nil {
		return stateManifest{}, err
	}
	defer zeroBytes(resourceKey)

	audit, err := idp.NewFileAuditSink(paths.AuditLog)
	if err != nil {
		return stateManifest{}, fmt.Errorf("open audit log: %w", err)
	}
	if err := os.Chmod(paths.AuditLog, 0o600); err != nil {
		_ = audit.Close()
		return stateManifest{}, fmt.Errorf("protect audit log: %w", err)
	}
	auditClosed := false
	defer func() {
		if !auditClosed {
			_ = audit.Close()
		}
	}()

	store, err := sqlitestore.Open(ctx, sqlitestore.DefaultConfig(paths.IdentityDatabase))
	if err != nil {
		return stateManifest{}, fmt.Errorf("open identity database: %w", err)
	}
	storeClosed := false
	defer func() {
		if !storeClosed {
			_ = store.Close()
		}
	}()

	accounts, err := idpaccounts.NewService(store, idpaccounts.Options{Audit: audit})
	if err != nil {
		return stateManifest{}, fmt.Errorf("create account service: %w", err)
	}
	if err := reconcileInitialUser(ctx, store, accounts, cfg); err != nil {
		return stateManifest{}, err
	}

	browser := embeddedidp.BrowserClient(
		opendrop.BrowserClientID,
		callbackURLs(origins),
		logoutURLs(origins),
		[]string{"openid", "profile", "email", opendrop.ScopeRead, opendrop.ScopeWrite, opendrop.ScopeScript},
	)
	browser.Client.AllowedAudiences = []string{desired.Audience}
	if _, err := embeddedidp.Bootstrap(ctx, store, embeddedidp.BootstrapConfig{
		Mode:         embeddedidp.DevMode,
		Clients:      []embeddedidp.ClientSpec{browser},
		SigningKeyID: "opendrop-signing-key",
		Audit:        audit,
	}); err != nil {
		return stateManifest{}, fmt.Errorf("bootstrap TinyIDP: %w", err)
	}
	if err := reconcileResourceClient(ctx, store, resourceKey, desired.Audience); err != nil {
		return stateManifest{}, err
	}
	storage, err := opendrop.OpenStore(ctx, paths.OpenDropDatabase)
	if err != nil {
		return stateManifest{}, fmt.Errorf("initialize OpenDrop database: %w", err)
	}
	if err := storage.Close(); err != nil {
		return stateManifest{}, fmt.Errorf("close initialized OpenDrop database: %w", err)
	}

	if desired.CreatedAt.IsZero() {
		desired.CreatedAt = time.Now().UTC()
	}
	if err := writeManifestAtomic(paths.Manifest, desired); err != nil {
		return stateManifest{}, err
	}
	if err := store.Close(); err != nil {
		storeClosed = true
		return stateManifest{}, fmt.Errorf("close identity database: %w", err)
	}
	storeClosed = true
	if err := audit.Close(); err != nil {
		auditClosed = true
		return stateManifest{}, fmt.Errorf("close audit log: %w", err)
	}
	auditClosed = true
	return desired, nil
}

func reconcileInitialUser(ctx context.Context, store idpstore.Store, accounts *idpaccounts.Service, cfg initializeConfig) error {
	login := strings.TrimSpace(cfg.Login)
	existing, err := store.GetUserByLogin(ctx, login)
	if err == nil {
		if existing.Disabled || (cfg.Email != "" && existing.Email != strings.TrimSpace(cfg.Email)) {
			return errors.New("existing initial user conflicts with initialization request")
		}
		return nil
	}
	if !errors.Is(err, idpstore.ErrNotFound) {
		return fmt.Errorf("read initial user: %w", err)
	}
	_, err = accounts.Create(ctx, idpaccounts.CreateRequest{
		Login:             login,
		Password:          append([]byte(nil), cfg.Password...),
		Email:             strings.TrimSpace(cfg.Email),
		EmailVerified:     strings.TrimSpace(cfg.Email) != "",
		Name:              strings.TrimSpace(cfg.Name),
		PreferredUsername: login,
	})
	if err != nil {
		return fmt.Errorf("create initial user: %w", err)
	}
	return nil
}

func reconcileResourceClient(ctx context.Context, store idpstore.Store, secretKey []byte, audience string) error {
	secret := resourceClientSecret(secretKey)
	desired := idpstore.Client{
		ID:                resourceClientID,
		Public:            false,
		AllowedGrantTypes: []string{idpstore.GrantAuthorizationCode},
		AllowedAudiences:  []string{audience},
		CanIntrospect:     true,
		AccessTokenTTL:    time.Hour,
		IDTokenTTL:        time.Hour,
		RefreshTokenTTL:   24 * time.Hour,
	}
	existing, err := store.GetClient(ctx, resourceClientID)
	if errors.Is(err, idpstore.ErrNotFound) {
		desired.SecretHash, err = bcrypt.GenerateFromPassword([]byte(secret), bcrypt.DefaultCost)
		if err != nil {
			return fmt.Errorf("hash resource client secret: %w", err)
		}
		now := time.Now().UTC()
		desired.CreatedAt, desired.UpdatedAt = now, now
		if err := desired.Validate(idpstore.DevMode); err != nil {
			return fmt.Errorf("validate resource client: %w", err)
		}
		if err := store.PutClient(ctx, desired); err != nil {
			return fmt.Errorf("create resource client: %w", err)
		}
		return nil
	}
	if err != nil {
		return fmt.Errorf("load resource client: %w", err)
	}
	if existing.ID != desired.ID || existing.Public || !existing.CanIntrospect || existing.Disabled ||
		!equalStrings(existing.AllowedAudiences, desired.AllowedAudiences) || !equalStrings(existing.AllowedGrantTypes, desired.AllowedGrantTypes) {
		return errors.New("existing resource client conflicts with OpenDrop security configuration")
	}
	if bcrypt.CompareHashAndPassword(existing.SecretHash, []byte(secret)) != nil {
		return errors.New("existing resource client secret conflicts with owner-only state")
	}
	return nil
}

func readStateManifest(file string) (stateManifest, error) {
	contents, err := os.ReadFile(file)
	if err != nil {
		return stateManifest{}, err
	}
	var manifest stateManifest
	if err := json.Unmarshal(contents, &manifest); err != nil {
		return stateManifest{}, fmt.Errorf("decode state manifest: %w", err)
	}
	if manifest.Version != stateManifestVersion || manifest.PublicBaseURL == "" || manifest.Issuer == "" ||
		manifest.BrowserClientID != opendrop.BrowserClientID || manifest.ResourceClientID != resourceClientID ||
		manifest.Audience == "" || len(manifest.AllowedOrigins) == 0 || manifest.CreatedAt.IsZero() {
		return stateManifest{}, errors.New("state manifest is incomplete or unsupported")
	}
	return manifest, nil
}

func validateState(root string) (stateManifest, statePaths, error) {
	paths := resolveStatePaths(root)
	if err := requireOwnerOnlyDirectory(paths.Root); err != nil {
		return stateManifest{}, paths, err
	}
	manifest, err := readStateManifest(paths.Manifest)
	if err != nil {
		return stateManifest{}, paths, fmt.Errorf("read initialized state: %w", err)
	}
	for _, directory := range stateDirectories(paths) {
		if err := requireOwnerOnlyDirectory(directory); err != nil {
			return stateManifest{}, paths, fmt.Errorf("validate state subdirectory %s: %w", directory, err)
		}
	}
	for label, file := range map[string]string{
		"state manifest":         paths.Manifest,
		"identity database":      paths.IdentityDatabase,
		"OpenDrop database":      paths.OpenDropDatabase,
		"audit log":              paths.AuditLog,
		"TinyIDP token secret":   paths.TokenSecret,
		"resource client secret": paths.ResourceClientSecret,
	} {
		info, err := os.Stat(file)
		if err != nil {
			return stateManifest{}, paths, fmt.Errorf("%s is unavailable: %w", label, err)
		}
		if !info.Mode().IsRegular() || info.Mode().Perm() != 0o600 {
			return stateManifest{}, paths, fmt.Errorf("%s permissions are %#o, want a regular file with mode 0600", label, info.Mode().Perm())
		}
	}
	for label, file := range map[string]string{
		"TinyIDP token secret":   paths.TokenSecret,
		"resource client secret": paths.ResourceClientSecret,
	} {
		info, err := os.Stat(file)
		if err != nil {
			return stateManifest{}, paths, fmt.Errorf("%s is unavailable: %w", label, err)
		}
		if info.Size() != 32 {
			return stateManifest{}, paths, fmt.Errorf("%s has %d bytes, want 32", label, info.Size())
		}
	}
	return manifest, paths, nil
}

func normalizeBaseURL(raw string) (string, error) {
	parsed, err := url.Parse(strings.TrimSpace(raw))
	if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" || parsed.User != nil || parsed.RawQuery != "" || parsed.Fragment != "" {
		return "", errors.New("public base URL must be an absolute HTTP(S) URL without userinfo, query, or fragment")
	}
	if parsed.EscapedPath() != "" && parsed.EscapedPath() != "/" {
		return "", errors.New("public base URL must not contain a path")
	}
	return parsed.Scheme + "://" + parsed.Host, nil
}

func normalizeOrigins(base string, raw []string) ([]string, error) {
	baseOrigin, err := normalizeOrigin(base)
	if err != nil {
		return nil, err
	}
	set := map[string]struct{}{baseOrigin: {}}
	for _, candidate := range raw {
		origin, err := normalizeOrigin(candidate)
		if err != nil {
			return nil, err
		}
		set[origin] = struct{}{}
	}
	origins := make([]string, 0, len(set))
	for origin := range set {
		origins = append(origins, origin)
	}
	sort.Strings(origins)
	return origins, nil
}

func normalizeOrigin(raw string) (string, error) {
	parsed, err := url.Parse(strings.TrimSpace(raw))
	if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" || parsed.User != nil || parsed.RawQuery != "" || parsed.Fragment != "" {
		return "", fmt.Errorf("invalid browser origin %q", raw)
	}
	if parsed.EscapedPath() != "" && parsed.EscapedPath() != "/" {
		return "", fmt.Errorf("browser origin %q must not contain a path", raw)
	}
	return parsed.Scheme + "://" + parsed.Host, nil
}

func stateDirectories(paths statePaths) []string {
	return []string{
		filepath.Dir(paths.IdentityDatabase),
		filepath.Dir(paths.OpenDropDatabase),
		filepath.Dir(paths.AuditLog),
		filepath.Dir(paths.TokenSecret),
	}
}

func callbackURLs(origins []string) []string {
	out := make([]string, 0, len(origins))
	for _, origin := range origins {
		out = append(out, origin+"/opendrop/callback.html")
	}
	return out
}

func logoutURLs(origins []string) []string {
	out := make([]string, 0, len(origins))
	for _, origin := range origins {
		out = append(out, origin+"/opendrop/")
	}
	return out
}

func sameManifestConfiguration(left, right stateManifest) bool {
	return left.Version == right.Version && left.PublicBaseURL == right.PublicBaseURL && left.Issuer == right.Issuer &&
		left.BrowserClientID == right.BrowserClientID && left.ResourceClientID == right.ResourceClientID &&
		left.Audience == right.Audience && equalStrings(left.AllowedOrigins, right.AllowedOrigins)
}

func equalStrings(left, right []string) bool {
	if len(left) != len(right) {
		return false
	}
	for i := range left {
		if left[i] != right[i] {
			return false
		}
	}
	return true
}

func loadOrCreateKey(file string, size int) ([]byte, error) {
	if key, err := os.ReadFile(file); err == nil {
		if len(key) != size {
			return nil, fmt.Errorf("secret %s has %d bytes, want %d", file, len(key), size)
		}
		info, statErr := os.Stat(file)
		if statErr != nil {
			return nil, fmt.Errorf("stat secret: %w", statErr)
		}
		if info.Mode().Perm() != 0o600 {
			return nil, fmt.Errorf("secret %s permissions are %#o, want 0600", file, info.Mode().Perm())
		}
		return key, nil
	} else if !os.IsNotExist(err) {
		return nil, fmt.Errorf("read secret: %w", err)
	}
	if err := os.MkdirAll(filepath.Dir(file), 0o700); err != nil {
		return nil, fmt.Errorf("create secret directory: %w", err)
	}
	key := make([]byte, size)
	if _, err := rand.Read(key); err != nil {
		return nil, fmt.Errorf("generate secret: %w", err)
	}
	handle, err := os.OpenFile(file, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
	if os.IsExist(err) {
		zeroBytes(key)
		return loadOrCreateKey(file, size)
	}
	if err != nil {
		zeroBytes(key)
		return nil, fmt.Errorf("create secret: %w", err)
	}
	written, err := handle.Write(key)
	if err != nil || written != len(key) {
		_ = handle.Close()
		_ = os.Remove(file)
		zeroBytes(key)
		if err != nil {
			return nil, fmt.Errorf("write secret: %w", err)
		}
		return nil, fmt.Errorf("write secret: short write (%d of %d bytes)", written, len(key))
	}
	if err := handle.Sync(); err != nil {
		_ = handle.Close()
		_ = os.Remove(file)
		zeroBytes(key)
		return nil, fmt.Errorf("sync secret: %w", err)
	}
	if err := handle.Close(); err != nil {
		_ = os.Remove(file)
		zeroBytes(key)
		return nil, fmt.Errorf("close secret: %w", err)
	}
	directory, err := os.Open(filepath.Dir(file))
	if err != nil {
		zeroBytes(key)
		return nil, fmt.Errorf("open secret directory for sync: %w", err)
	}
	if err := directory.Sync(); err != nil {
		_ = directory.Close()
		zeroBytes(key)
		return nil, fmt.Errorf("sync secret directory: %w", err)
	}
	if err := directory.Close(); err != nil {
		zeroBytes(key)
		return nil, fmt.Errorf("close secret directory: %w", err)
	}
	return key, nil
}

func writeManifestAtomic(file string, manifest stateManifest) error {
	contents, err := json.MarshalIndent(manifest, "", "  ")
	if err != nil {
		return fmt.Errorf("encode state manifest: %w", err)
	}
	contents = append(contents, '\n')
	temporary := file + ".tmp"
	handle, err := os.OpenFile(temporary, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0o600)
	if err != nil {
		return fmt.Errorf("create state manifest temporary file: %w", err)
	}
	cleanup := func() {
		_ = handle.Close()
		_ = os.Remove(temporary)
	}
	if err := handle.Chmod(0o600); err != nil {
		cleanup()
		return fmt.Errorf("protect state manifest temporary file: %w", err)
	}
	written, err := handle.Write(contents)
	if err != nil || written != len(contents) {
		cleanup()
		if err != nil {
			return fmt.Errorf("write state manifest temporary file: %w", err)
		}
		return fmt.Errorf("write state manifest temporary file: short write (%d of %d bytes)", written, len(contents))
	}
	if err := handle.Sync(); err != nil {
		cleanup()
		return fmt.Errorf("sync state manifest temporary file: %w", err)
	}
	if err := handle.Close(); err != nil {
		_ = os.Remove(temporary)
		return fmt.Errorf("close state manifest temporary file: %w", err)
	}
	if err := os.Rename(temporary, file); err != nil {
		_ = os.Remove(temporary)
		return fmt.Errorf("commit state manifest: %w", err)
	}
	directory, err := os.Open(filepath.Dir(file))
	if err != nil {
		return fmt.Errorf("open state directory for sync: %w", err)
	}
	defer directory.Close()
	if err := directory.Sync(); err != nil {
		return fmt.Errorf("sync state directory: %w", err)
	}
	return nil
}

func requireOwnerOnlyDirectory(directory string) error {
	info, err := os.Stat(directory)
	if err != nil {
		return fmt.Errorf("stat state directory: %w", err)
	}
	if !info.IsDir() {
		return errors.New("state path is not a directory")
	}
	if info.Mode().Perm()&0o077 != 0 {
		return fmt.Errorf("state directory permissions are %#o; group and other access must be disabled", info.Mode().Perm())
	}
	return nil
}

func resourceClientSecret(key []byte) string {
	return base64.RawURLEncoding.EncodeToString(key)
}

func zeroBytes(value []byte) {
	for i := range value {
		value[i] = 0
	}
}
