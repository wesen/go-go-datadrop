import { OpenDropClient } from "./opendrop-client.js";

const status = document.querySelector("#callback-status");
try {
  await OpenDropClient.completeLogin();
  status.textContent = "Login complete. Returning to OpenDrop…";
  location.replace("./");
} catch (error) {
  status.textContent = `Login failed: ${error.message}`;
}
