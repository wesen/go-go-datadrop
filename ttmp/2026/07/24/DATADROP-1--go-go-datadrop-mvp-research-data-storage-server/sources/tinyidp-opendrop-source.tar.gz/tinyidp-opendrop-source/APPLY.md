# Apply and run TinyIDP OpenDrop

The patch is pinned to TinyIDP commit:

```text
9e1b3190aaa825e734422e14b18e0780de52614b
```

It adds only `cmd/tinyidp-opendrop/`; it does not modify existing source files or
the module dependency files.

## 1. Apply the patch

```bash
git clone https://github.com/go-go-golems/tiny-idp.git
cd tiny-idp
git checkout 9e1b3190aaa825e734422e14b18e0780de52614b

git apply --check /path/to/tinyidp-opendrop.patch
git apply --index /path/to/tinyidp-opendrop.patch
```

Inspect the result:

```bash
git diff --cached --stat
git diff --cached --check
```

## 2. Build and test with TinyIDP's declared toolchain

The target repository declares Go 1.26.4 and toolchain 1.26.5. Use that
repository/toolchain rather than the older compiler that was available while
the patch was assembled.

```bash
go test ./cmd/tinyidp-opendrop/...
go test -race ./cmd/tinyidp-opendrop/...
go vet ./cmd/tinyidp-opendrop/...
go build ./cmd/tinyidp-opendrop
```

A successful real-module run is the required gate before deployment.

## 3. Initialize local state

Use an owner-only state directory and a password supplied through an environment
variable or file. The password must contain at least 15 bytes.

```bash
umask 077
export OPENDROP_PASSWORD='Silted-Fern-93!Copper-Moon'

go run ./cmd/tinyidp-opendrop init \
  --state-dir ./var/opendrop \
  --public-base-url http://127.0.0.1:8080 \
  --login alice \
  --email alice@example.test \
  --name Alice
```

A password file can be used instead:

```bash
go run ./cmd/tinyidp-opendrop init \
  --password-file /run/secrets/opendrop-password \
  --state-dir ./var/opendrop \
  --public-base-url http://127.0.0.1:8080
```

The password itself is not written to the manifest.

## 4. Start the appliance

```bash
go run ./cmd/tinyidp-opendrop serve \
  --state-dir ./var/opendrop \
  --addr 127.0.0.1:8080
```

Open:

```text
http://127.0.0.1:8080/opendrop/
```

Operational endpoints:

```text
http://127.0.0.1:8080/healthz
http://127.0.0.1:8080/readyz
http://127.0.0.1:8080/.well-known/opendrop
```

## 5. Register a separate static-site origin

Origins are fixed at initialization because they determine OAuth redirect URIs,
CORS, and WebSocket ticket binding.

```bash
export OPENDROP_PASSWORD='Silted-Fern-93!Copper-Moon'

go run ./cmd/tinyidp-opendrop init \
  --state-dir /srv/opendrop \
  --public-base-url https://drop.example \
  --origin https://app.example \
  --login alice \
  --email alice@example.test \
  --name Alice
```

The registered callback for that site is:

```text
https://app.example/opendrop/callback.html
```

Copy the static client files from:

```text
cmd/tinyidp-opendrop/internal/opendrop/web/
```

The static application can then construct:

```js
import { OpenDropClient } from "./opendrop-client.js";

const drop = new OpenDropClient({ baseURL: "https://drop.example" });
await drop.initialize();
await drop.login();
```

## 6. Reverse-proxy requirements

For anything beyond loopback development:

- expose the exact `--public-base-url` origin to browsers;
- terminate TLS before requests reach the Go process;
- do not rewrite the XRPC or `/idp` paths;
- support streaming responses and WebSocket upgrades;
- disable proxy buffering on the NDJSON feed;
- redact the `ticket` query parameter on the WebSocket endpoint from logs;
- preserve the browser `Origin` header; and
- apply request/rate limits at the edge in addition to application limits.

`--public-base-url` is used for DPoP `htu` verification. A mismatch between that
value and the public browser URL will cause proof rejection.

## 7. Minimal API smoke test

The embedded browser console is the simplest end-to-end test because it handles
PKCE and DPoP. After login:

1. Create a `demo` space.
2. Put a JSON record.
3. Start the fetch stream.
4. Append an event and verify it appears with an increasing cursor.
5. Stop the fetch stream, start the WebSocket, append another event, and verify
   delivery.
6. Save and run the sample Goja script; confirm its output appears in the
   sandboxed preview.

Also verify:

```bash
curl --fail http://127.0.0.1:8080/healthz
curl --fail http://127.0.0.1:8080/readyz
```

## 8. Remove the patch

Before committing:

```bash
git reset --hard HEAD
git clean -fd cmd/tinyidp-opendrop
```

After committing, revert the resulting commit normally.
